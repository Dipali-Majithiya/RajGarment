<?php
include("template.php");
function main()
{
	$heading="Users";
    include("inc/clsObj.php");
	$pageName="codeAdminUser.php";
	$object=$obj_admin;
	$object->limit=TOTAL_RECORDS;	
	
	extract($_POST);	
    
	$object->id=isset($_GET['uid']) ? $_GET['uid'] : ( isset($_GET['delete']) ? $_GET['delete'] : ( isset($_GET['id']) ? $_GET['id'] : $hid  )) ;
	$object->adminName=$txtAdminName;
	$object->adminUsername=$txtUserName;
    $object->adminPassword=encryptPassword($txtPassword);
	$object->adminEmail=$txtEmail;
	$object->status=isset($_GET['status']) ? $_GET['status'] : 0;	
		
	if(isset($_POST['btnAdd']))
	{
		$object->insert();	
		redirect($pageName."?msg=add");			
	}
	
	if(isset($_POST['btnUpdate']))
	{	
		 $object->update();
		 redirect($pageName."?msg=edit&page=".$_REQUEST['page']);
	}
	
	if(isset($_POST['btnAction']))
	{
	 	extract($_POST);
	 	
		switch($optAction)
	  	{
			case 0:
					$object->deleteSelect($chkAction);
					break;
			case 1:
					$object->statusUpdatePublish($chkAction);
					break;
			case 2:
				$object->statusUpdateUnPublish($chkAction);
	  	} 		  
	 	redirect($pageName."?msg=edit&page=".$_REQUEST['page']);
	}	
	
	if(isset($_GET['delete']))
	{			 
	  		$object->delete();
	  		redirect($pageName."?msg=del&page=".$_REQUEST['page']);
	}	
	
	if(isset($_GET['status']))
	{			 
		  	$object->status();
		  	redirect($pageName."?msg=status&page=".$_REQUEST['page']);		
	}
	
	if(isset($_GET['id']))
	{			
			$listEdit=$object->selectRecById();												
	}		
	
	$listRec=$object->paging();
    include("html/frmAdminUser.php");
 } 
?>