<?php
frmHeader($heading,$pageName);	
 if(isset($_REQUEST['btnAddCategory']) or isset($_REQUEST['id'])) { ?>
<div id="form_container">
<form action="<?=$pageName;?>" method="post" name="frmManage" onsubmit="return ValidateForm(this)">
	<fieldset>
    	<legend>User Details</legend>       
        <ul>
        	<li>
            	<label>Admin Name <span class="requiredt"> * </span> :</label>
            </li>
            <li>
            	<input name="txtAdminName" type="text" id="txtAdminName"  value="<?=$listEdit[0]['adminName'];?>">
            </li>
        </ul>
        <ul>
        	<li>
        	  <label>User Name <span class="requiredt"> * </span> :</label>
        	</li>
            <li>
              <input name="txtUserName" type="text" id="txtUserName"  value="<?=$listEdit[0]['adminUsername'];?>">
            </li>
        </ul>
        <ul>
        	<li>
        	  <label >Password <span class="requiredt"> * </span> :</label>
        	</li>
            <li><input name="txtPassword" type="text" id="txtPassword" value="<?=decryptPassword($listEdit[0]['adminPassword']);?>"/></li>
        </ul>
        <?php if(!isset($_REQUEST['id'])) {?>
        <ul>
        	<li>
        	  <label> Verify Password <span class="requiredt"> * </span> :</label>
        	</li>
            <li><input name="txtVerifyPassword" type="password" id="txtVerifyPassword" value="<?=$listEdit[0]['adminPassword'];?>"/></li>
        </ul>
		<?php }?>
        <ul>
        	<li>
        	  <label >Email <span class="requiredt"> * </span> :</label>
        	</li>
            <li><input name="txtEmail" type="text" id="txtEmail"  value="<?=$listEdit[0]['adminEmail'];?>"/></li>
        </ul>
         <?php if(!isset($_REQUEST['id'])) {?>
        <ul>
        	<li>
        	  <label >Registration Date :</label>
        	</li>
            <li><?php  echo date("d-m-Y");  ?></li>
        </ul>
        <?php }?>
         <ul>
        	<li>
        	   <label >&nbsp;</label>
        	</li>
            <li>
            	  <? frmButtons($heading);?>
            </li>
        </ul>             
    </fieldset>
     <?php if(isset($_REQUEST['id']))
	 {?>
     <input type=hidden name=Validation
                    value="Field=txtAdminName|Alias=Admin Name|Validate=Blank^
                    Field=txtUserName|Alias=User Name|Validate=Blank^
                    Field=txtPassword|Alias=Password|Validate=Blank^                
                    Field=txtEmail|Alias=Email Address|Validate=Email"/>
     <?php }
	 else
	 {?>
     	<input type=hidden name=Validation
                    value="Field=txtAdminName|Alias=Admin Name|Validate=Blank^
                    Field=txtUserName|Alias=User Name|Validate=Blank^
                    Field=txtPassword|Alias=Password|Validate=Blank^
                    Field=txtVerifyPassword|Alias=Verify Password|Validate=Blank^
                    Field=txtEmail|Alias=Email Address|Validate=Email^
                    Field=txtPassword|Alias=Verify Password|Validate=CONFIRMPASSWORD|CompareTo=txtVerifyPassword"/>     	
     <?php }?>                      
</form>
</div>
<?php 
	}
	else
	{
	frmMessage();
?>
<div class="paging">
    <?=$object->pagination;?>
</div>
<form action="<?=$pageName;?>" method="post" name="frmManageDetails" onsubmit="return ValidateForm(this)">
<? frmAction();?>
<div class="table_border">
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tabular">
  <tr>
    <th width="17%">Sr. No. </th>
    <th width="20%">Name</th>
    <th width="22%">Email</th>
    <th width="30%">Join Date</th>
    <th width="11%">Actions&nbsp;<input type="checkbox" id="selectAll" name="selectAll" onclick="check_all(this.form,this);"/></th>
  </tr>
  
   <?  
    if(count($listRec)>0)
	 {
      $colorflg=0;
	   for($e=0;$e<count($listRec);$e++)
	   {
		  if($colorflg==1)
		  { $colorflg=0;?>
  		  <tr class="odd" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='odd'">
   <?  }
   		else
		{	$colorflg=1;?>
		 <tr class="even" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='even'">
   <? } ?>
                <td><?=$e+1;?></td>
                <td><?=$listRec[$e]['adminName'];?></td>
                <td><?=$listRec[$e]['adminEmail'];?></td>
                <td><?=$listRec[$e]['adminJoinDate'];?></td>
                <td>
<?	if($listRec[$e]['id']!=1)
	{ ?>
	                <input type="checkbox" name="chkAction[]" id="chkAction[]"  value="<? echo $listRec[$e]['id'];?>" onclick="chkTotal(this.form)"/>&nbsp;
      <?php  
				if($listRec[$e]['status']=='0')
				{?>
                        <a href=""><img src="images/minus-circle.gif" width="16" height="16" alt="published"  border="0"/></a>
                    <?php }
					else
					{?>
                        <a href=""><img src="images/tick-circle.gif" width="16" height="16" alt="published"  border="0"/></a>
                    <?php }
	} ?>
     <a href="<?=$pageName;?>?id=<?php echo $listRec[$e]['id'];?>&page=<?=$_REQUEST['page'];?>"><img src="images/pencil.gif" width="16" height="16" alt="edit" border="0" /></a>
<?	if($listRec[$e]['id']!=1)
	{ ?>
    	<img src="images/close.png" width="16" height="16" alt="delete"  border="0" onclick="deleteAdmin(<?php echo $listRec[$e]['id'];?>,'<?php echo $listRec[$e]['adminUsername'];?>','Admin User','<?=$pageName;?>','<?=$_REQUEST['page'];?>')"/><? } ?>
           </td>
	     </tr>
  <? } }
  		else
		{?>
  		<tr>
        	<td colspan="5" align="center">
            	No Records Found...
            </td>
        </tr>
    <?php }?>    
  </table>
</div>
<input type=hidden name=Validation value="Field=optAction|Alias=Action|Validate=Combo"/>
</form>
<?php } ?>