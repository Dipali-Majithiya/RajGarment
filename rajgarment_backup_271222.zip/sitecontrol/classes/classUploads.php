<?php
global $db;
class uploads
	{
	   var $tablename='uploads';
	   var $id;
	   var $file_name;
	   var $file_type;
	   var $file_path;
	   var $status;
	   var $limit;
	   var $start;
       function uploads(){$this->db = new dbclass();}
	   
	   function insert()
	   {
	   			$sql = "insert into `$this->tablename` values('',																											
							   '$this->file_name',
							   '$this->file_type',
							   '$this->file_path',
							   '$this->status'
							    )";
								//echo $sql;die();		
					$this->db->insert($sql);
					$id=mysql_insert_id();
					return($id);
	   }
	   
	   function update()
	   {
	   
				if($this->file_path=="")
				{
					$sql = "";
					//echo $sql;die();
				}
				else
				{
					$sql = "update `$this->tablename` set
								`file_name`='$this->file_name',
								`file_type`='$this->file_type',
								`file_path`='$this->file_path',
								`status`='$this->status'
								 where `id`=$this->id";
								  //echo $sql;die();
					$this->db->edit($sql);
					return true;
				}
		}
							
		function select()
		{
		   $sql ="select * from `$this->tablename` order by id asc";//echo $sql;die();
		   $result=$this->db->select($sql);
		   return($result);
		}	

		function selectStatus()
		{
			$sql ="select * from `$this->tablename` where status=1 order by id asc";
			// echo $sql;die();
			return($this->pagingQuery($sql));
		}

		function selectStatusAll()
		{
			$sql ="select * from `$this->tablename` where status=1 order by id asc";
			 //echo $sql;die();
			$result=$this->db->select($sql);
			return($result);
		}
		
		function selectRecById()
		{
			$sql ="select * from `$this->tablename` 
				   where id='$this->id'";//echo $sql;die();
			   $result=$this->db->select($sql);
			   return($result);
		}
		
		function selectRecByIdStatus()
		{
			$sql ="select * from `$this->tablename` 
				   where id='$this->id' and status=1 order by id asc";//echo $sql;die();
			   $result=$this->db->select($sql);
			   return($result);
		}						
		
		function status()
		{
			$sql = "update `$this->tablename` set
						   `status`='$this->status'
							where `id`=$this->id";//echo $sql;die();	
					$this->db->edit($sql);		
					return true;
		}	
		
		function delete()
		{							 
				$sql="delete from `$this->tablename` 
					  where `id`=$this->id";//echo $sql;die();
				mysql_query($sql);	  
		}
		
		function sequenceUpdate()
		{
			$sql = "update `$this->tablename` set
						   `seqno`='$this->seqno'
							where `id`=$this->id";//echo $sql;die();	
					$this->db->edit($sql);		
					return true;
		}			
		
		/*update selected status publish*/	
		function statusUpdatePublish($chk)
		{
			for($i=0;$i<count($chk);$i++)
			{
				$id = $chk[$i];
				$sql = "update `$this->tablename` set
						`status`=1
						 where `id`='$id'";//echo $sql;die();	
						$this->db->edit($sql);		
			}
			return true;
		}	
		
		/*update selected status unpublish*/	
		function statusUpdateUnPublish($chk)
		{
			for($i=0;$i<count($chk);$i++)
			{
				$id = $chk[$i];
				$sql = "update `$this->tablename` set
							   `status`=0
								where `id`='$id'";//echo $sql;die();	
						$this->db->edit($sql);		
			}
			return true;
		}							
		
		/*delete the selected record*/	
		function deleteSelect($chk) 
		{
			for($i=0;$i<count($chk);$i++)
			{
				$id = $chk[$i];
				$sql="delete from `$this->tablename` where `id` = '$id'";
				$res = mysql_query($sql);
			}
			return true;
		}	
		/*...paging...*/
	
	function menuUplodeList()//order by adminid
	{		 
		if(isset($_POST['search']) && $_POST['search']=='Search' && $_POST['search_txt']!='')
		{
			$query = "select * from `$this->tablename` where (file_name LIKE '%".$_POST['search_txt']."%') order by id asc";			
		}
		else
	    {		
			extract($_POST);			
		
			if($sortClName!='')
			{				
				$query = 'select * from `uploads` order by '.$sortClName;			
			}
			else
			{			
				$query = 'select * from `uploads` order by id ';		
			}
		
			switch ($ascdsc)
			{
		  		case 0:
		  			$query = $query." asc";
				break;
		 		case 1:
		  			$query = $query." desc";
				break;
			}		
		}		 			
			$sql = $query;					   
		    $result=$this->db->select($sql);
		   	return($result);
	}
		
	function paging()
	{
		$pages = new Paging();
		$pages->sql ="select * from `$this->tablename`";
		
		$pages->page = isset($_REQUEST['page']) ? $_REQUEST['page'] : 1;
		$pages->limit = $this->limit;
		$pages->GeneratePaging();
		$this->pagination=$pages->pagination; 
		$result=$this->db->select($pages->sql);
		return($result);
	}
	
	function pagingQuery($sql)
	{
		$pages = new Paging();
		$pages->sql =$sql;
		$pages->page = isset($_REQUEST['page']) ? $_REQUEST['page'] : 1;
		$pages->limit = 16;
		$pages->parameters = $this->parameters;
		$pages->GeneratePaging();		
		$this->pagination=$pages->pagination; 
		$result=$this->db->select($pages->sql);
		return($result);
	}
	
	function pagingFrontQuery($sql)
	{
		$pages = new Paging();
		$pages->sql =$sql;
		$pages->page = isset($_REQUEST['page']) ? $_REQUEST['page'] : 1;
		$pages->limit = $this->limit;
		$pages->parameters = $this->parameters;
		$pages->GenerateFrontPaging();		
		$this->pagination=$pages->pagination; 
		$result=$this->db->select($pages->sql);
		return($result);
	}
}		
?>