<? 
include("html/frmTemplate.php");
function details($pageName,$object,$heading,$menuCatListEdit=""){?>
<form action="<?=$pageName;?>" method="post" name="frmManage" onsubmit="return ValidateForm(this)">
	<fieldset>
    	<legend>Category Details</legend>
        <ul>
        	<li>
            	<label>Category Position (Main/Sub) :</label>
            </li>
            <li>
            	<select name="optMenuPosition" id="optMenuPosition">
                    <option value="0">--Main Position--</option>
                    <?php 
						$menuMainCatList=$object->menuCategoryList();
					for($i=0;$i<count($menuMainCatList);$i++) { 
						if($menuMainCatList[$i]['id']!=$_GET['id']){
					?>
							<option value="<?=$menuMainCatList[$i]['id'];?>" <?php if($menuMainCatList[$i]['id']==$menuCatListEdit[0]['subcatid']){?> selected <?php }?>><?=$menuMainCatList[$i]['category_name'];?></option>
					<?php
						}
					 } 
					?>
                </select>
            </li>
        </ul>
        <ul>
        	<li>
        	  <label>Cagetory Name * :</label>
        	</li>
            <li>
              <input name="txtMenuName" type="text" id="txtMenuName" value="<?=$menuCatListEdit[0]['category_name'];?>" />
            </li>
        </ul>
        <ul>
        	<li>
        	  <label >Sequence No :</label>
        	</li>
            <li><input name="txtSeqNo" type="text" id="txtSeqNo" value="<?=$menuCatListEdit[0]['seq_no'];?>"/></li>
        </ul>
        <ul>
        	<li>
        	  <label >Meta Title : </label>
        	</li>
            <li>
            <input type="text" name="txtMetaTitle" id="txtMetaTitle" value="<?=$menuCatListEdit[0]['metaTitle'];?>" /></li>
        </ul>
        <ul>
        	<li>
        	  <label>Meta Description : </label>
        	</li>
            <li>
            <textarea  name="txtMetaDescription" id="txtMetaDescription" ><?=$menuCatListEdit[0]['metaDescription']; ?></textarea>           
            </li>
        </ul>
		<ul>
        	<li>
        	  <label>Meta Keywords :</label>
        	</li>
            <li>
            <textarea  name="txtMetaKeywords" id="txtMetaKeywords"><?=$menuCatListEdit[0]['metaKeywords']; ?></textarea>           
            </li>
        </ul>
	
         <ul>
        	<li>
        	   <label >&nbsp;</label>
        	</li>
            <li>
            	  <? frmButtons($heading);?> 
           </li>
        </ul>
        
                
    </fieldset> 
     <input type=hidden name=Validation 
        value="Field=txtMenuName|Alias=Menu Name|Validate=Blank^
               Field=txtMenuLink|Alias=Valid Menu Link|Validate=Blank"/>        
</form>
<? } function rowDisplay($pageName,$object,$heading,$menuMainCatListRec=""){?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tabular">
  <tr>
    <th width="7%">Id.</th>
    <th width="15%">Sequence. No.</th>
    <th width="59%">Cagetory / Sub Category Name</th>    
    <th width="19%">Actions&nbsp;
    <input type="checkbox" id="selectAll" name="selectAll" onclick="check_all(this.form,this);"/></th>
  </tr>
  
   <?  
    if(count($menuMainCatListRec)>0)
	 {
       for($e=0;$e<count($menuMainCatListRec);$e++){
	   ?>		 
		 <tr class="even" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='even'">         
                <td><?=$menuMainCatListRec[$e]['id'];?></td>
                <td>
                <input type="text" size="3" name="txtSeqNo[]" id="txtSeqNo" value="<?=$menuMainCatListRec[$e]['seq_no'];?>"/>
                <input type="hidden" name="categoryId[]" id="categoryId" value="<?=$menuMainCatListRec[$e]['id'];?>" size="3"/>
                </td>
                <td><?=$menuMainCatListRec[$e]['category_name'];?></td>                
                <td>
                 <?
				   	frmActionButton($menuMainCatListRec[$e]['id'],$menuMainCatListRec[$e]['status'],$pageName,$menuMainCatListRec[$e]['category_name'],$heading);
				?>	              
                </td>
	     </tr>
			<? 
				$object->id=$menuMainCatListRec[$e]['id'];
				$menuSubCatList=$object->menuSubCategoryList();
					if($menuSubCatList){ 
						for($i=0;$i<count($menuSubCatList);$i++){ 
            ?>
            		 <tr class="odd" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='odd'">
            <td><?=$menuSubCatList[$i]['id'];?></td>
                <td>
                <input type="text" size="3" name="txtSeqNo[]" id="txtSeqNo" value="<?=$menuSubCatList[$i]['seq_no'];?>"/> <input type="hidden" name="categoryId[]" id="categoryId" value="<?=$menuSubCatList[$i]['id'];?>" size="3"/>
                </td>
                <td style="padding-left:40px;"><?=$menuSubCatList[$i]['category_name'];?></td>                
                <td>
                <?
				   	frmActionButton($menuSubCatList[$i]['id'],$menuSubCatList[$i]['status'],$pageName,$menuSubCatList[$i]['category_name'],$heading);
				?>		               
                </td>
	     </tr>
         <?php }} ?>
  <? } } else {?>
  		<tr>
        	<td colspan="5" align="center">
            	No Records Found...
            </td>
        </tr>
    <?php }?>    
  </table>
<?php } ?>