<?php
include("template.php");
//	include("sitecontrol/inc/fileInclude.php"); 
//$menuListRec1=$objFrontMenu->menuCategoryListFront("top");	
// echo "<pre>"; print_r($menuListRec1);
function main()
{ 	
	include("sitecontrol/inc/clsObj.php"); 
	session_start(); ?>

<style type="text/css">
	td{
		line-height:25px;text-align:justify;font-size:12px;
	}
	.headingh1{
		font-size:24px;
	}
</style>
 	<h1 class="headingh1">Sitemap</h1>
<?php
	$menuListRec=$objFrontMenu->menuCategoryListFront("top");	
//	$menuListRec= $_SESSION['menu'];
// echo "<pre>"; print_r($menuListRec);
?>
<div style="margin-left:-12px;">

<table width="95%">
		<tr>
    		<td style="padding-left:50px;" valign="top"><table style="color:#000000;" >
		<?php 
		for($i=0;$i<count($menuListRec);$i++)
		{ 
			if($menuListRec[$i]['alias_name']!="")
			{
				$link = strtolower($menuListRec[$i]['alias_name']).".html";
			}
			else
			{				
				if($menuListRec[$i]['menuType']==3)
					$link = $menuListRec[$i]['menuUrl'];
				elseif($menuListRec[$i]['menuType']==2)
					$link = "content.php?id=".$menuListRec[$i]['id'];
			}?>
		<tr>
		<td align="left">
			 <?php
    			echo '<img src="images/contactus/sitearrow.png" />&nbsp;&nbsp;<a style="color:#3a335d;" href="'.$link.'">'.$menuListRec[$i]['menuName'].'</a>'; 

			if($menuListRec[$i]['id']==3)
			{
				$Category = $objProCat->menuCategoryList();		
				?>
            	<table style="margin-left:30px;" width="400" class="products">    
    			<?php
				for($t=0; $t<count($Category); $t++)
				{
					if($Category[$t]['alias_name']!="")
						$link = $Category[$t]['alias_name'].".html";
					else
						$link = "content.php?ctid=".$Category[$t]['id'];
				?>
          		<tr>
          			<td style="margin-left:100px!important;"><img src="images/contactus/sitearrow.png" /><a href="<?php echo $link; ?>" ><?=$Category[$t]['category_name'];?></a>
            	<? subCat($Category[$t]['id']); ?>
                	</td>
            	</tr>
          		<?php
            	}
				
				$rootproduct = $objProduct->selectRootProduct(); 
				for($m=0; $m<count($rootproduct); $m++)
				{ 
					if($rootproduct[$m]['alias_name']!="")
						$link = $rootproduct[$m]['alias_name'].".html";
					else
						$link = "content.php?pid=".$rootproduct[$m]['id'];
						
						if($rootproduct[$m]['product_name']!='')
						{
				?>
        		<tr>
                	<td style="margin-left:25px!important;"><img src="images/contactus/sitearrow.png" /><a href="<?php echo $link; ?>" ><?=$rootproduct[$m]['product_name'];?></a></td>
                </tr>
				<? } } ?>
    					</table>
        			</td>
        		</tr>
   				<? } } ?>
 			</table>
        </td>       
        <td valign="top">
        	<img height="300" src="images/contactus/sitemap.jpg" />
        </td>
    </tr>
</table>
</div>
<?php
} 
?>