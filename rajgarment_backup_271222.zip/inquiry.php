<?php
include("template.php");
function main()
{ 	
session_start();
?>
<script type="text/javascript">
<!--
function MM_validateForm() { //v4.0
  if (document.getElementById)
  {
    var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
    for(i=0; i<(args.length-2); i+=3)
	{ 
		test=args[i+2]; val=document.getElementById(args[i]);
      	if(val)
		{
			nm=val.name;
			if((val=val.value)!="")
			{
        		if(test.indexOf('isEmail')!=-1)
				{
					p=val.indexOf('@');
          			if(p<1 || p==(val.length-1))
						errors+='- '+nm+' must contain an e-mail address.\n';
        		}
				else if(test!='R')
				{
					num = parseFloat(val);
          			if(isNaN(val)) 
						errors+='- '+nm+' must contain a number.\n';
          			if(test.indexOf('inRange') != -1)
					{
						p=test.indexOf(':');
            			min=test.substring(8,p); max=test.substring(p+1);
            			if(num<min || max<num) 
							errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
      				}
				}
			}
			else if(test.charAt(0) == 'R') 
				errors += '- '+nm+' is required.\n';
			}
    	}
		if(errors)
			alert('The following error(s) occurred:\n'+errors);
    	document.MM_returnValue = (errors == '');
	}
}
//-->
</script>
<style>
.cap_status
{
	width: 350px;
	padding: 10px;
	font: 14px arial;
	color: #fff;
	background-color: #10853f;
	display: none;
}
.cap_status_error
{
	background-color: #bd0808;                
}
.inquiry td
{
	line-height:30px;
}

.headingh1
{
	font-size:24px;
}

.inputbox
{
	width:140px!important;
	border:1px solid #ccc!important;
}
</style>
    <h1 class="headingh1">Inquiry</h1>
    <form action="sendinquiry.php" method="post" enctype="multipart/form-data" name="inquiryFrm" onsubmit="MM_validateForm('Your_Name','','R','Your_Email','','RisEmail','City','','R','State','','R','Country','','R','Postal_Code','','R','Mobile','','R');return document.MM_returnValue">    
    <table width="100%" border="0" class="inquiry" >
    	<tr>
        	<td valign="top" width="45%">
                <table width="100%" border="0" cellspacing="5">
                  <tr>
                    <td valign="top" width="150">Your Name<font color="#FF0000">*</font></td>
                    <td valign="top" width="30">:</td>
                    <td valign="top"><input name="Your_Name" type="text" class="inputbox" id="Your_Name" value="<?=$_SESSION['enquiry']['Your_Name'];?>" /></td>
                  </tr>
                  <tr>
                    <td valign="top">Your Email<font color="#FF0000">*</font></td>
                    <td valign="top">:</td>
                    <td valign="top"><input name="Your_Email" type="text" class="inputbox" id="Your_Email" value="<?=$_SESSION['enquiry']['Your_Email'];?>" /></td>
                  </tr>
                  <tr>
                    <td valign="top">Company Name</td>
                    <td valign="top">:</td>
                    <td valign="top"><input type="text" class="inputbox" name="Your_Company_Name" value="<?=$_SESSION['enquiry']['Your_Company_Name'];?>" /></td>
                  </tr>
                  <tr>
                    <td valign="top">Website</td>
                    <td valign="top">:</td>
                    <td valign="top"><input type="text" class="inputbox" name="Website" value="<?=$_SESSION['enquiry']['Website'];?>" /></td>
                  </tr>
                  <tr>
                    <td valign="top">Street Address</td>
                    <td valign="top">:</td>
                    <td valign="top"><input type="text" class="inputbox" name="Street_Address" value="<?=$_SESSION['enquiry']['Street_Address'];?>" /></td>
                  </tr>
                  <tr>
                    <td valign="top">City<font color="#FF0000">*</font></td>
                    <td valign="top">:</td>
                    <td valign="top"><input name="City" type="text" class="inputbox" id="City" value="<?=$_SESSION['enquiry']['City'];?>" /></td>
                  </tr>
                  <tr>
                    <td valign="top" >State<font color="#FF0000">*</font></td>
                    <td valign="top" >:</td>
                    <td valign="top"><input name="State" type="text" class="inputbox" id="State" value="<?=$_SESSION['enquiry']['State'];?>" /></td>
                  </tr>
                  <tr>
                    <td valign="top">Postal Code<font color="#FF0000">*</font></td>
                    <td valign="top">:</td>
                    <td valign="top"><input type="text" class="inputbox" id="Postal_Code" name="Postal_Code" value="<?=$_SESSION['enquiry']['Postal_Code'];?>" /></td>
                  </tr>  
               </table>
			</td>
            <td valign="top" width="2%">&nbsp;
            	
          </td>
           
            <td valign="top" width="45%">
            
            	<table width="100%" border="0" cellspacing="5">
                      <tr>
                        <td width="150" valign="top" >Country<font color="#FF0000">*</font></td>
                        <td width="30" valign="top">:</td>
                        <td valign="top"><input name="Country" type="text" class="inputbox" id="Country" value="<?=$_SESSION['enquiry']['Country'];?>" /></td>
                      </tr>
                      <tr>
                        <td valign="top">Telephone<font color="#FF0000"></font></td>
                        <td valign="top">:</td>
                        <td valign="top"><input name="Telephone" type="text" class="inputbox" id="Telephone" value="<?=$_SESSION['enquiry']['Telephone'];?>" /></td>
                      </tr>
                      <tr>
                        <td valign="top">Mobile<font color="#FF0000">*</font></td>
                        <td valign="top">:</td>
                        <td valign="top"><input name="Mobile" type="text" class="inputbox" id="Mobile" value="<?=$_SESSION['enquiry']['Mobile'];?>" /></td>
                      </tr>
                      <!--
                      <tr>
                        <td valign="top">Attachment</td>
                        <td valign="top">:</td>
                        <td valign="top"><input type="file" class="file_upload" name="Attachment" /></td>
                      </tr>
                      -->  
                      <tr>
                        <td valign="top">Details</td>
                        <td valign="top">:</td>
                        <td valign="top"><textarea name="description" rows="3" class="inputbox"><?=$_SESSION['enquiry']['description'];?></textarea></td>
                      </tr>
                      <!--<tr>
                        <td valign="top">&nbsp;</td>
                        <td valign="top">&nbsp;</td>
                        <td valign="top"><img src="cap_bg1.jpg"/></td>
                      </tr>-->
                      <!--<tr>
                        <td valign="top">Enter Code<font color="#FF0000">*</font></td>
                        <td valign="top">:</td>
                        <td valign="top"><input name="Code" type="text" class="inputbox" id="Code" maxlength="6" /></td>
                      </tr>-->
                      <tr><td valign="top" colspan="3">&nbsp;</td></tr>
                        <tr>
                        <td valign="top">&nbsp;</td>
                        <td valign="top">&nbsp;</td>
                        <td valign="top"><input type="submit" style="font-size:13px; background-color:#3a335d;color:#FFFFFF;padding:6px;font-weight:bold;" class="submitbtn" value="Submit" name="submit" />
                <input type="reset" style="font-size:13px;background-color:#3a335d;color:#FFFFFF;padding:6px;font-weight:bold;" class="resetbtn" value="Clear" /></td>
                      </tr>
                      
                      
                </table>            
            </td>
            
		</tr>                          
	</table>
    <div class="bg"></div>
    
</form>
<p>&nbsp;</p>
<?php
} 
?>