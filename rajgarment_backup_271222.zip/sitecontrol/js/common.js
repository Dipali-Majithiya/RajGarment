total=0;
	function deleteAll(cid,caption,caption1,page,no)
		{			
			var msg="Want to delete "+ caption + " "+ caption1 +
			"\nYou can not undo after deleting"+
			"\n\nPress [Enter] or click [Ok] to delete"+
			"\nPress [Esc] or click on [Cancel] to cancel the operation";
			if(confirm(msg))
			{ 
				document.location=page+"?delete="+cid+'&page='+no;
			}			
		}	
	function deleteAdmin(cid,caption,caption1,page,no)
		{
				alert(no);
			if(cid=='1'){
				alert("You cannot delete admin user");
			}else{
				var msg="Want to delete "+ caption + " "+ caption1 +
				"\nYou can not undo after deleting any of the Admin User"+
				"\n\nPress [Enter] or click [Ok] to delete the Admin User"+
				"\nPress [Esc] or click on [Cancel] to cancel the operation";
				if(confirm(msg))
				{ 
					document.location=page+"?delete="+cid+'&page='+no;
				}
			}
		}		
	function check_all(Form_Obj,eventgiver)
		{		  
	    var ellen=Form_Obj.elements.length;		
		if(eventgiver.checked==true){
			for(var i=1;i<ellen;i++){
				if(Form_Obj.elements[i].name=="chkAction[]")
				Form_Obj.elements[i].checked=true;
			}
		}else if(eventgiver.checked==false){
			for(var i=1;i<ellen;i++){
				if(Form_Obj.elements[i].name=="chkAction[]")
				Form_Obj.elements[i].checked=false;
			}
		}
}	
function select_all(value)
		{		  
			var Form_Obj = document.forms['frmManageDetails'];
			var total =0;
			for(var i=1;i<Form_Obj.elements.length;i++)
			{
					if(Form_Obj.elements[i].type=="checkbox")
					{
						Form_Obj.elements[i].checked=value;
						total++;
					}
			}
			total--;
			if(!value) total=0;
				document.getElementById("total_selected").innerHTML=total;		
		}
function chkTotal(Form_Obj)		
		{
			total=0;
			for(var i=1;i<Form_Obj.elements.length;i++)
			{
					if(Form_Obj.elements[i].type=="checkbox")
					{
					if(Form_Obj.elements[i].checked==true)
					{						
						total++;
					}
					}
					 
			}
			document.getElementById("total_selected").innerHTML=total;
		}
function chkTotal(Form_Obj)		
		{
			total=0;
			for(var i=1;i<Form_Obj.elements.length;i++)
			{
					if(Form_Obj.elements[i].type=="checkbox")
					{
					if(Form_Obj.elements[i].checked==true)
					{						
						total++;
					}
					}
					 
			}
			document.getElementById("total_selected").innerHTML=total;
		}	
function ProperCase(obj)
{
	strTemp = trimAll(obj.value);
	strTemp = strTemp.toLowerCase()
	
	var test=""
	var isFirstCharOfWord = 1

	for (var intCount = 0; intCount < strTemp.length; intCount++)
		{
			var temp = strTemp.charAt(intCount)
			if (isFirstCharOfWord == 1)
				{
					temp = temp.toUpperCase()
				}
			test = test + temp
			if (temp == " ")
				{
					isFirstCharOfWord = 1
				}
			else isFirstCharOfWord = 0
		}
	obj.value = test
}		
		
function trimAll(sString)
{
	while (sString.substring(0,1) == ' '){
		sString = sString.substring(1, sString.length);
	}
	while (sString.substring(sString.length-1, sString.length) == ' ')
	{
		sString = sString.substring(0,sString.length-1);
	}
	return sString;
}


function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
		
		if(charCode ==45)
		{
			
		}
        else if (charCode > 31 && (charCode < 48 || charCode > 57))
		{
            return false;
		}

         return true;
      }