<?php 

	error_reporting(0);

	$obj_admin=new adminMaster();
	$objAdminMenu=new adminMenuMaster();
	$objFrontMenu=new userFrontMenuMaster();
	$objProCat=new pro_categories();
	$objProduct=new products();
	$objProduct1=new products1();
	$objPhotoGallery=new photo_gallery();
	$objSearch=new search();
	$objBanner=new banner();
	$objNews=new news();
	$objTest=new test();
	$objInquiry=new adminInquiry();
		
	$objPhotoCat=new photoCategory();
	$objPhotos=new Photos();
	
	$objSocialLinks = new social_links();
	
	$objUploads = new uploads();
	
	$objGlobalConfig = new golbalConfig(); // Global Configuration	
?>