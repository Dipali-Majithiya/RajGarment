<?php
include("inc/fileInclude.php");
include("inc/clsObj.php");

$days=1;
$m=20;
$C=6;

if($_POST['txtUserName']!="")
{
	$obj_admin->adminUsername=$_POST['txtUserName'];
	$obj_admin->adminPassword=encryptPassword($_POST['txtPassword']);
	$adminRec=$obj_admin->loginCheck();
}

$ip  = $_SERVER['REMOTE_ADDR']; 
$errors = "";

if(empty($txtUsername))
{
	$errors="Username is required";
}
if(empty($txtPassword))
{
	$errors.="\nPassword is required";
}
if(count($adminRec)==0)
{
	echo "<font color='#990000'><b>* * * Invalid Username and / or Password * * *</b></font>";
}
else
{
	//session_register('accessby');
	//session_register('memberid');
	//session_register('uid');

	$_SESSION['accessby']="admin";	

	if($_SESSION['accessby']=="admin")
	{
		$_SESSION['memberid']=$adminRec[0]['id'];
		$_SESSION['membername']=$adminRec[0]['adminUsername'];
	}
	
	elseif($_SESSION['accessby']=="head" || $_SESSION['accessby']=="executive" )
	{
		$_SESSION['memberid']=$adminRec[0]['id'];
		$_SESSION['membername']=$adminRec[0]['email'];
	}
	
	$_SESSION['uid']=$adminRec[0]['id'];
	echo "Please wait,redirecting...";
}
?>