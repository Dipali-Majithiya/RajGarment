<?php
include("template.php");
function main()
{
	include("inc/clsObj.php");
	$heading="News";	
	$object=$objNews;
	
	$pageName="codeManageNews.php";
	$object->limit=TOTAL_RECORDS;
	
	extract($_POST);
	$rnd=createRandomCode();
	
	$object->id=isset($_GET['uid']) ? $_GET['uid'] : ( isset($_GET['delete']) ? $_GET['delete'] : ( isset($_GET['id']) ? $_GET['id'] : $hid )) ;	
		
		if($_FILES['imageOriginal']['name']!="")
		{
			if(isset($hiddenImage))
			{
				unlink(NEWS_BIG_IMAGE.$hiddenImage);
				unlink(NEWS_SMALL_IMAGE.$hiddenImage);
			}
		}				
			   
		$object->newsTitle=$newsTitle;
		
		$newsDiscription=str_replace("\&quot;","", $newsDiscription);		
		$newsDiscription=str_replace('\\', '', $newsDiscription);				
		$newsDiscription=str_replace("\'","'", $newsDiscription);		
		$newsDiscription=str_replace("'","\'", $newsDiscription);	
		$object->newsDiscription=$newsDiscription;
		$object->newsLongDiscription=$newsLongDiscription;
		
		/*$object->Display_Home=isset($Display_Home) ? 1 : 0;*/
		$object->seqNo=$txtSeqNo;
		$object->status=$status;
		
		$wh = getimagesize($_FILES['imageOriginal']['tmp_name']);
		$w=$wh[0];
		$h=$wh[1];
									
		if($_FILES['imageOriginal']['name']!="")
		{		   			
				if($w>=NEWS_BIG_WIDTH && $h>=NEWS_BIG_HEIGHT)
				{
					$object->image=uploadImage("imageOriginal",$rnd.$_FILES['imageOriginal']['name'],NEWS_BIG_IMAGE,NEWS_BIG_WIDTH,NEWS_BIG_HEIGHT);
				}
				else
				{
					$object->image=uploadImage("imageOriginal",$rnd.$_FILES['imageOriginal']['name'],NEWS_BIG_IMAGE,'','');
				}
				
				if($w>=NEWS_SMALL_WIDTH && $h>=NEWS_SMALL_HEIGHT)
				{
					uploadImage("imageOriginal",$rnd.$_FILES['imageOriginal']['name'],NEWS_SMALL_IMAGE,NEWS_SMALL_WIDTH,NEWS_SMALL_HEIGHT);
				}
				else
				{
					uploadImage("imageOriginal",$rnd.$_FILES['imageOriginal']['name'],NEWS_BIG_IMAGE,'','');
				}
									
		    }
			else
			{				
					if(isset($hiddenImage))
					{
						  $object->image=$hiddenImage;	
     				}
					else
					{
						 $object->image=NULL;
					}			 	  
			}
		
		
		
		
			
			
			$object->status=isset($_GET['status']) ? $_GET['status'] : 1;
			
			if(isset($_POST['btnAdd']))
			{											
				$object->insert();
				redirect($pageName."?msg=add");				
			}
			
			if(isset($_POST['btnUpdate']))
			{							
				$object->update();
				redirect($pageName."?msg=edit");
			}			
			
			if(isset($_POST['btnAction']))
			{
		 		extract($_POST);
				switch($optAction)
		  		{
		  			case 0:
					$object->deleteSelect($chkAction);
    				redirect($pageName."?msg=del");
					break;
					
					case 1:
			 		$object->statusUpdatePublish($chkAction);
         			redirect($pageName."?msg=Publish");
			        break;
					
					case 2:
			        $object->statusUpdateUnPublish($chkAction);
					redirect($pageName."?msg=UnPublish");
					break;
					
					case 3:
					extract($_POST);
					for($i=0;count($categoryId)>$i;$i++)
					{
						$object->id=$categoryId[$i];
						$object->seqNo=$txtSeqNo[$i];
						$object->sequenceUpdate();				
					}	
					redirect($pageName."?msg=seq");					
		   		} 
	     	}						
	
			if(isset($_GET['id']))
			{					
					$editRec=$object->selectRecById();									
			}	
			
			if(isset($_GET['delete']))
			{				  	
				  $delRec=$object->selectRecById();
				  if($delRec[0]['image']!="")
				  	{					 
				  		unlink(NEWS_BIG_IMAGE.$delRec[0]['image']);
						unlink(NEWS_SMALL_IMAGE.$delRec[0]['image']);
					}			
				  $object->delete();
				  redirect($pageName."?msg=del");
			}	
			
			if(isset($_GET['status']))
			{			
			     $object->status();
				 redirect($pageName."?msg=status");		
			}
			
		// Sorting Start 

			if(isset($_REQUEST['editTblBool']))
		   		$editTblBool = $_REQUEST['editTblBool'];
			else
		   		$editTblBool=0;
		
			if(isset($_REQUEST['ascdsc']))
		   		$ascdsc = $_REQUEST['ascdsc'];
			else
		   		$ascdsc=0;
		
			if(isset($_REQUEST['sortClName']))
			   $sortClName = $_REQUEST['sortClName'];
			else
			   $sortClName="";
			
			if(isset($_REQUEST['offset']))
			   $offset=$_REQUEST['offset'];
			else
			   $offset=0;
		
		
		if($editTblBool!=1)
		{
			if($ascdsc==0)
				$ascdsc = 1;
			else
				$ascdsc = 0;
		}
		
		// Sorting End
			
	$listRec=$object->paging();	
	
    include("html/frmManageNews.php");
 } 
 ?>