<?php
include("template.php");
function main()
{
	include("inc/clsObj.php");
	$heading="Uploads";	
	$object=$objUploads;
	$pageName="codeUploads.php";
	$object->limit=TOTAL_RECORDS;
	
	extract($_POST);	
	
	/*echo "<pre>";
	print_r($_FILES);
	echo "</pre>";
	exit;*/
		
    $rnd=createRandomCode();
	$txtAreaDesc=$_POST['FCKeditor1'];					
	$txtAreaDesc=str_replace("\&quot;","", $txtAreaDesc);		
	$txtAreaDesc=str_replace('\\', '', $txtAreaDesc);				
	$txtAreaDesc=str_replace("\'","'", $txtAreaDesc);		
	$txtAreaDesc=str_replace("'","\'", $txtAreaDesc);		  				
	
	$object->id=isset($_GET['uid']) ? $_GET['uid'] : ( isset($_GET['delete']) ? $_GET['delete'] : ( isset($_GET['id']) ? $_GET['id'] : $hid )) ;

	$object->file_name=$_FILES['uploads']['name'];
	$object->file_type=$_FILES['uploads']['type'];

	if($_FILES['uploads']['name']!="")
		$uploadedfie=uploadFile("uploads",$_FILES['uploads']['name'],"../uploads/");
		$object->file_path="uploads/".$uploadedfie;

	if($_FILES['uploads']['name']=="")
	{
		if(isset($hiddenImage))
		{
				 $object->file_path=$hiddenImage;	
		}
		else
		{
				 $object->file_path=NULL;
		}
	}

	$object->status=isset($_GET['status']) ? $_GET['status'] : 1;
	
	if(isset($_POST['btnAdd']))
	{
		$object->insert();
		redirect($pageName."?msg=add");
	}
	
	if(isset($_POST['btnUpdate']))
	{
		if($object->file_path!="")
		{	
				$delRec=$object->selectRecById();
				unlink("../".$delRec[0]['file_path']);
		}
		$object->update();
		
		if(isset($_POST['page']))
		{
			$redirect = "?page=".$_POST['page']."&msg=edit"; 	
		}
		else
		{
			$redirect = "?msg=edit";	
		}		
		redirect($pageName.$redirect);
	}	
	
	if(isset($_POST['btnApply']))
	{
		if($object->file_path!="")
		{	
			$delRec=$object->selectRecById();
			unlink("../".$delRec[0]['file_path']);
		}
		$object->update();
		
		if(isset($_POST['page']))
		{
			$redirect = "?id=".$_POST['hid']."&page=".$_POST['page']; 	
		}
		else
		{
			$redirect = "?id=".$_POST['hid'];	
		}		
		redirect($pageName.$redirect);
	}		
	
	if(isset($_POST['btnAction']))
	{
		switch($optAction)
		{
			case 0:
					$object->deleteSelect($chkAction);
					redirect($pageName."?msg=del");
					break;
			case 1:
					$object->statusUpdatePublish($chkAction);
					redirect($pageName."?msg=Publish");
					break;
			case 2:
					$object->statusUpdateUnPublish($chkAction);
					redirect($pageName."?msg=UnPublish");
					break;
			case 3:
					for($i=0;count($categoryId)>$i;$i++)
					{
						$object->id=$categoryId[$i];
						$object->seqno=$txtSeqNo[$i];
						$object->sequenceUpdate();				
					}	
					redirect($pageName."?msg=seq");					
		} 
	}						
	
	if(isset($_GET['id']))
		$editRec=$object->selectRecById();									
	
	if(isset($_GET['delete']))
	{	
		$delRec=$object->selectRecById();	
		if($delRec[0]['file_path']!="")
		{	
			unlink("../".$delRec[0]['file_path']);
		}
		$object->delete();
		redirect($pageName."?msg=del");
	}
	
	if(isset($_GET['status']))
	{			
		$object->status();
		redirect($pageName."?msg=status");		
	}
	
	$listRec=$object->paging();
	$listRec=$object->menuUplodeList();		
    include("html/frmUploads.php");
}
?>
