<?
	$objProduct->id=$category[0]['id'];
?>
<h1 class="headingh1"><?=$category[0]['category_name'];?></h1>
<style type="text/css">
td,th{color:#000;}
th
{
	background:#4D437C;
	color:#fff;
	text-align:left;
	padding:5px;
}
#wrapper11 {display:table;float:left;width:200px;height:200px;border:1px solid #ccc;margin:0 15px 15px 0;overflow:hidden;}
#cell11 {display:table-cell; vertical-align:middle; height:200px; width:200px;}
.content11{text-align:center;}
.pagination_back .current11
{
	background:#4B4377;
	color:#fff;
	padding:5px;
	border:1px solid #333;
	font-weight:bold;
}
.pagination_back a
{
	background:#ccc;
	color:#000;
	padding:5px;
	border:1px solid #999;
	font-weight:bold;
	margin-right:3px;
}
</style>
<table width="100%">
  <tr><td><? subCat($category[0]['id']);//subProducts($category[0]['id']);?></td></tr> 
</table>