<?php	
function frmAction()
{?>
<div class="action">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="53%">
      	<a href="Javascript:select_all(true);">Select All</a> | 
            <a href="Javascript:select_all(false);">Deselect All</a> | <span id="total_selected">0</span> items selected</td>
    <?php /*?>  <td >
      	No. Of Records:
      <select name="optRecords" onchange="frmManageDetails.submit();">
          <option value="<?=TOTOTAL_RECORDS;?>">--Select No.--</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="10">10</option>
          <option value="20">20</option>
          <option value="30">30</option>
          <option value="50">50</option>           
	  </select>  	
        
      </td><?php */?>
      <td width="28%" align="right">
	  Action : 
      <select name="optAction">
          <option value="-1">--Select Action--</option>
          <option value="0">Delete</option>
          <option value="1">Published</option>
          <option value="2">Unpublished</option>
          <option value="3">Update Sequence</option>           
	  </select>
	  <input type="submit" class="button" onmouseover="this.className='button_hover'" onmouseout="this.className='button'" 
      value="Submit" name="btnAction" id="btnAction" />
	  </td>
    </tr>
  </table>
</div>
<? } 

function frmHeader($heading,$pageName)
{?>

<div style="padding:10px;background:url(images/header-back.gif);border:#999999 1px solid">
<form action="<?=$pageName;?>" method="post" name="frmAddRec">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="83%" class="title">
    <?php 
	  		if(isset($_REQUEST['btnAddCategory']))
			{ 
				echo "Manage ".$heading."&raquo; Add ".$heading;
			} 
		    else if( isset($_REQUEST['id']))
			{
				echo "Manage ".$heading."&raquo; Edit ".$heading;
			}
			else 
			{
				echo "Manage ".$heading;
			}	 
	    ?> 
	</td>
    <td width="17%">
    <?php if(isset($_REQUEST['btnAddCategory']) or isset($_REQUEST['id']))
	{ ?>
    	<input name="btnBack" id="btnBack"  type="submit" class="button" style="float:right;" onmouseover="this.className='button_hover'"        onmouseout="this.className='button'" value="Back"  />
    <?php } 
	else 
	{ 
		if((stristr($_SERVER['PHP_SELF'],"codeFrontMenu.php")!="" && MENU_EDIT==1) || (stristr($_SERVER['PHP_SELF'],         "codeFrontMenu.php")==""))
		{?>
        	<input name="btnAddCategory" id="btnAddCategory"  type="submit" class="button" style="float:right;" 
            onmouseover="this.className='button_hover'" onmouseout="this.className='button'" value="Add <?=$heading;?>"/><?php 
		}
	}?>
    </td>
  </tr>
</table>
</form>
</div>
<? } 

function  frmButtons($heading)
{?>
	  <?php if(isset($_GET['id']))
	  {?>
            <input type="submit" name="btnUpdate" value="Update <?=$heading;?>" class="button" onmouseover="this.className='button_hover'" onmouseout="this.className='button'" />
      <?php } 
	  else 
	  {?>
            <input type="submit" name="btnAdd" value="Add <?=$heading;?>" class="button" onmouseover="this.className='button_hover'" onmouseout="this.className='button'" />
      <?php } ?>  
      <input name="hid" type="hidden" value="<?=$_GET['id'];?>" />
      <input type="hidden" name="page" id="page" value="<?=$_REQUEST['page'];?>" />
<? } 

function  frmMessage()
{ ?>
<div style="width:100%; text-align:center; padding-bottom:5px; padding-top:0px;">
	        <?php if(isset($_GET['msg'])){ echo $mess[$_GET['msg']]; }?>
</div> 
<? } 

function  frmPaging($object)
{ ?>
<div class="paging">
   <table width="100%">
	<tr>
    	<td valign="top"><?=$object->pagination;?></td>
        
        <td valign="top" align="right">
        	<form action="" method="post">
            	<input type="text" name="search_txt" id="search_txt" style="padding:5px;border:1px solid #ccc;" />
                <input type="submit" name="search" id="search" value="Search" />
            </form>
        </td>
        
    </tr>
</table>
</div>
<? } 

function  frmActionButton($id,$status,$pageName,$itemname,$heading,$admin="")
{  

	if($_REQUEST['page']!='')
	{ 
	}
	else
	{
	  	$_REQUEST['page'] = 1;
	}
	
	if($admin!="")
	{
		if($id!=1) 
		{ ?> 
           
          <input type="checkbox" name="chkAction[]" id="chkAction[]"  value="<? echo $id;?>" onclick="chkTotal(this.form)"/>&nbsp;
      	  <?php  
				if($status=='0')
				{ ?>
                      <a href="?status=1&amp;uid=<? echo $id;?>&page=<?=$_REQUEST['page'];?>"><img src="images/minus-circle.gif" 					                       width="16" height="16" alt="published"  border="0"/></a>
                  <?php 
				}
				
				else
				{?>
                        <a href="?status=0&amp;uid=<? echo $id;?>&page=<?=$_REQUEST['page'];?>"><img src="images/tick-circle.gif"                        width="16" height="16" alt="published"  border="0"/></a>
                  <?php
                }
		} ?>
        
            <a href="<?=$pageName;?>?id=<?php echo $id;?>&page=<?=$_REQUEST['page'];?>"><img src="images/pencil.gif" 
            width="16" height="16" alt="edit" border="0" /></a>
		 
		 <? if($id!=1)
			{ ?>
            	<img src="images/close.png" width="16" height="16" alt="delete"  border="0" onclick="deleteAdmin(<?php echo $id;?>,'<?php                 echo $itemname;?>','<?=$heading;?>','<?=$pageName;?>','<?=$_REQUEST['page'];?>')"/><? } ?>
     	 <? }
		 	
			else
			{ ?>
            	<input type="checkbox" name="chkAction[]" id="chkAction[]"  value="<? echo $id;?>" onclick="chkTotal(this.form);"/>&nbsp;
                <?php  if($status=='0')
					   { ?>
                            <a href="?status=1&uid=<? echo $id;?>&page=<?=$_REQUEST['page'];?>"><img src="images/minus-circle.gif" 
                            width="16" height="16" alt="published"  border="0"/></a>
                 <?php }
				 	   else
					   { ?>
                            <a href="?status=0&uid=<? echo $id;?>&page=<?=$_REQUEST['page'];?>"><img src="images/tick-circle.gif" 
                            width="16" height="16" alt="published"  border="0"/></a>
                 <?php } ?>
                            <a href="<?=$pageName;?>?id=<?php echo $id;?>&page=<?=$_REQUEST['page'];?>"><img src="images/pencil.gif" 
                            width="16" height="16" alt="edit" border="0" /></a>
                    		<img src="images/close.png" width="16" height="16" alt="delete"  border="0" 
                            onclick="deleteAll(<?php echo $id;?>,'<?php echo $itemname;?>','<?=$heading;?>','<?=$pageName;?>')"/>
		<? } 
	}
function group()
{
	include("inc/clsObj.php");
	// Subscriber list ?>

	<form action="<?=$pageName;?>" method="post" name="groupfrmManageDetails"  >

	<div class="action">
  	<table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="53%">
<!--      	<a href="Javascript:select_all(true);">Select All</a> | 
            <a href="Javascript:select_all(false);">Deselect All</a> | <span id="total_selected">0</span> items selected -->      					      </td>
   
      <td width="28%" align="right">
	  Add to Group : 
      <select name="optGroup" id="optGroup">
          <option value="0">--Select Action--</option>          
          <?
		  		$group = $objGroup->selectStatus();				
				for($i=0; $i<count($group); $i++)
				{
					?><option value="<?php echo $group[$i]['id'];?>"><?php echo $group[$i]['group_name'];?></option><?
				}
		   ?>
       <!--   <option value="1">Published</option>
          <option value="2">Unpublished</option>
          <option value="3">Update Sequence</option>   -->        
	  </select>
	  
          <input type="submit" class="button" onmouseover="this.className='button_hover'" onmouseout="this.className='button'" 
          value="Submit" name="btnGroup" onclick="return addgroup();" id="btnGroup" />
	  </td>
      </tr>
  	</table>
</div>
<? }

function group_name()
{
	
include("inc/clsObj.php");

// Send News Letter

?>

<form action="<?=$pageName;?>" method="post" name="groupfrmManageDetails"  >

<div class="action">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="53%">
      	<a href="Javascript:select_all(true);">Select All</a> | 
            <a href="Javascript:select_all(false);">Deselect All</a> | <span id="total_selected">0</span> items selected      </td>
   
      <td width="28%" align="right">
	  Group : 
      <select onchange="return getgroup();" name="optGroup" id="optGroup">
          <option value="0">--Select Action--</option>
          
          <?
		  		$group = $objGroup->selectStatus();
				
				for($i=0; $i<count($group); $i++)
				{
					?><option value="<?php echo $group[$i]['id'];?>"><?php echo $group[$i]['group_name'];?></option><?
				}
		   ?>

       <!--   <option value="1">Published</option>
          <option value="2">Unpublished</option>
          <option value="3">Update Sequence</option>   -->        
	  </select>
	  <input type="submit" class="button" onmouseover="this.className='button_hover'" onmouseout="this.className='button'" 
      value="Submit" name="btnGroup" onclick="return addgroup();" id="btnGroup" />
	  </td>
    </tr>
  </table>
</div>

<? 
}

function frmApplyButtons($heading)
{
	   if(isset($_GET['id']))
	   {?>
            <input type="submit" name="btnApply" value="Apply Changes" class="button" onmouseover="this.className='button_hover'"            onmouseout="this.className='button'" />
    <? }
	   else 
	   {?>
            <input type="submit" name="btnAdd" value="Add <?=$heading;?>" class="button" onmouseover="this.className='button_hover'"            onmouseout="this.className='button'" />
    <? } ?>  
      		<input name="hid" type="hidden" value="<?=$_GET['id'];?>" />
      		<input type="hidden" name="page" id="page" value="<?=$_REQUEST['page'];?>" /><?
}?>