<? include("template.php");
function main()
{ 
	include("sitecontrol/inc/clsObj.php"); 
	$objFrontMenu->id=7;
	$recDet = $objFrontMenu->selectRecById(); 
?>
<script type="text/javascript">
<!--
function MM_validateForm() { //v4.0
  if (document.getElementById)
  {
    var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
    for(i=0; i<(args.length-2); i+=3)
	{ 
		test=args[i+2]; val=document.getElementById(args[i]);
      	if(val)
		{
			nm=val.name;
			if((val=val.value)!="")
			{
        		if(test.indexOf('isEmail')!=-1)
				{
					p=val.indexOf('@');
          			if(p<1 || p==(val.length-1))
						errors+='- '+nm+' must contain an e-mail address.\n';
        		}
				else if(test!='R')
				{
					num = parseFloat(val);
          			if(isNaN(val)) 
						errors+='- '+nm+' must contain a number.\n';
          			if(test.indexOf('inRange') != -1)
					{
						p=test.indexOf(':');
            			min=test.substring(8,p); max=test.substring(p+1);
            			if(num<min || max<num) 
							errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
      				}
				}
			}
			else if(test.charAt(0) == 'R') 
				errors += '- '+nm+' is required.\n';
			}
    	}
		if(document.getElementById("captchaResult").value=="")
			errors+='- Captcha Code is required\n';
		else if(document.getElementById('captchaResult').value != document.getElementById("captchaTotal").value)
			errors+='- Captcha Code is invalid\n';
			
		if(errors)
			alert('The following error(s) occurred:\n'+errors);
    	document.MM_returnValue = (errors == '');
	}
}
//-->
</script>
<div class="sub-banner-wthree">
		<h2><?=$recDet[0]['menuName'];?></h2>
	</div>
	<div class="contact-agile" id="contact">
			<div class="container">
				
				<!--<div class="col-md-6 col-sm-3 contact-left">
					<h4>CONTACT:</h4>
					<h5>Address:</h5>
					<ul>
					<li><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span></li>
					<p>G-1 New Laxmi Visnu Market<br>Opp Mahalaxmi Complex<br> Gheekanta,Ahmedabad<br> Gujarat 380001</p>
				</ul>

				</div>-->
				<div class="col-md-6 ">
				<h4 style="text-align:center; margin-top:20px;">CONTACT</h4>
				<div style="text-align:center; margin-top:43px;">
				<p><span class="glyphicon glyphicon-map-marker" aria-hidden="true" style="right:5px;"></span>G-1 New Laxmi Visnu Market<br>Opp Mahalaxmi Complex<br> Gheekanta,Ahmedabad<br> Gujarat 380001</p><br/>
				<p><strong>Mr.Nareshkumar Budhani</strong></p><br/>
				<p><span class="glyphicon glyphicon-earphone" aria-hidden="true" style="right:5px;"></span>+91 98983 94321</p><br/>
				<p><span class="glyphicon glyphicon-earphone" aria-hidden="true" style="right:5px;"></span>+91 98257 77900</p><br/>
				
				<p><span class="glyphicon glyphicon-envelope" aria-hidden="true" style="right:5px;"></span><a href="mailto:raj.fashion10@gmail.com">raj.fashion10@gmail.com</a></p>
				</div>
			</div>
				<!--<div class="col-md-6 col-sm-8 contact-middle">
					<h4>INQUIRY</h4>
					<form action="#" method="post">
						<input type="text" name="your name" placeholder="YOUR NAME">
						<input type="text" name="your email" class="c-email" placeholder="YOUR EMAIL">
						<input type="text" name="your contact" class="c-email" placeholder="YOUR CONTACT">
						<textarea  name="your message" placeholder="YOUR MESSAGE"></textarea>
						<div class="submit">
							<input type="submit" value="SEND MESSAGE">
						</div>
					<div class="clearfix"></div>
					</form>
				</div>-->
				<div class="col-md-6 ">
				<h4 style="text-align:center; margin-top:20px;">QUICK INQUIRY</h4>
				<form style="text-align:center;" action="sendinquiry.php" method="post"  enctype="multipart/form-data" onsubmit="MM_validateForm('Name','','R','Email','','RisEmail','Mobile','','R','Message','','R');return document.MM_returnValue">	
				<!--<form  action="#" method="post">-->
					<input type="text" placeholder="Name" name="Name" id="Name" ><br/>
					<input type="text" placeholder="Email"name="Email" id="Email"><br/>
					<input type="text" placeholder="Mobile"name="Mobile" id="Mobile"><br/>
					<textarea style="width:50%;" rows="3" name="Message" placeholder="Message" id="Message"></textarea><br/>
					<?
		$min_number = 1;
		$max_number = 15;
		$random_number1 = mt_rand($min_number, $max_number);
		$random_number2 = mt_rand($min_number, $max_number);
		$_SESSION['captchaSum']=$random_number1+$random_number2;
		//===========End of Captcha Code=========
		?>
		<p style="margin-top:20px;"><strong><?=$random_number1."+".$random_number2;?> :</strong></p> 
		<input type="text" placeholder="Enter Code" name="captchaResult" id="captchaResult" autocomplete="off">
		<input name="firstNumber" id="firstNumber" type="hidden" value="<?php echo $random_number1; ?>" />
		<input name="secondNumber" id="secondNumber" type="hidden" value="<?php echo $random_number2; ?>" />
		<input name="captchaTotal" id="captchaTotal" type="hidden" value="<?php echo $_SESSION['captchaSum']; ?>" /><br/>
					
					
					<input style="margin-top:20px;" type="submit" name="submit" value="Send">
				</form>
			</div>
				<!--<div class="col-md-1 col-sm-1 contact-right">
						<ul>
							<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>		
								
						</ul>
				</div>-->
			</div>
		</div>
		<br/>
		<div id="map">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3671.828946347573!2d72.58513631496795!3d23.03005198494919!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e8446214359f3%3A0x2d2c2b1aaba61f4d!2sRaj+Fashion!5e0!3m2!1sen!2sin!4v1510401666317" width="100%" height="350px" frameborder="0" style="border:0" allowfullscreen></iframe></div>
<? } ?>