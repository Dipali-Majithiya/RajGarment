<? 
include("template.php");
function main(){
include("sitecontrol/inc/clsObj.php");
$objSearch->search_text=$_GET['Search_Text'];		 	 
$result = $objSearch->getSearchResult();
?>
<style>
ul.search_result{}
</style>
<!--inner content div start-->
<h2>You searched result for  "<strong><?=$_REQUEST['Search_Text'];?></strong>".</h2>
<div class="inner_content">
    <ul class="search_result" style="margin-left:30px;">
    <? 	
        if(count($result['link'])>0){
            for($i=0;$i<count($result['link']);$i++){
    ?>
            <li style="height:20px;">
            	<a href="<?=$result['link'][$i];?>" title="<?=$result['title'][$i];?>" target="_<?=$result['target'][$i];?>">
					<?php echo $result['title'][$i];?>
                </a>
            </li>
    <? 		
			if(isset($_REQUEST['Search_Text']) && !empty($_REQUEST['Search_Text'])){
				$after = strstr($result['intro'][$i], $_REQUEST['Search_Text']);
				echo '<p style="padding-left:16px;">'.substr($after, 0, 100).'...</p><br /><br />';
			}
            } 
        }else{
        echo "Opps ! there is no matching result found, please try other keyword.";
    }
     ?>
    </ul>
</div>
<? } ?>