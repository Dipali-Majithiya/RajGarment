<?php
error_reporting(0);
	/*define("DB_NAME","rajgarment");
	define("SERVER_NAME","localhost");
	define("USER_NAME","root");
	define("PASSWORD","");*/
	
	define("DB_NAME","rajgarme_rajgarment");
	define("SERVER_NAME","localhost");
	define("USER_NAME","rajgarme_raj");
	define("PASSWORD","X;8vAJ#*9ZRM");
?>
