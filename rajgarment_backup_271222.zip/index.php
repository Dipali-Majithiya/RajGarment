<? include("template.php");
function main()
{ 
	include("sitecontrol/inc/clsObj.php"); 
	$objFrontMenu->id=1;
	$recDet = $objFrontMenu->selectRecById(); 
?>
<div class="banner-w3l">
		<h3>Life Is not Perfect But Your Outfit Can Be</h3>
		<label class="line"></label>
		<h2>JUST BE YOU</h2>
		<div class="arrow">
			<a href="#footer" class="scroll"><i class="fa fa-arrow-down" aria-hidden="true"></i></a>
		</div>
	</div>
	
	<div class="banner-btm-w3-agile">
		<div class="container">
			<div class="col-md-8 banner-btm-left-w3ls">
			<?=$recDet[0]['menuDesc'];?>
				<!--<h3>Welcome To Raj Garments</h3>
				<h4>The joy of dressing is an art</h4>
				 <p>Resurgent economies, set of complex and intriguing challenges to businesses operating in this environment. Along with the impending outlook towards business expansion and growth.</p>	
				 <p class="w3layouts">Resurgent economies, set of complex and intriguing challenges to businesses operating in this environment. Along with the impending outlook towards business expansion and growth.</p>-->
			</div>
			<!--<div class="col-md-6 banner-btm-right-w3ls">
				<div class="col-md-6 banner-btm-right-w3ls-one">
					<div class="gap">
						<div class="grid">
							<figure class="effect-apollo">
								<img src="images/jeans-1.jpg" alt=" " />							</figure>
						</div>
					</div>
					<div class="grid">
						<figure class="effect-apollo">
							<img src="images/cotton-jeans-1.jpg" />						</figure>
					</div>
				</div>
				<div class="col-md-6 banner-btm-right-w3ls-two">
					<div class="gap">
						<div class="grid">
							<figure class="effect-apollo">
								<img src="images/codroy-img-1.jpg" alt=" " />							</figure>
						</div>
					</div>
					<div class="grid">
						<figure class="effect-apollo">
							<img src="images/trouser-img1.jpg" alt=" " />						</figure>
					</div>
				</div>
			</div>-->
			<!--<div class="banner-btm-w3-agile">
		<div class="container">
			<div class="col-md-6 banner-btm-left-w3ls">
				<h3>Fashion And Style</h3>
				<h4>The joy of dressing is an art</h4>
				 <p>Resurgent economies, set of complex and intriguing challenges to businesses operating in this environment. Along with the impending outlook towards business expansion and growth.</p>	
				 <p class="w3layouts">Resurgent economies, set of complex and intriguing challenges to businesses operating in this environment. Along with the impending outlook towards business expansion and growth.</p>
			</div>-->
			<div class="col-md-4 banner-btm-right-w3ls">
				<div>
					<? if($recDet[0]['image']!="") 
					{ ?>
					<div class="grid">
					<figure class="effect-apollo">
					<img src="<?=FRONT_BIG_IMAGE.$recDet[0]['image'];?>" alt=" ">
					</figure>
						<!--<figure class="effect-apollo">
							<img src="images/bb2.jpg" alt=" ">
						</figure>-->
					</div>
					<? } ?>
				</div>
				<div>
					<div class="gap">
						<div class="grid">
							
						</div>
					</div>
					<div class="grid">
						
					</div>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>	
	</div>
	
	
	
	
	<div class="services-bottom">
		<div class="container">
			<h3>OUR PRODUCTS</h3>
			<div class="col-md-6 services-bottom-left"><?
			   $product = $objProduct->selectStatusAll(); // Root Products
	
				for($m=0; $m<3; $m++)
				{	
				
					if($product[$m]['alias_name']!="")
						$link = $product[$m]['alias_name'].".html";
					else
						$link = "content.php?pid=".$product[$m]['id'];
							
			 ?>  
			   
			   <div class="news-2">
					<div class="col-md-3 small-img">
						<a href="<?=$link;?>"><img style="width:135px; height:135px; margin-bottom:30px;" src="<?=PRODUCT_BIG_IMAGE.$product[$m]['image'];?>" alt=" " /></a>
					</div>
					<div class="col-md-9 news-text">
						<a href="<?=$link;?>"><h4 style="margin-bottom:5px;"><?=$product[$m]['product_name'];?></h4></a>
						<!--<h5>19/09/2016</h5>-->
						<div style="overflow:hidden; height:55px;">
						<?=$product[$m]['description'];?>
						</div>
						<!--<p>Donec eget pellentesque ipsum. Mauris dolor est,eget, varius volutpat ante. </p>-->
						<a href="<?=$link;?>" class="spcl">Read More</a> 
					</div>
					<div class="clearfix"></div>
				</div>
				<? } ?>
				<?php /*?><div class="news-3">
					<div class="col-md-3 small-img sb-gap">
						<a href="#"><img src="images/cottonjeans.jpg" alt=" " /></a>
					</div>
					<div class="col-md-9 news-text sb-gap">
						<a href="#"><h4>COTTON JEANS</h4></a>
						<!--<h5>21/09/2016</h5>-->
						<p>Vivamus condimentum fringilla varius. Duis ullamcorpe,vitae rutrum ex mattis</p>
						<a href="#" class="spcl">Read More</a> 
					</div>
					<div class="clearfix"></div>
				</div>
				
				<div class="news-3">
					<div class="col-md-3 small-img sb-gap">
						<a href="#"><img src="images/shirt-image1.jpg" alt=" " /></a>
					</div>
					<div class="col-md-9 news-text sb-gap">
						<a href="#"><h4>SHIRT</h4></a>
						<!--<h5>21/09/2016</h5>-->
						<p>Vivamus condimentum fringilla varius. Duis ullamcorpe,vitae rutrum ex mattis</p>
						<a href="#" class="spcl">Read More</a> 
					</div>
					<div class="clearfix"></div>
				</div><?php */?>
				
				
			</div>
			<div class="col-md-6 services-bottom-right">
				<?
			   $product = $objProduct->selectStatusAll(); // Root Products
	
				for($m=3; $m<count($product); $m++)
				{	
				
					if($product[$m]['alias_name']!="")
						$link = $product[$m]['alias_name'].".html";
					else
						$link = "content.php?pid=".$product[$m]['id'];
							
			 ?>  
			   
			   <div class="news-2">
					<div class="col-md-3 small-img">
						<a href="<?=$link;?>"><img style="width:135px; height:135px; margin-bottom:30px;" src="<?=PRODUCT_BIG_IMAGE.$product[$m]['image'];?>" alt=" " /></a>
					</div>
					<div class="col-md-9 news-text">
						<a href="<?=$link;?>"><h4 style="margin-bottom:5px;"><?=$product[$m]['product_name'];?></h4></a>
						<!--<h5>19/09/2016</h5>-->
						<div style="overflow:hidden; height:55px;">
						<?=$product[$m]['description'];?>
						</div>
						<!--<p>Donec eget pellentesque ipsum. Mauris dolor est,eget, varius volutpat ante. </p>-->
						<a href="<?=$link;?>" class="spcl">Read More</a> 
					</div>
					<div class="clearfix"></div>
				</div>
				<? } ?>
				
				
				<!--<div class="news-2">
					<div class="col-md-3 small-img">
						<a href="#"><img src="images/codroy.jpg" alt=" " /></a>
					</div>
					<div class="col-md-9 news-text">
						<a href="#"><h4> CORDUROY </h4></a>
						<!--<h5>19/09/2016</h5>
						<p>Donec eget pellentesque ipsum. Mauris dolor est,eget, varius volutpat ante. </p>
						<a href="#" class="spcl">Read More</a> 
					</div>
					<div class="clearfix"></div>
				</div>-->
				
				
				
				<!--<div class="news-3">
					<div class="col-md-3 small-img sb-gap">
						<a href="#"><img src="images/trouser.jpg" alt=" " /></a>
					</div>
					<div class="col-md-9 news-text sb-gap">
						<a href="#"><h4>TROUSER</h4></a>
						<!--<h5>21/09/2016</h5>
						<p>Vivamus condimentum fringilla varius. Duis ullamcorpe,vitae rutrum ex mattis</p>
						<a href="#" class="spcl">Read More</a> 
					</div>
					<div class="clearfix"></div>
				</div>-->
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	
<? } ?>