<? 
include("html/frmTemplate.php");
function details($pageName,$object,$heading,$listEdit=""){?>
<form action="<?=$pageName;?>" method="post" name="frmManage" enctype="multipart/form-data" onsubmit="return ValidateForm(this)"> 
   <fieldset>
    	<legend>News Details</legend>          	
		<ul>
        	<li>
            	<label >News Title <span class="requiredt"> * </span> :</label>
            </li>
            <li>
           	  	<input type="text" name="newsTitle" id="newsTitle" value="<?=$listEdit[0]['newsTitle'];?>">
            </li>
        </ul>  
        
        <ul>
        	<li>
        	  <label>Sequence No :</label>
        	</li>
            <li>
              <input name="txtSeqNo" type="text" id="txtSeqNo" value="<?=$listEdit[0]['seqNo']; ?>">
            </li>
        </ul>
         
        <ul>
        	<li>
            	<label>Short Description :</label>
            </li>
            <li>
                <textarea name="newsDiscription" id="newsDiscription"><?php echo $listEdit[0]['newsDiscription'];?></textarea>
            </li>
        </ul>
        <ul>
        	<li>
            	<label>Description :</label>
            </li>
            <li>
           	  	<!--<input type="text" name="caption" id="caption" value="<?php //echo $listEdit[0]['caption'];?>" size="50" > -->
                <!--<textarea name="caption" id="caption"><?php //echo $listEdit[0]['caption'];?></textarea>-->
                <?
                $path = pathinfo($_SERVER['SCRIPT_NAME']);
                $sBasePath = $path['dirname']."/editor/";
                $oFCKeditor = new FCKeditor('newsLongDiscription') ;
                $oFCKeditor->ToolbarSet = 'MyToolbar' ;
                $oFCKeditor->Height ='450';
                $oFCKeditor->BasePath	= $sBasePath ;
                $oFCKeditor->Config['SkinPath'] = $sBasePath . 'editor/skins/silver/' ;
                $oFCKeditor->Value	= $listEdit[0]['newsLongDiscription'];
                $oFCKeditor->Create() ;
            	?>
            </li>
        </ul> 
        
        <ul>
        	<li>
            	<label >Image :</label>
            </li>
            <li>
           	  <input type="file" name="imageOriginal" id="imageOriginal"/>
            </li>
        </ul>
        
         <?php if(isset($_REQUEST['id']))
		 {
		 ?>
         <ul>
        	<li>
        	  <label>&nbsp;</label>
        	</li>
            <li>
            	<img src="<?php echo NEWS_BIG_IMAGE.$listEdit[0]['image'];?>" alt="" width="300" />
                <input type="hidden" name="hiddenImage" id="hiddenImage" value="<?=$listEdit[0]['image'];?>"/>
            </li>
        </ul>
       <?php }?> 
        
        
        
        
        <ul>
        	<li>
            	<label >Display on Home Page :</label>
            </li>
           <li>
           	  	<input type="checkbox" name="Display_Home" id="Display_Home" <?=$menuCatListEdit[0]['Display_Home']==1?'checked':'';?>/>
            </li>
        </ul>            
     	<ul>
        	<li>
        	   <label >&nbsp;</label>
        	</li>
            <li>
            	  <? frmButtons($heading);?>
           </li>
    </ul>        
    </fieldset>   
    <!--<input type=hidden name=Validation value="Field=name|Alias=Banner Name|Validate=Blank^
 Field=caption|Alias=Caption|Validate=Blank"/>-->
 	<input type=hidden name=Validation value="Field=name|Alias=News Name|Validate=Blank"/>      
</form>
<? }function rowDisplay($pageName,$object,$heading,$listRec=""){
extract($_POST);
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tabular">
  <tr>
    <th width="6%" onclick="sortColumn('id');">Id.<div <? if($sortClName=='id' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='id' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?> ></div></th>     
    <th width="9%" onclick="sortColumn('seqNo');">Seq. No <div <? if($sortClName=='seqNo' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='seqNo' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?> ></div></th>  
    <th width="25%" onclick="sortColumn('newsTitle');">News Title <div <? if($sortClName=='newsTitle' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='newsTitle' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?> ></div></th> 
    <th width="47%" onclick="sortColumn('newsDiscription');">News Short Discription <div <? if($sortClName=='newsDiscription' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='newsDiscription' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?> ></div></th> 
    
    <th width="24%">Actions&nbsp;
    <input type="checkbox" id="selectAll" name="selectAll" onclick="check_all(this.form,this);"/></th>
  </tr>  
   <?  
    if(count($listRec)>0)
	 {
	 	$colorflg=0;
         for($e=0;$e<count($listRec);$e++){
	     if ($colorflg==1){		$colorflg=0;?>
  		 <tr class="odd" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='odd'">
  		 <? }	else {	$colorflg=1;?>
		 <tr class="even" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='even'">
  		 <? } ?>		        
                <td><?=$listRec[$e]['id'];?></td>  
                          <td>
                <input type="text" size="3" name="txtSeqNo[]" id="txtSeqNo" value="<?=$listRec[$e]['seqNo'];?>"/>
                                <input type="hidden" name="categoryId[]" id="categoryId" value="<?=$listRec[$e]['id'];?>" size="3"/>

                </td> 
                <td><?=$listRec[$e]['newsTitle'];?></td>
                 <td><?=$listRec[$e]['newsDiscription'];?></td>
                                                
                <td>
                <? frmActionButton($listRec[$e]['id'],$listRec[$e]['status'],$pageName,$listRec[$e]['newsTitle'],$heading);	 ?>
                </td>
	     </tr>	
           <?php }}else {?>
  		<tr>
        	<td colspan="5" align="center">
            	No Records Found...
            </td>
        </tr>
    <?php }?>    
  </table>
<? } ?>