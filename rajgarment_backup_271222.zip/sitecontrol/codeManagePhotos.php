<?php
include("template.php");
function main()
{
	$heading="Manage Photos";
	include("inc/clsObj.php");
	$page="codeManagePhotos.php";

	$object=$objPhotos;
	extract($_POST);
	
//echo "<pre>"; print_r($_POST); exit;
		if($_FILES['imageOriginal']['name']!="")
		{
			if(isset($productPhoto))
			{
				unlink(PHOTO_GALLERY_BIG.$productPhoto);
				unlink(PHOTO_GALLERY_SMALL.$productPhoto);
			}
		}						
		
		$rnd=createRandomCode();			
		
		$object->id=isset($_GET['uid']) ? $_GET['uid'] : ( isset($_GET['delete']) ? $_GET['delete'] : ( isset($_GET['id']) ? $_GET['id'] : $hid )) ;
		
		if($optMenuLevel=='')
		{
			$optMenuLevel ='';
		}
		
		$object->catgid=$optMenuLevel;
		//$object->name=$name;
		//$object->seqno=$txtSeqNo;
		//echo $object->seqno; exit;

			if($_FILES['imageOriginal']['name']!="")
			{
		   			$object->image=uploadImage("imageOriginal",$rnd.$_FILES['imageOriginal']['name'],PHOTO_GALLERY_BIG,PHOTO_GALLERY_BIG_WIDTH,'');
				uploadImage("imageOriginal",$rnd.$_FILES['imageOriginal']['name'],PHOTO_GALLERY_SMALL,PHOTO_GALLERY_SMALL_WIDTH,'');	
		    }
			else
			{				
					if(isset($productPhoto))
					{
						  $object->image=$productPhoto;	
     				}
					else
					{
						 $object->image=NULL;
					}			 	  
			}
			
			$object->status=isset($_GET['status']) ? $_GET['status'] : 1;
			
			if(isset($_POST['btnAdd']))
			{											
				$object->insert();
				redirect($page."?msg=add");				
			}
			if(isset($_POST['btnUpdate']))
			{							
				$object->update();
				redirect($page."?msg=edit");
			}			
			if(isset($_POST['btnAction']))
			{
		 		extract($_POST);
		 		switch($optAction)
		  		{
		  			case 0:
					$object->deleteSelect($chkAction);
    				redirect($page."?msg=del");
					break;
					
					case 1:
			 		$object->statusUpdatePublish($chkAction);
         			redirect($page."?msg=Publish");
			        break;
					
					case 2:
			        $object->statusUpdateUnPublish($chkAction);
					redirect($page."?msg=UnPublish");
					break;		
					
					case 3:
					extract($_POST);
					for($i=0;count($categoryId)>$i;$i++)
					{
						$object->id=$categoryId[$i];
						$object->seqno=$txtSeqNo[$i];
						$object->sequenceUpdate();				
					}				
					redirect($page."?msg=seq");	
		   		} 
	    	}						
			
			if(isset($_GET['id']))
			{					
					$listEdit=$object->selectRecById();									
			}	
			if(isset($_GET['delete']))
			{				  	
				$delRec=$object->selectRecById();	
				
				if($delRec[0]['image']!="")
				{					 
					unlink(PHOTO_GALLERY_BIG.$delRec[0]['image']);
					unlink(PHOTO_GALLERY_SMALL.$delRec[0]['image']);
				}	
				$object->delete();
				redirect($page."?msg=del");
			}	
			if(isset($_GET['status']))
			{			
			     $object->status();
				 redirect($page."?msg=status");		
			}
	
	// Sorting Start 
	
	if(isset($_REQUEST['editTblBool']))
	   $editTblBool = $_REQUEST['editTblBool'];
	else
	   $editTblBool=0;
	
	if(isset($_REQUEST['ascdsc']))
	   $ascdsc = $_REQUEST['ascdsc'];
	else
	   $ascdsc=0;
	
	if(isset($_REQUEST['sortClName']))
	   $sortClName = $_REQUEST['sortClName'];
	else
	   $sortClName="";
	
	if(isset($_REQUEST['offset']))
	   $offset=$_REQUEST['offset'];
	else
	   $offset=0;
	
	if($editTblBool!=1)
	{
		if ($ascdsc==0)
			$ascdsc = 1;
		else
			$ascdsc = 0;
	}	
	// Sorting End				
	$listRec=$object->paging();	
    include("html/frmManagePhotos.php");
}	

function display($cid,$n,$cat="") 
{
		include("inc/clsObj.php");		
		$objProjects->id=$cid;
	    $menuSubCatList=$objProjects->menuSubCategoryList();
	    $n+=2;
	    
		for($i=0;$i<count($menuSubCatList);$i++)
		{?>
			<option value="<?=$menuSubCatList[$i]['id'];?>"<? if($menuSubCatList[$i]['id']==$cat){?>selected<? }?> ><?php echo str_repeat("&nbsp;",$n).$menuSubCatList[$i]['name'];?></option>	    
    	<? display($menuSubCatList[$i]['id'],$n); 
		}
}
?>