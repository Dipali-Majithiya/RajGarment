<?php
function SendEmail($to,$from,$subject,$msg)
{
    $mail_subject = $subject;
	$message = $msg;
	$mail_to = $to;
	$mail_from = $from;
    $headers = "From:".$mail_from;
	
	mail($mail_to, $mail_subject, $message, $headers);
}
?>