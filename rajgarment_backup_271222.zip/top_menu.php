<ul class="nav navbar-nav">
  <?php
  
   include("functions.php");
 
	$menuListRec=$objFrontMenu->menuCategoryListFront("top");
	for($i=0;$i<count($menuListRec);$i++)
	{ 
		// Menu Link
			
			if($menuListRec[$i]['menuType']==3)
				$link = $menuListRec[$i]['menuUrl'];
			elseif($menuListRec[$i]['menuType']==2)
			{				
				$link = "content.php?id=".$menuListRec[$i]['id'];
			}
		
		// Main menu list
		
		$objFrontMenu->id=$menuListRec[$i]['id'];
		$menucount = $objFrontMenu->menuSubCategoryListFront();	// Submenu List
		
		// Menu item(s)
			
		
		if($menuListRec[$i]['id']==3)
		{ ?>
		<li class="dropdown mega-dropdown act">
		<a href="<?=$link;?>" class="dropdown-toggle" data-toggle="dropdown" target="<?=$menuListRec[$i]['menuTargetWindow'];?>"> <?=$menuListRec[$i]['menuName'];?> <span class="caret"></span></a><?	
		} 
		else
		{
		?>
  		<li><a href="<?=$link;?>" target="<?=$menuListRec[$i]['menuTargetWindow'];?>" data-hover="<?=$menuListRec[$i]['menuName'];?>"> <?=$menuListRec[$i]['menuName'];?></a><?
		}
					
		if(count($menucount)>0)
		{				
			menuSubMenu($menuListRec[$i]['id']); // Submenu				
		}
		// Category and Products	 
 
	if($menuListRec[$i]['id']==3)
	{
		?><div class="dropdown-menu mega-dropdown-menu codes-menu">
		<ul><?
				$Categories = $objProCat->menuCategoryList();	 // Main Category List
							
				for($t=0; $t<count($Categories); $t++)
				{																			
						if(count($Categories)>0)
						{	
							if($Categories[$t]['alias_name']!="")
								$link = $Categories[$t]['alias_name'].".html";
							else
								$link = "content.php?ctid=".$Categories[$t]['id'];?>
                                <li>
                                <a id="category_list" href="<?php echo $link; ?>"><?php echo $Categories[$t]['category_name'];?></a>
								<?		 
									menuSubCat($Categories[$t]['id']);  // Sub Category List
                                    menuSubProducts($Categories[$t]['id']);  // Sub Products of Category
								?>
							  	</li>
							  	<?
						}		
				}
							
				$rootproduct = $objProduct->selectRootProduct(); // Root Products
	
				for($m=0; $m<count($rootproduct); $m++)
				{	
				
					if($rootproduct[$m]['alias_name']!="")
						$link = $rootproduct[$m]['alias_name'].".html";
					else
						$link = "content.php?pid=".$rootproduct[$m]['id'];
							
					if($rootproduct[$m]['product_name']!='')
					{
						?><li><a href="<?php echo $link; ?>" ><?php echo $rootproduct[$m]['product_name']; ?></a></li><?
					}
				} ?>
		</ul></div><?
	} 
} ?>
</li>
</ul>