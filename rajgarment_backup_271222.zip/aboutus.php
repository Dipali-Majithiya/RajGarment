<? include("template.php");
function main()
{ 
	include("sitecontrol/inc/clsObj.php"); 
	$objFrontMenu->id=2;
	$recDet = $objFrontMenu->selectRecById(); 
?>
<div class="sub-banner-wthree">
		<h3><?=$recDet[0]['menuName'];?></h3>
	</div>

<div class="about-w3layouts">
	
	<div class="banner-btm-w3-agile">
		<div class="container">
			<div class="col-md-8 banner-btm-left-w3ls">
				<h3 style="color:#0194da;"><?=$recDet[0]['menuName'];?></h3>
				<?=$recDet[0]['menuDesc'];?>
				<?php /*?><h4 style="color:#000;">Raj Garment</h4>
				
				 <p>Resurgent economies, set of complex and intriguing challenges to businesses operating in this environment. Along with the impending outlook towards business expansion and growth.</p>	
				 <p class="w3layouts">Resurgent economies, set of complex and intriguing challenges to businesses operating in this environment. Along with the impending outlook towards business expansion and growth.</p><?php */?>
			</div>
			
			<div class="col-md-4 banner-btm-right-w3ls">
				<div>	
					
					<? if($recDet[0]['image']!="") 
					{ ?>
					<div class="grid">
					<figure class="effect-apollo">
					<img src="<?=FRONT_BIG_IMAGE.$recDet[0]['image'];?>" alt=" ">
					</figure>
						<!--<figure class="effect-apollo">
							<img src="images/bb2.jpg" alt=" ">
						</figure>-->
					</div>
					<? } ?>
						<!--<figure class="effect-apollo">
							<img src="images/bb2.jpg" alt=" ">
						</figure>-->
					
				</div>
			</div>
			<div class="clearfix"></div>
		</div>	
	</div>
	
	</div>
	
	 <script src="js/responsiveslides.min.js"></script>
			     <script>
			    // You can also use "$(window).load(function() {"
			    $(function () {
			      // Slideshow 4
			      $("#slider4").responsiveSlides({
			        auto: true,
			        pager:false,
			        nav:true,
			        speed: 500,
			        namespace: "callbacks",
			        before: function () {
			          $('.events').append("<li>before event fired.</li>");
			        },
			        after: function () {
			          $('.events').append("<li>after event fired.</li>");
			        }
			      });
			
			    });
			  </script>

<? } ?>