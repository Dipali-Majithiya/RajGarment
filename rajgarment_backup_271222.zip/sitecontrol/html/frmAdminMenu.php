<? 
include("html/frmTemplate.php");
function details($pageName,$object,$heading,$menuCatListEdit="")
{?>
<form action="<?=$pageName;?>" method="post" name="frmManage" onsubmit="return ValidateForm(this)">
	<fieldset>
    	<legend>Menu Details</legend>
        <ul>
        	<li>
            	<label>Menu Position :</label>
            </li>
            <li>
            	<select name="optMenuPosition" id="optMenuPosition">
                    <option value="0">--Main Position--</option>
                    <? 
					$menuMainCatList=$object->menuCategoryList();
					for($i=0;$i<count($menuMainCatList);$i++)
					{ ?>
                        <option value="<?=$menuMainCatList[$i]['id'];?>"<?php if($menuMainCatList[$i]['id']==$menuCatListEdit[0]['adminMenuSubId']){?> selected <?php }?>>
                            <?=$menuMainCatList[$i]['adminMenuName'];?>
                        </option>
                 <? } ?>
                </select>
            </li>
        </ul>
        <ul>
        	<li>
        	  <label>Menu Name <span class="requiredt"> * </span> :</label>
        	</li>
            <li>
              <input name="txtMenuName" type="text" id="txtMenuName" value="<?=$menuCatListEdit[0]['adminMenuName'];?>" />
            </li>
        </ul>
        <ul>
        	<li>
        	  <label>Sequence No :</label>
        	</li>
            <li><input name="txtSeqNo" type="text" id="txtSeqNo" value="<?=$menuCatListEdit[0]['seqNo'];?>"/></li>
        </ul>
        <ul>
        	<li>
        	  <label>Link <span class="requiredt"> * </span> :</label>
        	</li>
            <li>
            <input name="txtMenuLink" type="text" id="txtMenuLink"  value="<?=$menuCatListEdit[0]['adminMenuLink'];?>"/>
            </li>
        </ul>
         <ul>
        	<li>
        	   <label >&nbsp;</label>
        	</li>
            <li>
            	  <? frmButtons($heading);?> 
           </li>
        </ul>        
    </fieldset> 
     <input type=hidden name=Validation 
        value="Field=txtMenuName|Alias=Menu Name|Validate=Blank^
               Field=txtMenuLink|Alias=Valid Menu Link|Validate=Blank"/>        
</form>
<? } 

function rowDisplay($pageName,$object,$heading,$menuMainCatListRec="")
{?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tabular">
  <tr>
    <th width="17%">Id.</th>
    <th width="20%">Seq. No.</th>
    <th width="22%">Menu</th>    
    <th width="11%">Actions&nbsp;<input type="checkbox" id="selectAll" name="selectAll" onclick="check_all(this.form,this);"/></th>
  </tr>
  
   <?  
    if(count($menuMainCatListRec)>0)
	{
       for($e=0;$e<count($menuMainCatListRec);$e++)
	   {
	   ?>		 
		 <tr class="even" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='even'">         
                <td><?=$menuMainCatListRec[$e]['id'];?></td>
                <td>
                <input type="text" size="3" name="txtSeqNo[]" id="txtSeqNo" value="<?=$menuMainCatListRec[$e]['seqNo'];?>"/>
                <input type="hidden" name="categoryId[]" id="categoryId" value="<?=$menuMainCatListRec[$e]['id'];?>" size="3"/>
                </td>
                <td><?=$menuMainCatListRec[$e]['adminMenuName'];?></td>                
                <td>
                 <?
				   	frmActionButton($menuMainCatListRec[$e]['id'],$menuMainCatListRec[$e]['status'],$pageName,$menuMainCatListRec[$e]['adminMenuName'],$heading);
				?>	              
                </td>
	     </tr>
			<? 
				$object->id=$menuMainCatListRec[$e]['id'];
				$menuSubCatList=$object->menuSubCategoryList();
					if($menuSubCatList)
					{ 
						for($i=0;$i<count($menuSubCatList);$i++)
						{ 
            ?>
            		 <tr class="odd" onmouseover="Javascript:this.className='rowhover'" onmouseout="Javascript:this.className='odd'">
            <td><?=$menuSubCatList[$i]['id'];?></td>
                <td>
                <input type="text" size="3" name="txtSeqNo[]" id="txtSeqNo" value="<?=$menuSubCatList[$i]['seqNo'];?>"/> <input type="hidden" name="categoryId[]" id="categoryId" value="<?=$menuSubCatList[$i]['id'];?>" size="3"/>
                </td>
                <td style="padding-left:40px;"><?=$menuSubCatList[$i]['adminMenuName'];?></td>                
                <td>
                <?
				   	frmActionButton($menuSubCatList[$i]['id'],$menuSubCatList[$i]['status'],$pageName,$menuSubCatList[$i]['adminMenuName'],$heading);
				?>		               
                </td>
	     </tr>
         <?php }} ?>
  <? }  }
  		else
		{?>
  		<tr>
        	<td colspan="5" align="center">
            	No Records Found...
            </td>
        </tr>
   <?php }?>    
  </table>
<?php } ?>