<?php


	frmHeader($heading,$pageName);	
  if(isset($_REQUEST['btnAddCategory']) or isset($_REQUEST['id'])) { ?>
<div id="form_container">
<? details($pageName,$object,$heading,$editRec);?>
</div>
<?php 
	} else {
		frmMessage();
		frmPaging($object);
		
		if(basename($_SERVER['PHP_SELF'])=='codeManageUser.php')
		{
		  group(); 
		}

?>
<form action="<?=$pageName;?>" method="post" name="frmManageDetails" onSubmit="return ValidateForm(this)">
<?php 	frmAction(); ?>
<div class="table_border">	
	<?	rowDisplay($pageName,$object,$heading,$listRec);?>
</div>
<input type=hidden name=Validation value="Field=optAction|Alias=Action|Validate=Combo"/>

</form>



<?php } ?>