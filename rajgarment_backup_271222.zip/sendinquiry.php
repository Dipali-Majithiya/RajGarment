<?php
session_start();

include("sitecontrol/inc/fileInclude.php");
include("sitecontrol/inc/clsObj.php");
/*$cap = 'notEq';
if($_POST['Code']==$_SESSION['cap_code'])
{
	// Captcha verification is Correct. Do something here!
	$cap = 'Eq';
}
else
{
	// Captcha verification is wrong. Take other action
	$_SESSION['enquiry'] = $_POST;
	$cap  = '<script type="text/javascript">';
	$cap .= 'alert("You have enter invalid security code.");';
	$cap .= 'document.location="inquiry.html";';
	$cap .= '</script>';
	echo $cap; 
}*/

	/*$heading="Inquiry";
	$pageName="sendinquiry.php";
	$object=$objInquiry;
	$object->limit=TOTAL_RECORDS;
extract($_REQUEST);	
    
	$object->id=isset($_GET['uid']) ? $_GET['uid'] : ( isset($_GET['delete']) ? $_GET['delete'] : ( isset($_GET['id']) ? $_GET['id'] : $hid  )) ;
	$object->Name=$Your_Name;
	$object->Email=$Your_Email;
	$object->CompanyName=$Your_Company_Name;
	$object->Website=$Website;
	$object->Address=$Street_Address;
	$object->City=$City;
	$object->State=$State;
	$object->PostalCode=$Postal_Code;
	$object->Country=$Country;
	$object->Telephone=$Telephone;
	$object->Mobile=$Mobile;
	$object->Detail=$description;
	$object->status=isset($_GET['status']) ? $_GET['status'] : 0;*/	
		
	if(isset($_POST['submit']))
	{
		//$object->insert();	
	/*	redirect($pageName."?msg=add");			
	}*/

extract($_REQUEST);
//$obj_admin->id=1;
//$recAdmin=$obj_admin->selectRecById();
$msg='<TABLE cellpadding=5 cellspacing="7" width=700 align=left border=1  bordercolor="#CCCCCC" style="border-collapse:collapse;">
		<TBODY>
        	<TR>
            	<TD>Name : </TD>
				<TD colspan=3>'.$_POST['Name'].'</td> 
			</TR>
			<TR>
            	<TD>Email : </TD>
				<TD colspan=3>'.$_POST['Email'].'</td> 
			</TR>
			<TR>
            	<TD>Mobile : </TD>
				<TD colspan=3>'.$_POST['Mobile'].'</td> 
			</TR>
			<TR>
            	<TD>Description : </TD>
				<TD colspan=3>'.$_POST['Message'].'</td> 
			</TR>
      </TBODY>
      </TABLE>';

//echo $msg;
//exit;
//$to = $recAdmin[0]['adminEmail'];
//if($cap=="Eq"){
//$to = "webdeveloper.resolute@gmail.com";
$to = "raj.fashion10@gmail.com";
$from = "info@rajgarment.com";

	$headers  = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
	$headers .= "To:$to\r\n";
	$headers .= "From:$from\r\n";
	
	unset($_SESSION['enquiry']);
	
	mail($to,"Inquiry from : ".$_POST['Name'],$msg,$headers);
		
?>
<script type="text/javascript">   
   alert("Thank you for sending your inquiry")
   document.location="index.html";
</script><?

} 
else
{

extract($_REQUEST);
//$obj_admin->id=1;
//$recAdmin=$obj_admin->selectRecById();
$msg='<TABLE cellpadding=5 cellspacing="7" width=700 align=left border=1  bordercolor="#CCCCCC" style="border-collapse:collapse;">
		<TBODY>
        	<TR>
            	<TD>Name : </TD>
				<TD colspan=3>'.$_POST['name'].'</td> 
			</TR>
			<TR>
            	<TD>Email : </TD>
				<TD colspan=3>'.$_POST['email'].'</td> 
			</TR>
			<TR>
            	<TD>Mobile : </TD>
				<TD colspan=3>'.$_POST['mobile'].'</td> 
			</TR>
			<TR>
            	<TD>Description : </TD>
				<TD colspan=3>'.$_POST['message'].'</td> 
			</TR>
      </TBODY>
      </TABLE>';

//echo $msg;
//exit;
//$to = $recAdmin[0]['adminEmail'];
//if($cap=="Eq"){
//$to = "webdeveloper.resolute@gmail.com";
$to = "raj.fashion10@gmail.com";
$from = "info@rajgarment.com";

	$headers  = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
	$headers .= "To:$to\r\n";
	$headers .= "From:$from\r\n";
	
	unset($_SESSION['enquiry']);
	
	mail($to,"Inquiry from : ".$_POST['Name'],$msg,$headers);
	
?>
<script type="text/javascript">   
   alert("Thank you for sending your inquiry")
   document.location="index.html";
</script>
<? } ?>