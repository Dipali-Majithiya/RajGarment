<?php
global $db;
class products1
	{
	   var $tablename='products1';
	   var $id;
	   var $catid;
	   var $seqNo;
	   var $product_name;
	   var $alias_name;
	   var $price;
	   var $description;
	   var $size;
	   var $image;	  
	   var $new_arrival;
	   var $hot_product;
	   var $metaTitle;  
	   var $metaDescription;
	   var $metaKeywords;
	   var $status;
	   var $limit;
	   var $start;
       function products1(){$this->db = new dbclass();}
	   function insert()
	   {	
	   			$sql = "insert into `$this->tablename` values('',																											
							   '$this->catid',
							   '$this->seqNo',
							   '$this->product_name',
							   '$this->alias_name',
							   '$this->size',
							   '$this->price',
							   '$this->description',
							   '$this->image',
							   '$this->new_arrival',
							   '$this->hot_product',
							   '$this->metaTitle',  
							   '$this->metaDescription',
							   '$this->metaKeywords',
							   '$this->status'
							    )";
								//echo $sql;die();		
					$this->db->insert($sql);
					$id=mysql_insert_id();
					products::insert_images($id);
					return($id);
			}
			
	   // Multiple Image Code //	
	   function insert_images($insert_id)
	   {
		   
	   	$number_of_file_fields = 0;
		$number_of_uploaded_files = 0;
		$number_of_moved_files = 0;
		$uploaded_files = array();
		/**
		 * we get a $_FILES['images'] array ,
		 * we procee this array while iterating with simple for loop 
		 * you can check this array by print_r($_FILES['images']); 
		*/
		 
		 $temp_count = count($_FILES['images']['name']);
		 for($i=0; $i<count($_FILES['images']['name']); $i++)
		 {
		 	if(!empty($_FILES['images']['name'][$i]))
			{
				$upload['name'][$i]=$_FILES['images']['name'][$i];
				$upload['tmp_name'][$i]=$_FILES['images']['tmp_name'][$i];
				$upload['type'][$i]=$_FILES['images']['type'][$i];
				$upload['error'][$i]=$_FILES['images']['error'][$i];
				$upload['size'][$i]=$_FILES['images']['size'][$i];
				
				// Added for width and height
				$wh = getimagesize($_FILES['images']['tmp_name'][$i]);
				$upload['width'][$i]=$wh[0];
				$upload['height'][$i]=$wh[1];
			}
		 }
	   	   
		 for($j=0; $j<$temp_count; $j++)
		 {
		 		$uploaded_titles[] = $_POST['img_title'][$j];
				$uploaded_sequence[] = $_POST['img_sequence'][$j];
				$rnd=createRandomCode();
				if(!empty($upload['name'][$j]))
				{
					$_FILES['images']['name']=$upload['name'][$j];
					$_FILES['images']['tmp_name']=$upload['tmp_name'][$j];
					$_FILES['images']['type']=$upload['type'][$j];
					$_FILES['images']['error']=$upload['error'][$j];
					$_FILES['images']['size']=$upload['size'][$j];	
					
					// Added for width and height
					
 				 	if($upload['width'][$j]>=PRODUCT_BIG_WIDTH)
					{
						$objectBigImage=uploadImage("images", $rnd.$_FILES['images']['name'], PRODUCT_BIG_IMAGE, PRODUCT_BIG_WIDTH,'');
					}
					else
					{
						$objectBigImage=uploadImage("images", $rnd.$_FILES['images']['name'], PRODUCT_BIG_IMAGE, '','');
					}
					
					if($upload['width'][$j]>=PRODUCT_SMALL_WIDTH)
					{
						$objectSmallImage=uploadImage("images", $rnd.$_FILES['images']['name'], PRODUCT_SMALL_IMAGE, PRODUCT_SMALL_WIDTH,'');

					}
					else
					{
						$objectSmallImage=uploadImage("images", $rnd.$_FILES['images']['name'], PRODUCT_SMALL_IMAGE, '','');
					}
				
					$sql = "insert into `product_img` values('',																											
								   '$insert_id',
								   '".$objectSmallImage."',
								   '$uploaded_sequence[$j]',
								   '$uploaded_titles[$j]'
									)";
									//echo $sql; exit;
					$this->db->insert($sql);
				}
		 }
		 return true;
	   }
	   
	   function update_images($id)
	   {
		$number_of_file_fields = 0;
		$number_of_uploaded_files = 0;
		$number_of_moved_files = 0;
		$uploaded_files = array();
		$upload_directory = 'test_upload/'; //set upload directory
		/**
		 * we get a $_FILES['images'] array ,
		 * we procee this array while iterating with simple for loop 
		 * you can check this array by print_r($_FILES['images']); 
		 */
		$temp_count = count($_FILES['images']['name']);
		for($i=0; $i<count($_FILES['images']['name']); $i++)
		{
			if(!empty($_FILES['images']['name'][$i]))
			{
				$upload['name'][$i]=$_FILES['images']['name'][$i];
				$upload['tmp_name'][$i]=$_FILES['images']['tmp_name'][$i];
				$upload['type'][$i]=$_FILES['images']['type'][$i];
				$upload['error'][$i]=$_FILES['images']['error'][$i];
				$upload['size'][$i]=$_FILES['images']['size'][$i];
				
				// Added for width and height
				$wh = getimagesize($_FILES['images']['tmp_name'][$i]);
				$upload['width'][$i]=$wh[0];
				$upload['height'][$i]=$wh[1];
			}
			
		}
		
		for($j=0; $j<$temp_count; $j++)
		{
				$uploaded_titles[] = $_POST['img_title'][$j];
				$uploaded_sequence[] = $_POST['img_sequence'][$j];
				$rnd=createRandomCode();
				if(!empty($upload['name'][$j]))
				{
					$_FILES['images']['name']=$upload['name'][$j];
					$_FILES['images']['tmp_name']=$upload['tmp_name'][$j];
					$_FILES['images']['type']=$upload['type'][$j];
					$_FILES['images']['error']=$upload['error'][$j];
					$_FILES['images']['size']=$upload['size'][$j];	
					
					// Added for width and height
														
					if($upload['width'][$j]>=PRODUCT_BIG_WIDTH)
					{
						$objectBigImage=uploadImage("images", $rnd.$_FILES['images']['name'], PRODUCT_BIG_IMAGE, PRODUCT_BIG_WIDTH,'');
					}
					else
					{
						$objectBigImage=uploadImage("images", $rnd.$_FILES['images']['name'], PRODUCT_BIG_IMAGE, '','');
					}
					
					if($upload['width'][$j]>=PRODUCT_SMALL_WIDTH)
					{
						$objectSmallImage=uploadImage("images", $rnd.$_FILES['images']['name'], PRODUCT_SMALL_IMAGE, PRODUCT_SMALL_WIDTH,'');

					}
					else
					{
						$objectSmallImage=uploadImage("images", $rnd.$_FILES['images']['name'], PRODUCT_SMALL_IMAGE, '','');
					}
					
					$sql = "insert into `product_img` values('',																											
							   '$id',
							   '".$objectSmallImage."',
							   '$uploaded_sequence[$j]',
							   '$uploaded_titles[$j]'
								)";
									//echo $sql; exit;
					$this->db->insert($sql);
				}
		}
		return true;
	   }
	   
	   function getImages($id)
	   {
		$sql ="select * from `product_img` where product_id=".$id." ORDER BY img_sequence";//echo $sql;die();
		$result=$this->db->select($sql);
		return($result);
	   }
	   
	   function selectDelRecById($img)
	   {
		$sql="delete from `product_img` 
				  where `img_id`=$this->id";//echo $sql;die();
			mysql_query($sql);
			unlink(PRODUCT_BIG_IMAGE.$img);
			unlink(PRODUCT_SMALL_IMAGE.$img);
	   }
	   
	   function updateRecById($img_id, $title, $seq)
	   {
		$sql = "update `product_img` set
							`img_sequence`='$seq',
							`img_title`='$title'
							 where `img_id`=$img_id";
							  //echo $sql;die();	
					$this->db->edit($sql);
	   }
	   // End Multiple Image Code /
	   
	   function update()
	   {
				$sql = "update `$this->tablename` set
								`catid`='$this->catid',
								`seqNo`='$this->seqNo',
								`product_name`='$this->product_name',
								`alias_name`='$this->alias_name',
								`size`='$this->size',
								`image`='$this->image',
								`description`= '$this->description',
								`new_arrival`='$this->new_arrival',
								`hot_product`='$this->hot_product',
								`metaTitle`='$this->metaTitle',  
								`metaDescription`='$this->metaDescription',
								`metaKeywords`='$this->metaKeywords',
								`status`='$this->status'
								 where `id`=$this->id";
								  //echo $sql;die();	
						$this->db->edit($sql);
						products::update_images($this->id);		
						return true;
		}
							
		function select()
		{
				 $sql ="select * from `$this->tablename` order by seqNo asc";//echo $sql;die();
    			   $result=$this->db->select($sql);
	 		       return($result);
		}	

		function selectStatus()
		{
			$sql ="select * from `$this->tablename` where status=1 order by seqNo asc";
			// echo $sql;die();
			return($this->pagingQuery($sql));
		}

		function selectStatusAll()
		{
			$sql ="select * from `$this->tablename` where status=1 order by seqNo asc";
			 //echo $sql;die();
			$result=$this->db->select($sql);
			return($result);
		}
			
		function selectCountStatus()
		{
			$sql ="select count(*) as total from `$this->tablename` where category_id='$this->category_id' and status=1 order by seqNo asc";
			//echo $sql;die();
			$result=$this->db->select($sql);
			return($result);
		}	
		function selectNewArrivalStatus($all="")
		{
			if($all==1)
			{
					$sql ="select * from `$this->tablename` where status=1 and new_arrival=1 order by seqNo asc";
					 return($this->pagingQuery($sql));
			}
			else
			{
				$sql ="select * from `$this->tablename` where status=1 and new_arrival=1 order by rand() limit 0,4";
				 $result=$this->db->select($sql);
				  return($result);
			}
		}
		function selectNewArrivalCountStatus()
		{
			$sql ="select count(*) as total from `$this->tablename` where status=1 and new_arrival=1 order by seqNo asc";
			$result=$this->db->select($sql);
			return($result);
		}	
		function selectNewArrivalBrandStatus()
		{
			$sql ="select * from `$this->tablename` where status=1 and new_arrival=1 and brand_id='$this->brand_id' order by seqNo asc";//echo $sql;die();
			return($this->pagingQuery($sql));
		}	
		function selectNewArrivalBrandCountStatus()
		{
			$sql ="select count(*) as total from `$this->tablename` where status=1 and new_arrival=1 and brand_id='$this->brand_id'";//echo $sql;die();
			$result=$this->db->select($sql);
			return($result);
		}		
		function selectBestDealStatus($all="")
		{
			if($all==1)
			{
					$sql ="select * from `$this->tablename` where status=1 and best_deal=1";
					return($this->pagingQuery($sql));
			}
			else
			{
					$sql ="select * from `$this->tablename` where status=1 and best_deal=1 order by rand() limit 0,4";
					$result=$this->db->select($sql);
					return($result);
			}	
		}			
		function selectBestDealCountStatus()
		{	
			$sql ="select count(*) as total from `$this->tablename` where status=1 and best_deal=1";
			$result=$this->db->select($sql);
			return($result);
		}	
		function selectBestDealBrandStatus()
		{
			$sql ="select * from `$this->tablename` where status=1 and best_deal=1 and brand_id='$this->brand_id'";
			//echo $sql;die();
			return($this->pagingQuery($sql));
		}		
		function selectBestDealBrandCountStatus()
		{
			$sql ="select count(*) as total from `$this->tablename` where status=1 and best_deal=1 and brand_id='$this->brand_id'";//echo $sql;die();
			$result=$this->db->select($sql);
			return($result);
		}						
		function searchStatus($query)
		{
			if($query==1)
			{	
				$sql ="select * from `$this->tablename` where category_id='$this->category_id' and status=1 and brand_id='$this->brand_id'";
			}				
			else
			{
				$sql ="select * from `$this->tablename` where category_id='$this->category_id' and status=1";
			}	
			//echo $sql;die();
			return($this->pagingQuery($sql));
		}
		function searchCountStatus($query)		
		{
			if($query==1)
			{	
				$sql ="select count(*) as total from `$this->tablename` where category_id='$this->category_id' and status=1 and brand_id='$this->brand_id'";
			}				
			else
			{
				$sql ="select count(*) as total from `$this->tablename` where category_id='$this->category_id' and status=1";
			}	
			$result=$this->db->select($sql);
			return($result);	
		}
		function mainSearchStatus($query)
		{
			if($query==1)
			{	
			$sql ="select * from `$this->tablename` where name like '%$this->name%' and status=1 and brand_id='$this->brand_id'";
			}				
			else
			{
				$sql ="select * from `$this->tablename` where name like '%$this->name%' and status=1 order by seqNo asc";
			}	
			//echo $sql;die();
			return($this->pagingQuery($sql));
		}			
		function selectRecById()
		{
			$sql ="select * from `$this->tablename` 
				   where id='$this->id'";//echo $sql;die();
			   $result=$this->db->select($sql);
			   return($result);
		}
		function selectImageRecById()
		{
			$sql ="select * from `product_img` 
			   where product_id='$this->id'";//echo $sql;die();
		   	$result=$this->db->select($sql);
		   	return($result);
		}
		/*
		function selectDelRecById($img)
			{
				$sql="delete from `product_img` 
						  where `img_id`=$this->id";//echo $sql;die();
					mysql_query($sql);
					unlink(PRODUCT_BIG_IMAGE.$img);
			}
		*/	
		function selectRecByCategoryId()
			{
				$sql ="select * from `$this->tablename` 
					   where catid='$this->catid' and status=1 order by seqNo asc";
				   // echo $sql;die();
				   $result=$this->db->select($sql);
	 		       return($result);
			}	
		function selectRecByIdStatus()
			{
				$sql ="select * from `$this->tablename` 
					   where id='$this->id' and status=1 order by seqNo asc";//echo $sql;die();
				   $result=$this->db->select($sql);
	 		       return($result);
			}						
		function status()
			{
				$sql = "update `$this->tablename` set
							   `status`='$this->status'
								where `id`=$this->id";//echo $sql;die();	
						$this->db->edit($sql);		
						return true;
			}	
		function delete()
			{							 
					$sql="delete from `$this->tablename` 
						  where `id`=$this->id";//echo $sql;die();
					mysql_query($sql);	  
			}	
		function sequenceUpdate()
			{
				$sql = "update `$this->tablename` set
	  						   `seqno`='$this->seqno'
							    where `id`=$this->id";//echo $sql;die();	
						$this->db->edit($sql);		
						return true;
			}			
		/*update selected status publish*/	
		function statusUpdatePublish($chk)
			{
				for($i=0;$i<count($chk);$i++)
						{
							$id = $chk[$i];
							$sql = "update `$this->tablename` set
									`status`=1
									 where `id`='$id'";//echo $sql;die();	
									$this->db->edit($sql);		
	  				    }
			    return true;
			}	
		/*update selected status unpublish*/	
		function statusUpdateUnPublish($chk)
			{
				for($i=0;$i<count($chk);$i++)
						{
							$id = $chk[$i];
							$sql = "update `$this->tablename` set
										   `status`=0
											where `id`='$id'";//echo $sql;die();	
									$this->db->edit($sql);		
	  				    }
			    return true;
			}							
		/*delete the selected record*/	
		function deleteSelect($chk) 
			{
				for($i=0;$i<count($chk);$i++)
						{
							$id = $chk[$i];
							$sql="delete from `$this->tablename` where `id` = '$id'";
	     					$res = mysql_query($sql);
						}
				return true;
			}	
		/*...paging...*/
	function paging()
	{
		$pages = new Paging();
		$pages->sql ="select * from `$this->tablename` order by seqNo asc";
		
		$pages->page = isset($_REQUEST['page']) ? $_REQUEST['page'] : 1;
		$pages->limit = $this->limit;
		$pages->GeneratePaging();
		$this->pagination=$pages->pagination; 
		$result=$this->db->select($pages->sql);
		return($result);
	}
	function pagingQuery($sql)
	{
		$pages = new Paging();
		$pages->sql =$sql;
		$pages->page = isset($_REQUEST['page']) ? $_REQUEST['page'] : 1;
		$pages->limit = 16;
		$pages->parameters = $this->parameters;
		$pages->GeneratePaging();		
		$this->pagination=$pages->pagination; 
		$result=$this->db->select($pages->sql);
		return($result);
	}
	
	
		function pagingFrontQuery($sql)
	{
		$pages = new Paging();
		$pages->sql =$sql;
		$pages->page = isset($_REQUEST['page']) ? $_REQUEST['page'] : 1;
		$pages->limit = 12;
		$pages->parameters = $this->parameters;
		$pages->GenerateFrontPaging();		
		$this->pagination=$pages->pagination; 
		$result=$this->db->select($pages->sql);
		return($result);
	}
	
   function addToCart($pid,$qty)
	{	
		unset($cart);
		$cart = array("id"=>array(), 
					  "name"=>array(), 	
					  "qty"=>array(),
					  "unit"=>array(),
					  "price"=>array());		
		$cart=$_SESSION['cart'];	
		  		
	    $sql="SELECT * FROM `$this->tablename` WHERE id=".$pid." and status=1";
		$rs=$this->db->select($sql);			
		$found=false;	
		for($col=0;$col<count($cart['id']);$col++){
			if($cart['id'][$col]==$pid){
				$cart['qty'][$col] = $cart['qty'][$col]+$qty;
				$qty = $cart['qty'][$col];			
				$cart['price'][$col] = ($rs[0]['price'] * $cart['qty'][$col]);
				$found=true;
				break;
			}
		}
		if(!$found){
			$i=count($cart['id']);	
			$cart['id'][$i] = $pid; 								
			$cart['name'][$i] = $rs[0]['name'];
			$cart['qty'][$i] = $qty;
			$cart['unit'][$i] = $rs[0]['price'];
		    $cart['price'][$i] = ($rs[0]['price'] * ($qty)); 			
		}
		
		$_SESSION['cart']=$cart;		
		return $_SESSION['cart'];
	}		
 function updateCart($qty, $index)
	{
		$cart=$_SESSION['cart'];
		$cart['qty'][$index] = $qty;
		$sql="SELECT * FROM `$this->tablename` WHERE id=".$cart['id'][$index]." and status=1";
		$rs=$this->db->select($sql);
		$cart['price'][$index] = floatval($cart['qty'][$index] * $rs[0]['price']);	
		$_SESSION['cart']=$cart;		
		return $cart;
	}
 
 function remove($index)
 	{
		$cart=$_SESSION['cart'];	
		$tempcart = array("id"=>array(),"name"=>array(),"qty"=>array(),"unit"=>array(),"price"=>array());		  
		for($col=0,$tempcol=0;$col<count($cart['id']);$col++,$tempcol++){
				if($col != $index){
					$tempcart['id'][$tempcol]=$cart['id'][$col];
					$tempcart['name'][$tempcol]=$cart['name'][$col];
					$tempcart['qty'][$tempcol]=$cart['qty'][$col];	
					$tempcart['unit'][$tempcol]=$cart['unit'][$col];			
					$tempcart['price'][$tempcol]=$cart['price'][$col];								
				}
			} 
		$_SESSION['cart']=$tempcart;		
		unset($cart,$tempcart);
		return $_SESSION['cart'];			
	}
	
	
	function prod_cat($ctid)
	{
	
		$sql ="select * from `$this->tablename` where catid='$ctid' and status=1 order by seqNo asc";
//			echo $sql; //exit;					
		 $result=$this->db->select($sql);
		 return($result);

	}			   			
	
	function selectRootProduct()
			{
				$sql ="select * from `$this->tablename` where catid='0' and status=1 order by seqNo asc";
				 //echo $sql;die();
    			$result=$this->db->select($sql);
				return($result);
			}
			
			// Alias
			
			function selectRecByAlias()
			{
				$sql ="select * from `$this->tablename` where alias_name='$this->alias_name' order by seqNo asc";
					   //echo $sql;die();
				   $result=$this->db->select($sql);
	 		       return($result);
			}
							
			function selectRecords($pvar)
			{
			//	$sql ="select distinct count(p.alias_name),count(pc.alias_name),count(mm.alias_name) from products as p, pro_categories as pc, menumgr as mm where (p.alias_name = '".$pvar."') or (pc.alias_name = '".$pvar."') or (mm.alias_name = '".$pvar."')  ";
			
			
			$sql = "SELECT alias_name,id, COUNT(*) AS tes FROM menumgr WHERE alias_name='".$pvar."' GROUP BY alias_name HAVING COUNT(*) >= 1 union SELECT alias_name,id, COUNT(*) AS pro FROM products WHERE alias_name='".$pvar."' GROUP BY alias_name HAVING COUNT(*) >= 1 union SELECT alias_name,id, COUNT(*) AS pro FROM pro_categories WHERE alias_name='".$pvar."' GROUP BY alias_name HAVING COUNT(*) >= 1";
			
				// echo $sql;die();
    			$result=$this->db->select($sql);
		   return($result);
			}
			
			function selectHotProductStatus($all="")

			{

				if($all==1)

					{

				 			$sql ="select * from `$this->tablename` where status=1 and hot_product=1";

							 return($this->pagingQuery($sql));

				    }

				else

					{

						$sql ="select * from `$this->tablename` where status=1 and hot_product=1 order by rand()";

						 $result=$this->db->select($sql);

						  return($result);

					}

			}

}		

?>
