<? include("template.php");
function main()
{ 
	include("sitecontrol/inc/clsObj.php"); 
	$objFrontMenu->id=9;
	$recDet = $objFrontMenu->selectRecById(); 
?>
<div class="sub-banner-wthree">
		<h2><?=$recDet[0]['menuName'];?></h2> 
	</div>
	
	
	<!-- portfolio --> 
	<div id="portfolio" class="portfolio w3layouts-gal">
		<div class="container">
				
			<div class="gallery_gds">
				<ul class="simplefilter">
					<li class="active" data-filter="all">All</li>
					<li data-filter="1">JEANS</li>
					<li data-filter="2">COTTON JEANS</li>
					<li data-filter="3">CORDUROY</li>
					<li data-filter="4">TROUSER</li>
					<li data-filter="5">SHIRT</li>
				</ul>
				<div class="filtr-container">
					<?
					$imglist = $objProduct->getImages(1);
					for($n=0; $n<count($imglist); $n++)
					{ 
					?>
					
					<div class="col-md-4 filtr-item" data-category="1" data-sort="Busy streets">
						<div class="agileits-img">
							<a href="<?=PRODUCT_SMALL_IMAGE.$imglist[$n]['name'];?>" class="swipebox" title="Welcome To Raj Garment">
								<img class="img-responsive img-style row2" src="<?=PRODUCT_SMALL_IMAGE.$imglist[$n]['name'];?>" alt=""  /> 
								
							</a> 
						</div>
					</div>
					<? } 
					
					$imglist2 = $objProduct->getImages(2);
					for($n=0; $n<count($imglist2); $n++)
					{ 
					?>
					
					
					
					<div class="col-md-4 filtr-item" data-category="2" data-sort="Luminous night">
						<div class="agileits-img">
							<a href="<?=PRODUCT_SMALL_IMAGE.$imglist2[$n]['name'];?>" class="swipebox" title="Welcome To Raj Garment">
								<img src="<?=PRODUCT_SMALL_IMAGE.$imglist2[$n]['name'];?>" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<? }
					$imglist3 = $objProduct->getImages(3);
					for($n=0; $n<count($imglist3); $n++)
					{  ?>
					
					
					
					<div class="col-md-4 filtr-item" data-category="3" data-sort="Industrial site">
						<div class="agileits-img">
							<a href="<?=PRODUCT_SMALL_IMAGE.$imglist3[$n]['name'];?>" class="swipebox" title="Welcome To Raj Garment">
								<img src="<?=PRODUCT_SMALL_IMAGE.$imglist3[$n]['name'];?>" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<? }
					$imglist4 = $objProduct->getImages(4);
					for($n=0; $n<count($imglist4); $n++)
					{  ?>
					
					
					
					<div class="col-md-4 filtr-item" data-category="4" data-sort="In production">
						<div class="agileits-img">
							<a href="<?=PRODUCT_SMALL_IMAGE.$imglist4[$n]['name'];?>" class="swipebox" title="Welcome To Raj Garment">
								<img src="<?=PRODUCT_SMALL_IMAGE.$imglist4[$n]['name'];?>" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<? }
					$imglist5 = $objProduct->getImages(5);
					for($n=0; $n<count($imglist5); $n++)
					{ ?>
					
					<div class="col-md-4 filtr-item" data-category="5" data-sort="Luminous night">
						<div class="agileits-img">
							<a href="<?=PRODUCT_SMALL_IMAGE.$imglist5[$n]['name'];?>" class="swipebox" title="Welcome To Raj Garment">
								<img src="<?=PRODUCT_SMALL_IMAGE.$imglist5[$n]['name'];?>" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<? } ?>
					
					
					
					
					<!--<div class="col-md-4 filtr-item" data-category="5" data-sort="Luminous night">
						<div class="agileits-img">
							<a href="images/shirt/shirt-img1.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/shirt/shirt-img1.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<div class="col-md-4 filtr-item" data-category="4" data-sort="In production">
						<div class="agileits-img">
							<a href="images/trouser/img5.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/trouser/img5.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<div class="col-md-4 filtr-item" data-category="5" data-sort="Luminous night">
						<div class="agileits-img">
							<a href="images/shirt/shirt-img3.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/shirt/shirt-img3.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<div class="col-md-4 filtr-item" data-category="1" data-sort="City wonders">
						<div class="agileits-img">
							<a href="images/Jeans/img2.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/Jeans/img2.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<div class="col-md-4 filtr-item" data-category="3" data-sort="Industrial site">
						<div class="agileits-img">
							<a href="images/Corduroy/img1.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/Corduroy/img1.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<div class="col-md-4 filtr-item" data-category="4" data-sort="In production">
						<div class="agileits-img">
							<a href="images/trouser/img2.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/trouser/img2.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<div class="col-md-4 filtr-item" data-category="5" data-sort="Luminous night">
						<div class="agileits-img">
							<a href="images/shirt/shirt-img2.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/shirt/shirt-img2.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<div class="col-md-4 filtr-item" data-category="3" data-sort="Peaceful lake">
						<div class="agileits-img">
							<a href="images/Corduroy/img2.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/Corduroy/img2.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<div class="col-md-4 filtr-item" data-category="1" data-sort="Busy streets">
						<div class="agileits-img">
							<a href="images/Jeans/img3.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img class="img-responsive img-style row2" src="images/Jeans/img3.jpg" alt=""  /> 
							</a> 
						</div>
					</div>
					<div class="col-md-4 filtr-item" data-category="5" data-sort="Luminous night">
						<div class="agileits-img">
							<a href="images/shirt/shirt-plain1.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/shirt/shirt-plain1.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<div class="col-md-4 filtr-item" data-category="4" data-sort="In production">
						<div class="agileits-img">
							<a href="images/trouser/img1.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/trouser/img1.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					
					<div class="col-md-4 filtr-item" data-category="1" data-sort="City wonders">
						<div class="agileits-img">
							<a href="images/Jeans/img4.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/Jeans/img4.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<div class="col-md-4 filtr-item" data-category="2" data-sort="Luminous night">
						<div class="agileits-img">
							<a href="images/cotton-jeans/img2.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/cotton-jeans/img2.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<div class="col-md-4 filtr-item" data-category="5" data-sort="Luminous night">
						<div class="agileits-img">
							<a href="images/shirt/shirt-plain2.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/shirt/shirt-plain2.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<div class="col-md-4 filtr-item" data-category="4" data-sort="In production">
						<div class="agileits-img">
							<a href="images/trouser/img3.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/trouser/img3.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<div class="col-md-4 filtr-item" data-category="5" data-sort="Luminous night">
						<div class="agileits-img">
							<a href="images/shirt/shirt-plain3.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/shirt/shirt-plain3.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<div class="col-md-4 filtr-item" data-category="1" data-sort="City wonders">
						<div class="agileits-img">
							<a href="images/Jeans/img5.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/Jeans/img5.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<div class="col-md-4 filtr-item" data-category="4" data-sort="In production">
						<div class="agileits-img">
							<a href="images/trouser/img4.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/trouser/img4.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<div class="col-md-4 filtr-item" data-category="2" data-sort="Luminous night">
						<div class="agileits-img">
							<a href="images/cotton-jeans/img3.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/cotton-jeans/img3.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<div class="col-md-4 filtr-item" data-category="5" data-sort="Luminous night">
						<div class="agileits-img">
							<a href="images/shirt/shirt-plain6.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/shirt/shirt-plain6.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<div class="col-md-4 filtr-item" data-category="1" data-sort="City wonders">
						<div class="agileits-img">
							<a href="images/Jeans/img6.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/Jeans/img6.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<div class="col-md-4 filtr-item" data-category="2" data-sort="Luminous night">
						<div class="agileits-img">
							<a href="images/cotton-jeans/img4.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/cotton-jeans/img4.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>
					<div class="col-md-4 filtr-item" data-category="5" data-sort="Luminous night">
						<div class="agileits-img">
							<a href="images/shirt/shirt-img5.jpg" class="swipebox" title="Welcome To Raj Garment">
								<img src="images/shirt/shirt-img5.jpg" alt="" class="img-responsive img-style row2" />
							</a>	
						</div>
					</div>-->
				   <div class="clearfix"> </div>
				</div>
			</div>
		</div>  
	</div>    
	<!-- //portfolio-->
	<script src="js/jquery.filterizr.js"></script>  
	<script src="js/controls.js"></script>
	<!-- Kick off Filterizr -->
	<script type="text/javascript">
		$(function() {
			//Initialize filterizr with default options
			$('.filtr-container').filterizr();
		});
	</script>	
		<!-- swipe box js -->
	<script src="js/jquery.swipebox.min.js"></script> 
	<script type="text/javascript">
			jQuery(function($) {
				$(".swipebox").swipebox();
			});
	</script>
	<!-- //swipe box js --> 
	<script src="js/jquery.adipoli.min.js" type="text/javascript"></script>
	<script type="text/javascript"> 
		$(function(){ 
			$('.row2').adipoli({
				'startEffect' : 'overlay',
				'hoverEffect' : 'sliceDown'
			}); 
		});
		
	</script>
	
<? } ?>