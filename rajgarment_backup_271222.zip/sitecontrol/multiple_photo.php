<?php 
error_reporting(0);
	include("inc/fileInclude.php"); 
	include("inc/clsObj.php");
	
	if(isset($_GET['property_id']) && !empty($_GET['property_id']))
	{
		//echo $_GET['property_id'];
		$objPhotos->id=$_GET['property_id'];
		$contentDet = $objPhotos->selectDelRecById($_GET['image']);
		echo "Image deleted successfully...";
	}
	
	if(isset($_GET['img_id']) && !empty($_GET['img_id']))
	{
		//echo $_GET['property_id'];
		$objPhotos->id = $_GET['img_id'];
		$contentDet = $objPhotos->updateRecById($_GET['img_id'], $_GET['title'], $_GET['seq']);
		echo "Sequence number & Title  updated successfully...!!!";
	}
?>