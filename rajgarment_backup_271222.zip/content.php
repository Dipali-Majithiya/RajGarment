<?php include("template.php"); 

function main()
{ 	
	include("sitecontrol/inc/clsObj.php");
		
		if((isset($_GET['pid']) && $_GET['pid']!="")  || (isset($_GET['ctid']) && $_GET['ctid']!="") || (isset($_GET['id']) && $_GET['id']!="") || (isset($_GET['cpname']) && $_GET['cpname']!="") || isset($_GET['nid']) && $_GET['nid']!='' || isset($_GET['tid']) && $_GET['tid']!='')
		{
			
			if(isset($_GET['pid']))
			{
				$objProduct->id=$_GET['pid'];
				$product = $objProduct->selectRecById();				
			}
			elseif(isset($_GET['ctid']))
			{
				$objProCat->id=$_GET['ctid'];
				$category = $objProCat->selectRecById();
			}
			elseif(isset($_GET['id']))
			{
				$objFrontMenu->id=$_GET['id'];
				$contentDet = $objFrontMenu->selectRecById();
			}
			elseif(isset($_GET['nid']))
			{
				$objNews->id=$_GET['nid'];
				$contentDet = $objNews->selectRecById();
				?>
                <p style="color: #000;">News Title :- </p><?=$contentDet[0]['newsTitle'];?><br /><br />
                
                <p style="color: #000;">Image :- </p><?
            	
				if(count($contentDet)>0)
				{	
				for($i=0;$i<count($contentDet);$i++)
				{
				if(file_exists(NEWS_GALLERY_BIG.$contentDet[$i]['image']))
				{				
				$wh = getimagesize(NEWS_GALLERY_BIG.$contentDet[$i]['image']);
				// 	$wh=getimagesize($_FILES['Image1']['tmp_name']);			
				$w=$wh[0];
				$h=$wh[1];			 
				
				if($w>=$h)
				{ ?>
                    	
					<a href="<?=NEWS_GALLERY_BIG.$contentDet[$i]['image'];?>" title="<?=$contentDet[$i]['name'];?>">
                    <img width="50%" src="<?=NEWS_GALLERY_BIG.$contentDet[$i]['image'];?>" />
                    </a><?=$contentDet[$i]['name'];
                     
				}
				else
				{ ?>
                   
                	<a href="<?=NEWS_GALLERY_BIG.$i['image'];?>" title="<?=$i['name'];?>">
                    <img height="<?=($h<200) ? $h : '185';?>" src="<?=NEWS_GALLERY_BIG.$contentDet[$i]['image'];?>" />
                    </a><?=$contentDet[$i]['name'];  						      
				} 
			}
		}
				}
		else
		{
			?><label style="color:#FF0000">No photos found.</label><?
		} ?>      
                
                <br /><br />
                <p style="color: #000;">News Discription :- </p><?=$contentDet[0]['newsDiscription'];?><br /><br />
                <p style="color: #000;">News Long Discription :- </p><?=$contentDet[0]['newsLongDiscription'];?><br /><br />
                <p style="float:right !important;"><a style="color: #e94f00 !important;" href="news.php">Read More</a></p>
               <!-- <table width="100%" border="1" bordercolor="#999999" cellspacing="0" cellpadding="0" class="tabular">
                	<tr>
                    	<th width="6%" style="color: #000;" >News Title</th>
                        <th width="6%" style="color: #000;">News Discription</th>
                        <th width="6%" style="color: #000;">News Long Discription</th>
                    </tr>
                	<tr>
                		<td style="text-align:center !important;" width="6%" ><?=$contentDet[0]['newsTitle'];?></td>
                    	<td style="text-align:center !important;" width="6%" ><?=$contentDet[0]['newsDiscription'];?></td>
                    	<td style="text-align:center !important;" width="6%" ><?=$contentDet[0]['newsLongDiscription'];?></td>
                	</tr>
                </table>-->
				<?
				
			}
			elseif(isset($_GET['cpname']))
			{
				$objProduct->alias_name=$_GET['cpname'];
				$product = $objProduct->selectRecByAlias();		
				
				$objProCat->alias_name=$_GET['cpname'];
				$category = $objProCat->selectRecByAlias();	
				
				$objFrontMenu->alias_name=$_GET['cpname'];
				$contentDet = $objFrontMenu->selectRecByAlias();	
				//echo "<pre>";	print_r($contentDet);
			}
?>
<style type="text/css">
.headingh1
{
	font-size:20px;
}
.qucontact td
{
	line-height:30px;
}
</style>
<?					
			if(count($product)>0)
			{
				include("product.php");
			}
			elseif(count($category)>0)
			{
				include("category.php");
			}
			
			elseif(count($contentDet)>0)
			{
				?>
				<h1 class="headingh1">
				  <?=$contentDet[0]['menuName'];?>
				</h1> 
				<div class="inner_content">
				  <?=$contentDet[0]['menuDesc'];?>
				</div>
				<?php
			}
	}	
} 
?>