<? 
include("template.php");

function main()
{ ?>
<div class="dashboard-module" style="padding:10px;background:#F6F6F6;height:280px;">
      <a href="codeFrontMenu.php" class="dashboard-module">
        <img src="images/menu.gif" alt="edit" width="64" height="64" border="0" />
        <span>Front Menu </span>                
      </a>
      <a href="codeAdminUser.php" class="dashboard-module">
        <img src="images/Crystal_Clear_user.gif" alt="edit" width="64" height="64" border="0" />
        <span>Manage Users </span>                
      </a>                
      <a href="codeAdminChangePassword.php" class="dashboard-module">
        <img src="images/password.gif" alt="edit" width="64" height="64" border="0" />
        <span>Change Password </span>                
      </a>
      
      <a href="codeProducts.php" class="dashboard-module">
        <img src="images/project.png" alt="edit" width="64" height="64" border="0" />
        <span>Products</span>                
      </a>
      <a href="codeManagePhotos.php" class="dashboard-module">
        <img src="images/gallery.png" alt="edit" width="64" height="64" border="0" />
        <span>Photo Gallery</span>                
      </a>
      <a href="codeManageNews.php" class="dashboard-module">
        <img src="images/news.png" alt="edit" width="64" height="64" border="0" />
        <span>News</span>                
      </a>
      <a href="codeManageInquiry.php" class="dashboard-module">
        <img src="images/inquiry.png" alt="edit" width="64" height="64" border="0" />
        <span>Inquiry</span>                
      </a>
     <!-- <a href="codeAdminUser.php" class="dashboard-module">
        <img src="images/people.png" alt="edit" width="64" height="64" border="0" />
        <span>People</span>                
      </a>
      <a href="codeNews.php" class="dashboard-module">
        <img src="images/news.png" alt="edit" width="64" height="64" border="0" />
        <span>News</span>                
      </a> -->
      
<div style="clear: both"></div>           
</div>
<? } ?>