<?php /*?><h1 class="headingh1"> <?=$product[0]['product_name'];?></h1><br/><?php */?>
<? 
				$objFrontMenu->id=3;
				$backto = $objFrontMenu->selectRecById(); 
			
				if($backto[0]['alias_name']!='')
				{
					$link = strtolower($backto[0]['alias_name']).".html";
				}
				else
				{
					if($backto[0]['menuType']==3)
						$link = $backto[0]['menuUrl'];
					elseif($backto[0]['menuType']==2)
						$link = "content.php?id=".$backto[0]['id'];
				}
				
				if(isset($_GET['pid']) && !empty($_GET['pid']))
				{
					$sql = "SELECT * FROM `product_img` where product_id=".$_GET['pid'];	
				}
				else
				{
					$sql = "SELECT * FROM `product_img` where product_id=1";
				}		
				$imglist = $objProduct->getImages($product[0]['id']);
	
	 // For paging remove below comment
	// $imglist=$objProduct->pagingFrontQuery($sql);
  ?> 
  
  <div class="sub-banner-wthree">
		<h3>PRODUCTS</h3>
	</div>
	
	<div  class="about-w3layouts">
	
	<div class="banner-btm-w3-agile">
		<div class="container">
			<div class="col-md-8 banner-btm-left-w3ls">
				<!--<h3>Welcome To Raj Garments</h3>-->
				<h3 style="color:#0194da; margin-bottom:20px; text-transform:uppercase;"><?=$product[0]['product_name'];?></h3>
				<?=$product[0]['description'];?>
				 <!--<p>Resurgent economies, set of complex and intriguing challenges to businesses operating in this environment. Along with the impending outlook towards business expansion and growth.</p>	
				 <p class="w3layouts">Resurgent economies, set of complex and intriguing challenges to businesses operating in this environment. Along with the impending outlook towards business expansion and growth.</p>-->
			</div>
			
			<div class="col-md-4 banner-btm-right-w3ls">
				<div><?
				if($product[0]['image']!="")
				{ ?>	
					<div class="grid">
					<figure class="effect-apollo">
					<img src="<?=PRODUCT_BIG_IMAGE.$product[0]['image'];?>" alt=" ">
					</figure>
						<!--<figure class="effect-apollo">
							<img src="images/side-img/jeans.jpg" alt=" ">
						</figure>-->
					</div>
				<? } ?>
				</div>
				
			</div>
			<div class="clearfix"></div>
		</div>	
	</div>
	 
	 </div>	
	 
	  <script src="js/responsiveslides.min.js"></script>
			     <script>
			    // You can also use "$(window).load(function() {"
			    $(function () {
			      // Slideshow 4
			      $("#slider4").responsiveSlides({
			        auto: true,
			        pager:false,
			        nav:true,
			        speed: 500,
			        namespace: "callbacks",
			        before: function () {
			          $('.events').append("<li>before event fired.</li>");
			        },
			        after: function () {
			          $('.events').append("<li>after event fired.</li>");
			        }
			      });
			
			    });
			  </script>
            
	<?php /*?><div id="vlightbox1">   
    <table id="imgbord" width="100%">
  	<tr>
    <td ><a href="<?=$link;?>" class="backbutton"> << Back </a></td>
 	</tr>
  	<tr>
    <td>&nbsp;</td>
  	</tr>
  <? if($product[0]['description']!='')
  	 {?>
  		<tr>
    		<td class="secondone" valign="top" style="font-size:12px;"><?=$product[0]['description'];?></td>
  		</tr>
  <? } ?>
  <tr>
    <td>&nbsp;</td>
  </tr>

  <tr>
  	<td>
    	<table bordercolor="#CCCCCC" border="0" class="products"  width="100%">
        <tr>
        	<td valign="middle">           
        <div style="width:900px;">
	<?php
		if(count($imglist)>0)
		{
			$counter=0; 
			for($n=0; $n<count($imglist); $n++)
			{ 
            	if(file_exists(PRODUCT_BIG_IMAGE.$imglist[$n]['name']))
				{						
					$wh = getimagesize(PRODUCT_SMALL_IMAGE.$imglist[$n]['name']);
					$w=$wh[0];
					$h=$wh[1];		
    ?>                      
    <div id="wrapper11">
	<div id="cell11">
		<div class="content11">                         
    <? if($w>=$h)
	{ ?>
      <a class="vlightbox1" href="<?=PRODUCT_BIG_IMAGE.$imglist[$n]['name'];?>?url=<?=PRODUCT_BIG_IMAGE.$imglist[$n]['name'];?>">
      <img width="100%" src="<?=PRODUCT_SMALL_IMAGE.$imglist[$n]['name'];?>?url=<?=PRODUCT_SMALL_IMAGE.$imglist[$n]['name'];?>"alt="<?=$imglist[$n]['img_title'];?>"/></a>
     <? }
	 else
	 { ?>
     	<a class="vlightbox1" style="margin-bottom:0px; margin-top:0px;" href="<?=PRODUCT_BIG_IMAGE.$imglist[$n]['name'];?>?url=<?=PRODUCT_BIG_IMAGE.$imglist[$n]['name'];?>" >
        <img height="<?=($h<200) ? $h : '185';?>" src="<?=PRODUCT_SMALL_IMAGE.$imglist[$n]['name'];?>?url=<?=PRODUCT_SMALL_IMAGE.$imglist[$n]['name'];?>" alt="<?=$imglist[$n]['img_title'];?>" /></a>
     <? } ?>
    </div>
	</div>
</div>
<?php }
} ?>      
    </div>
    </td>
    </tr>
	<?php
		}		
	?>
</table>
    </td>
  </tr>
 <tr><td align="center"  style="text-align:center;">&nbsp;</td></tr>
 
  <!--<tr>
    <td align="right" style="text-align:right;"><a style="font-size:16px;" href="#toplogo">Top</a></td>
  </tr>-->
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td width="100"><a class="sendbutton" style="" href="<?=$link;?>" >Send Inquiry</a></td>
  </tr>
</table><?php */?>
