<?
	$filepath = (stristr($_SERVER['PHP_SELF'],"sitecontrol")!="") ? "../" : "" ;

	define("TEMPLATE",$template);
	$basepath1 = "http://" . $_SERVER['HTTP_HOST']  . $_SERVER['REQUEST_URI']; 	
	$basepath2 = explode('/',$basepath1);
		
	for($i=0; $i<count($basepath2)-1; $i++)
	{
		$basepath .= $basepath2[$i].'/';
	}
	
	/* Front Menu Image Path  */
	define("FRONT_SMALL_IMAGE", $filepath.TEMPLATE."images/front/small/");	
	define("FRONT_BIG_IMAGE", $filepath.TEMPLATE."images/front/big/");
	/* Front Menu Image End */
	
	/* Banner path */
	define("BANNER_BIG_IMAGE", $filepath.TEMPLATE."images/banner/big/");
	define("BANNER_SMALL_IMAGE", $filepath.TEMPLATE."images/banner/small/");
	/* Banner end */
	
	/* News path */
	define("NEWS_BIG_IMAGE", $filepath.TEMPLATE."images/news/big/");
	define("NEWS_SMALL_IMAGE", $filepath.TEMPLATE."images/news/small/");
	/* News end */
	
	/* Category Path  */
	define("CATEGORY_SMALL_IMAGE", $filepath.TEMPLATE."images/category/small/");	
	define("CATEGORY_BIG_IMAGE", $filepath.TEMPLATE."images/category/big/");
	/* Category End */
	
	/* Product path */
	define("PRODUCT_SMALL_IMAGE", $filepath.TEMPLATE."images/product/small/");	
	define("PRODUCT_BIG_IMAGE", $filepath.TEMPLATE."images/product/big/");
	/* Product end */	
	
	/* Newsgallary Path, Height and Width */
	define("NEWS_GALLERY_SMALL", $filepath."images/news/small/");	
	define("NEWS_GALLERY_BIG", $filepath."images/news/big/");	
	define("NEWS_CATEGORY", $filepath."images/news/category/");	
	/* Newsgallery End */
	
	/* Photogalley Path, Height and Width */
	define("PHOTO_GALLERY_SMALL", $filepath."images/photo_gallery/photos/small/");	
	define("PHOTO_GALLERY_BIG", $filepath."images/photo_gallery/photos/big/");	
	define("PHOTO_CATEGORY", $filepath."images/photo_gallery/category/");	
	/* Photogallery End */
	
	/* Soical Images */
	define("SOCIAL_IMAGE", $filepath."images/social/");	
		
	define("BASE_URL",$basepath);	
	define("COPYRIGHTS", date("Y"));
	define("TOTAL_RECORDS",30);	
	define("CURRENCY","$");		
	//session_register("userfile_path");
	//session_register("no_of_rec");	
	

	//-------constants for payment gateway -------
	define("TEST_MODE",true);

	//-------constants for other modules-------
	define("MENU_EDIT",1);
?>	