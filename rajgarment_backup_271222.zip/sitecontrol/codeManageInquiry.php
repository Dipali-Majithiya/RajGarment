<?php
include("template.php");
function main()
{
	$heading="Inquiry";
    include("inc/clsObj.php");
	$pageName="codeManageInquiry.php";
	$object=$objInquiry;
	$object->limit=TOTAL_RECORDS;	
	
	extract($_POST);	
    
	$object->id=isset($_GET['uid']) ? $_GET['uid'] : ( isset($_GET['delete']) ? $_GET['delete'] : ( isset($_GET['id']) ? $_GET['id'] : $hid  )) ;
	
	$object->Name=$Your_Name;
	$object->Email=$Your_Email;
	$object->CompanyName=$Your_Company_Name;
	$object->Website=$Website;
	$object->Address=$Street_Address;
	$object->City=$City;
	$object->State=$State;
	$object->PostalCode=$Postal_Code;
	$object->Country=$Country;
	$object->Telephone=$Telephone;
	$object->Mobile=$Mobile;
	$object->Detail=$description;
	$object->status=isset($_GET['status']) ? $_GET['status'] : 0;	
		
	if(isset($_POST['btnAdd']))
	{
		$object->insert();	
		redirect($pageName."?msg=add");			
	}
	
	if(isset($_POST['btnUpdate']))
	{	
		 $object->update();
		 redirect($pageName."?msg=edit&page=".$_REQUEST['page']);
	}
	
	if(isset($_POST['btnAction']))
	{
	 	extract($_POST);
	 	
		switch($optAction)
	  	{
			case 0:
					$object->deleteSelect($chkAction);
					break;
			case 1:
					$object->statusUpdatePublish($chkAction);
					break;
			case 2:
				$object->statusUpdateUnPublish($chkAction);
	  	} 		  
	 	redirect($pageName."?msg=edit&page=".$_REQUEST['page']);
	}	
	
	if(isset($_GET['delete']))
	{			 
	  		$object->delete();
	  		redirect($pageName."?msg=del&page=".$_REQUEST['page']);
	}	
	
	if(isset($_GET['status']))
	{			 
		  	$object->status();
		  	redirect($pageName."?msg=status&page=".$_REQUEST['page']);		
	}
	
	if(isset($_GET['id']))
	{			
			$listEdit=$object->selectRecById();												
	}		
	
	$listRec=$object->paging();
    include("html/frmAdminInquiry.php");
 } 
?>