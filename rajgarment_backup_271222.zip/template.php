<?php
	error_reporting(0);
 	include("sitecontrol/inc/fileInclude.php"); 
	include("sitecontrol/inc/clsObj.php"); 
	include("sitecontrol/config.php"); 
	
	if(stristr($_SERVER['PHP_SELF'],"index.php")!="")
	{
		$objFrontMenu->id=1;
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	elseif(stristr($_SERVER['PHP_SELF'],"aboutus.php")!="")
	{
		$objFrontMenu->id=2;
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	elseif(stristr($_SERVER['PHP_SELF'],"products.php")!="")
	{
		$objFrontMenu->id=3;
		$metaRec=$objFrontMenu->selectRecById(); 
	}	
	elseif(stristr($_SERVER['PHP_SELF'],"inquiry.php")!="")
	{		
		$objFrontMenu->id=6;
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	elseif(stristr($_SERVER['PHP_SELF'],"contactus.php")!="")
	{
		$objFrontMenu->id=7;
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	elseif(stristr($_SERVER['PHP_SELF'],"sitemap.php")!="")
	{
		$objFrontMenu->id=8;
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	
	elseif(stristr($_SERVER['PHP_SELF'],"gallery.php")!="")
	{
		$objFrontMenu->id=9;
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	elseif(stristr($_SERVER['PHP_SELF'],"video_gallery.php")!="")
	{
		$objFrontMenu->id=11;
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	elseif(stristr($_SERVER['PHP_SELF'],"abc.php")!="")
	{
		$objFrontMenu->id=13;
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	elseif((isset($_GET['ctid']) && $_GET['ctid']!="") || (isset($_GET['cpname']) && $_GET['cpname']!="") || (isset($_GET['pid']) && $_GET['pid']!=""))
	{
		if(isset($_GET['ctid']))
		{
				$objProCat->id=$_GET['ctid'];
				$metaRec = $objProCat->selectRecById();
				
				if($metaRec[0]['metaTitle']=='')
				{
					$metaRec[0]['metaTitle'] = $metaRec[0]['category_name'].' | '.META_TITLE;
				}
				if($metaRec[0]['metaDescription']=='')
				{
					$metaRec[0]['metaDescription'] = WE_OFFER.' '.$metaRec[0]['category_name'].' , '.META_DESC;
				}
				if($metaRec[0]['metaKeywords']=='')
				{
					$metaRec[0]['metaKeywords'] = $metaRec[0]['category_name'].' , '.META_KEYWORD;
				}
				
			}
			elseif(isset($_GET['pid']))
			{
				$objProduct->id=$_GET['pid'];
				$metaRec = $objProduct->selectRecById();
				
				if($metaRec[0]['metaTitle']=='')
				{
					$metaRec[0]['metaTitle'] = $metaRec[0]['product_name'].' | '.META_TITLE;
				}
				if($metaRec[0]['metaDescription']=='')
				{
					$metaRec[0]['metaDescription'] = WE_OFFER.' '.$metaRec[0]['product_name'].' , '.META_DESC;
				}
				if($metaRec[0]['metaKeywords']=='')
				{
					$metaRec[0]['metaKeywords'] = $metaRec[0]['product_name'].' , '.META_KEYWORD;
				}
			}
			elseif(isset($_GET['cpname']))
			{
				$objProduct->alias_name=$_GET['cpname'];
				$metaRec = $objProduct->selectRecByAlias();	
				
				//echo "<pre>"; print_r($metaRec); exit;
				
				if(count($metaRec)>0)
				{
					if($metaRec[0]['metaTitle']=='')
					{
						$metaRec[0]['metaTitle'] = $metaRec[0]['product_name'].' | '.META_TITLE;
					}
					if($metaRec[0]['metaDescription']=='')
					{
						$metaRec[0]['metaDescription'] = WE_OFFER.' '.$metaRec[0]['product_name'].' , '.META_DESC;
					}
					if($metaRec[0]['metaKeywords']=='')
					{
						$metaRec[0]['metaKeywords'] = $metaRec[0]['product_name'].' , '.META_KEYWORD;
					}
				}
				else
				{
				
					$objProCat->alias_name=$_GET['cpname'];
					$metaRec = $objProCat->selectRecByAlias();	
									
					if($metaRec[0]['metaTitle']=='')
					{
						$metaRec[0]['metaTitle'] = $metaRec[0]['category_name'].' | '.META_TITLE;
					}
					if($metaRec[0]['metaDescription']=='')
					{
						$metaRec[0]['metaDescription'] = WE_OFFER.' '.$metaRec[0]['category_name'].' , '.META_DESC;
					}
					if($metaRec[0]['metaKeywords']=='')
					{
						$metaRec[0]['metaKeywords'] = $metaRec[0]['category_name'].' , '.META_KEYWORD;
					}
					
				}
								
			}						
	}
	else
	{
		$objFrontMenu->id=$_GET['id'];
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title><? echo $metaRec[0]['metaTitle'];?></title>
<meta name="description" content="<? echo $metaRec[0]['metaDescription'];?>" />
<meta name="keywords" content="<? echo $metaRec[0]['metaKeywords'];?>" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!--<title>Welcome To Raj Garment Gheekanta,Ahmedabad Gujarat 380001</title>-->
<!--<meta name="keywords" content="Jeans,Cotton Jeans,Corduroy,Trouser,Shirt Manufacturer in Ahmedabad, Gujarat, India" />-->
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--css -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all" />
<!--// css -->
<!-- font -->
<link href="//fonts.googleapis.com/css?family=Ceviche+One" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link href="//fonts.googleapis.com/css?family=Berkshire+Swash" rel="stylesheet">
<!-- //font -->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>

	<!-- start-smooth-scrolling -->
			<script type="text/javascript" src="js/easing.js"></script>
			<script type="text/javascript">
				jQuery(document).ready(function($) {
					$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
			</script>
	<!-- //start-smoth-scrolling -->
<script type="text/javascript" src="js/numscroller-1.0.js"></script>
</head>
<body>
	<div class="header-w3">
			<div class="header-top-agile">
				<div class="container">
					<div class="col-md-3 logo-agileinfo">
					<a href="index.html"><img src="images/raj-garment-logo3.jpg"></a>
						<!--<h1><a href="index.html">Raj Garment</a></h1>
-->					</div>
					<div class="col-md-6 logo-agileinfo">
					<a href="index.html"><img src="images/logo-4.jpg" ></a>
						<!--<h1><a href="index.html">Raj Garment</a></h1>
-->					</div>
					
					
					<div class="col-md-3 social-icons-agileits">
						<ul>
							<!--<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>-->
							<!--<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span></li>
					<li>+98983 94321</li>-->
							<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>  +91 98983 94321</li>
							<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>				
						</ul>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
			<div class="header-bottom-agile">
				<div class="container">
					<div class="col-md-9 navigation">
						<nav class="navbar navbar-default cl-effect-16" id="cl-effect-16">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<div id="navbar" class="navbar-collapse navbar-right collapse hover-effect">
						 <? include("top_menu.php"); ?>
							<?php /*?><ul class="nav navbar-nav">
								<li class="active"><a href="index.html" data-hover="HOME">HOME</a></li>
								<li><a href="about.html" data-hover="ABOUT">ABOUT</a></li>
								<li class="dropdown mega-dropdown act">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="PRODUCT">PRODUCT<span class="caret"></span></a>				
									<div class="dropdown-menu mega-dropdown-menu codes-menu">
										<ul>	
											<li><a href="jeans.html">JEANS</a></li>
											<li><a href="cottonjeans.html">COTTON JEANS</a></li>
											<li><a href="corduroy.html">CORDUROY</a></li>
											<li><a href="trouser.html">TROUSER</a></li>
											<li><a href="shirt.html">SHIRT</a></li>
										</ul>             
									</div>				
								</li>
								<li><a href="gallery.html" data-hover="GALLERY">GALLERY</a></li>
								
								<li><a href="contact.html" data-hover="CONTACT">CONTACT</a></li>
							</ul>	<?php */?>
						</div>
						</nav>
					</div>
					<!--<div class="col-md-3 search">
						<div id="sb-search" class="sb-search">
							<form action="#" method="post">
								<input class="sb-search-input" name="search" placeholder="Enter your search term..." id="search" required="">
								<input class="sb-search-submit" type="submit" value="">
								<span class="sb-icon-search"> </span>
							</form>
							<div class="clearfix"> </div>
							<!-- search-scripts
							<!--<script src="js/classie.js"></script>
							<script src="js/uisearch.js"></script>
								<script>
									new UISearch( document.getElementById( 'sb-search' ) );
								</script>
							<!-- //search-scripts 
						</div>
					</div>-->
					<div class="clearfix"></div>
				</div>
			</div>
	</div>

    
     

      
 
   <? main(); ?>  
   
   <div class="footer-agileits-w3layouts" id="footer">
		<div class="container">
			<div class="col-md-4 footer-left-agile">
			<?
				$objFrontMenu->id=10;
				$recDet = $objFrontMenu->selectRecById(); 
			?><?=$recDet[0]['menuDesc'];?>
			<?php /*?><img src="images/raj-garment-logo.jpg"><br/><br/>
			<!--<h1><a href="#">Adore</a></h1>-->
			<p><img src="images/logo-2.jpg"></p>
			<p><img src="images/logo-3.jpg"></p><br/>
				<p>Integer porttitor elit sit amet ullamcorper venenatis. Suspendisse in ornare magna, vitae scelerisque lectus. Proin lacus tellus, tincidunt sed sem quis</p><br/><?php */?>
				
			</div>
			<div class="col-md-4 footer-middle-w3-agileits">
				<h3>Address</h3>
				<ul>
					<li><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span></li>
					<li>G-1 New Laxmi Visnu Market,<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Opp Mahalaxmi Complex,<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Gheekanta, Ahmedabad-380001<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Gujarat, India </li>
				</ul>
				<ul class="gap">
					<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span></li>
					<li>Mr.Nareshkumar Budhani</li>
				</ul>
				<ul class="gap">
					<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span></li>
					<li>+91 98983 94321</li>
				</ul>
				<ul class="gap">
					<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span></li>
					<li>+91 98257 77900</li>
				</ul>
				
				<ul>
					<li><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span></li>
					<li><a href="mailto:raj.fashion10@gmail.com">raj.fashion10@gmail.com</a></li>
				</ul>
			</div>
<script type="text/javascript">
<!--
function MM_validateForms() { //v4.0
  if (document.getElementById)
  {
    var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForms.arguments;
    for(i=0; i<(args.length-2); i+=3)
	{ 
		test=args[i+2]; val=document.getElementById(args[i]);
      	if(val)
		{
			nm=val.name;
			if((val=val.value)!="")
			{
        		if(test.indexOf('isEmail')!=-1)
				{
					p=val.indexOf('@');
          			if(p<1 || p==(val.length-1))
						errors+='- '+nm+' must contain an e-mail address.\n';
        		}
				else if(test!='R')
				{
					num = parseFloat(val);
          			if(isNaN(val)) 
						errors+='- '+nm+' must contain a number.\n';
          			if(test.indexOf('inRange') != -1)
					{
						p=test.indexOf(':');
            			min=test.substring(8,p); max=test.substring(p+1);
            			if(num<min || max<num) 
							errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
      				}
				}
			}
			else if(test.charAt(0) == 'R') 
				errors += '- '+nm+' is required.\n';
			}
    	}
		if(document.getElementById("captchaResults").value=="")
			errors+='- Captcha Code is required\n';
		else if(document.getElementById('captchaResults').value != document.getElementById("captchaTotals").value)
			errors+='- Captcha Code is invalid\n';
			
		if(errors)
			alert('The following error(s) occurred:\n'+errors);
    	document.MM_returnValue = (errors == '');
	}
}
//-->
</script>
			<div class="col-md-4 footer-right-w3layouts">
				<h3 >QUICK INQUIRY</h3>
				<form action="sendinquiry.php" method="post"  enctype="multipart/form-data" onsubmit="MM_validateForms('name','','R','email','','RisEmail','mobile','','R','message','','R');return document.MM_returnValue">	
				<!--<form  action="#" method="post">-->
					<input type="text" placeholder="Name" name="name" id="name" ><br/>
					<input type="text" placeholder="Email"name="email" id="email"><br/>
					<input type="text" placeholder="Mobile"name="mobile" id="mobile"><br/>
					<textarea style="margin-top:5px;" cols="35" rows="3" name="message" placeholder="Message" id="message"></textarea><br/>
					<?
		$min_number = 1;
		$max_number = 15;
		$random_number1 = mt_rand($min_number, $max_number);
		$random_number2 = mt_rand($min_number, $max_number);
		$_SESSION['captchaSum']=$random_number1+$random_number2;
		//===========End of Captcha Code=========
		?>
		<p style="margin-top:20px;"><strong><?=$random_number1."+".$random_number2;?> :</strong></p> 
		<input type="text" placeholder="Enter Code" name="captchaResults" id="captchaResults" autocomplete="off">
		<input name="firstNumber" id="firstNumber" type="hidden" value="<?php echo $random_number1; ?>" />
		<input name="secondNumber" id="secondNumber" type="hidden" value="<?php echo $random_number2; ?>" />
		<input name="captchaTotals" id="captchaTotals" type="hidden" value="<?php echo $_SESSION['captchaSum']; ?>" /><br/>
					
					
					<input style="margin-top:20px;" type="submit" name="submit_temp" value="Send">
				</form>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="copy-w3-agileits">
		<div class="container">
			<p>&copy; 2017 Raj Garment. All Rights Reserved | Design By: <a href="www.imagewebsolution.com">www.imagewebsolution.com</a></p>
		</div>
	</div>
</body>
</html>
      