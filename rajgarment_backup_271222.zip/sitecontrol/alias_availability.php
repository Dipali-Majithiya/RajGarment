<?php
include("inc/fileInclude.php");
include("inc/clsObj.php");

// echo $_GET['ntid']; exit;

	$_POST['Alias_Name'] = preg_replace("![^a-z0-9]+!i", "-", $_POST['Alias_Name']);
	$_POST['Alias_Name'] = strtolower($_POST['Alias_Name']);
	
	if($_GET['par']=='category')
	{	
		//$records = $objProCat->selectRecords($_POST['Alias_Name']);
		if(isset($_GET['ntid']) && $_GET['ntid']!='')
		{
			$records = $objProCat->selectRecords($_POST['Alias_Name'],$_GET['ntid']);	
		}
		else
		{
			$records = $objProCat->selectRecords($_POST['Alias_Name'],'');
		}
	}
	
	elseif($_GET['par']=='product')
	{		
		if(isset($_GET['ntid']) && $_GET['ntid']!='')
		{
			$records = $objProduct->selectRecords($_POST['Alias_Name'],$_GET['ntid']);	
		}
		else
		{
			$records = $objProduct->selectRecords($_POST['Alias_Name'],'');
		}		
	}
	
	else
	{
		$records = $objFrontMenu->selectRecords($_POST['Alias_Name']);
	}
	//if()		
	if($records[0]['alias_name']!='')
	{
		echo "no";
	}
	else 
	{
		echo "yes";
	}	
	/*for($pp=0; $pp<count($products); $pp++){
		$products[$pp]['alias_name'] = preg_replace("![^a-z0-9]+!i", "-", $products[$pp]['alias_name']);
		$products[$pp]['alias_name'] = strtolower($products[$pp]['alias_name']);
		$pro[$pp] = $products[$pp]['alias_name'];
	}
	$_POST['Alias_Name'] = preg_replace("![^a-z0-9]+!i", "-", $_POST['Alias_Name']);
	$_POST['Alias_Name'] = strtolower($_POST['Alias_Name']);
	$alias_name=$_POST['Alias_Name'];
	
//	echo $alias_name; exit;
	
	if (in_array($alias_name, $pro)){echo "no";}else{echo "yes";}*/
//this varible contains the array of existing users
	//$existing_users=array('roshan', 'mike', 'jason'); 
	
//value got from the get metho
	//$user_name=$_POST['user_name'];
	
//checking weather user exists or not in $existing_users array
	//if (in_array($user_name, $existing_users))
	//{
		//user name is not availble
		//echo "no";
	//}else{
		//user name is available
		//echo "yes";
	//}
?>