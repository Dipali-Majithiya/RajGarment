<?php
global $db;
class adminInquiry
{
	   /* Variable Declaration*/		
	   var $tablename='inquiry';
	   var $id;
	   var $Name;
	   var $Email;
	   var $CompanyName;
	   var $Website;
	   var $Address;
	   var $City;
	   var $State;
	   var $PostalCode;
	   var $Country;
       var $Telephone;
	   var $Mobile;
	   var $Detail;
	   var $status;      
	   var $limit;
	   var $start;
	    
		/*Constructor to intialize the Dabatabase*/
        function adminInquiry()
		{
			$this->db = new dbclass();
		}
		
		/*Insert Record into Database*/		
		/*function adminEmail()
		{
			$sql ="select * from `$this->tablename` 
				   where id='$this->id'";
				   // echo $sql;die();
			   $result=$this->db->select($sql);
			   return($result);
		}	*/
		
		function insert() 
		{
				$sql = "insert into `$this->tablename` values ('',
							'$this->Name',
							'$this->Email', 
							'$this->CompanyName',
							'$this->Website',
							'$this->Address',
							'$this->City',
							'$this->State',
							'$this->PostalCode',
							'$this->Country',
							'$this->Telephone',
							'$this->Mobile',
							'$this->Detail',
							'$this->status')";//echo $sql;die();
						
				$this->db->insert($sql);
				$id=mysql_insert_id();
				return($id);
		} 
		
		/* Check the login  for the user*/	
	/*	function loginCheck()
		{
			   $sql ="select * from `$this->tablename` 
					  where adminUsername='$this->adminUsername' and 
							adminPassword='$this->adminPassword' and 
							status=1";
			// echo $sql;die();
			$result=$this->db->select($sql);
			return($result);
		}
*/
		/* Login updates last login time*/	
	/*	function loginUpdate()
		{
			$sql = "update `$this->tablename` set
							`adminLastLogin`= now()										
							 where `id`=".$_SESSION['memberid'];
							 //echo $sql;die();				  
					$this->db->edit($sql);		
					return true;
		}	
*/
		/* Login updates last login time*/	
		/*function updateRights()
		{
			$sql = "update `$this->tablename` set
							`adminRights`= '$this->adminRights'
							 where `id`='$this->id'";
							 // echo $sql;die();				  
					$this->db->edit($sql);		
					return true;
		}	*/

		/* Fetch all the records */	
		/*function select()
		{
			$sql ="select * from `$this->tablename` order by adminName";
			//echo $sql;die();
			   $result=$this->db->select($sql);
			   return($result);
		}	
		*/
		/*Fectch record by id from Database*/		
		/*function selectRecById()
		{
			$sql ="select * from `$this->tablename` 
				   where id='$this->id'";
				   //echo $sql;die();
			   $result=$this->db->select($sql);
			   return($result);
		}*/
		
		/* update the record in database*/		
		/*function update()
		{
			$sql = "update `$this->tablename` set
							`adminName`='$this->adminName',
							`adminUsername`='$this->adminUsername',
							`adminPassword`='$this->adminPassword',
							`adminEmail`='$this->adminEmail'										
							 where `id`=$this->id";//echo $sql;die();	
					$this->db->edit($sql);		
					return true;
		}*/
		
		/*delete a record from database*/	
		/*function delete()
		{
			$sql="delete from `$this->tablename` 
				  where `id`=$this->id";//echo $sql;die();
			mysql_query($sql);	  
		}*/
		
		/*update password*/	
		/*function adminUpdatePassword()
		{
			$sql = "update `$this->tablename` set
						   `adminPassword`='$this->adminPassword'
							where `id`=$this->id";//echo $sql;die();	
					$this->db->edit($sql);		
					return true;
		}*/
		
		/*update single status*/	
		/*function status()
		{
			$sql = "update `$this->tablename` set
						   `status`='$this->status'
							where `id`=$this->id";//echo $sql;die();	
					$this->db->edit($sql);		
					return true;
		}*/
		
		/*update selected status publish*/	
		/*function statusUpdatePublish($chk)
		{
			for($i=0;$i<count($chk);$i++)
			{
				$id = $chk[$i];
				$sql = "update `$this->tablename` set
							   `status`=1
								where `id`='$id'";//echo $sql;die();	
				$this->db->edit($sql);		
			}
			return true;
		}	*/
		
		/*update selected status unpublish*/	
		/*function statusUpdateUnPublish($chk)
		{

			for($i=0;$i<count($chk);$i++)
			{
				$id = $chk[$i];
				$sql = "update `$this->tablename` set
							   `status`=0
								where `id`='$id'";//echo $sql;die();	
						$this->db->edit($sql);		
			}
			return true;
		}	*/
		
		/*delete the selected record*/	
		/*function deleteSelect($chk) 
		{
			for($i=0;$i<count($chk);$i++)
			{
				$id = $chk[$i];
				$sql="delete from `$this->tablename` where `id` = '$id'";
				$res = mysql_query($sql);
			}
			return true;
		}	*/
		
		/*function forgotPassoword()
	    {
			$sql="select * from `$this->tablename` where adminEmail='$this->adminEmail'";
			$result=$this->db->select($sql);
			return($result);
	    }	*/						
		
		/*...Paging...*/
		/*function paging()
		{
			$pages = new Paging();
			$pages->sql ="select * from `$this->tablename`";
			$pages->page = isset($_REQUEST['page']) ? $_REQUEST['page'] : 1;
			$pages->limit = $this->limit; 
			$pages->GeneratePaging();
			$this->pagination=$pages->pagination; 
			$result=$this->db->select($pages->sql);
			return($result);
		}   */
}		
?>   