<?php
global $db;
class products
	{
	   var $tablename='products';
	   var $id;
	   var $catid;
	   var $sqno;
	   var $product_name;
	   var $price;
	   var $description;
	   var $size;
	   var $image;	  
	   var $new_arrival;
	   var $metaTitle;  
	   var $metaDescription;
	   var $metaKeywords;
	   var $status;
	   var $limit;
	   var $start;
       function products(){$this->db = new dbclass();}
	   function insert(){	
	   			$sql = "insert into `$this->tablename` values('',																											
							   '$this->catid',
							   '$this->sqno',
							   '$this->product_name',
							   '$this->size',
							   '$this->price',
							   '$this->description',
							   '$this->image',
							   '$this->new_arrival',
							   '$this->metaTitle',  
							   '$this->metaDescription',
							   '$this->metaKeywords',
							   '$this->status'
							    )";
								//echo $sql;die();		
					$this->db->insert($sql);
					$id=mysql_insert_id();
					return($id);
			}
	   function update()
			{
				$sql = "update `$this->tablename` set
								`catid`='$this->catid',
								`sqno`='$this->sqno',
								`product_name`='$this->product_name',
								`size`='$this->size',
								`image`='$this->image',
								`description`= '$this->description',
								`new_arrival`='$this->new_arrival',
								`metaTitle`='$this->metaTitle',  
								`metaDescription`='$this->metaDescription',
								`metaKeywords`='$this->metaKeywords',
								`status`='$this->status'
								 where `id`=$this->id";
								  //echo $sql;die();	
						$this->db->edit($sql);		
						return true;
			}					
		function select()
			{
				 $sql ="select * from `$this->tablename`";//echo $sql;die();
    			   $result=$this->db->select($sql);
	 		       return($result);
			}	

		function selectStatus()
			{
				$sql ="select * from `$this->tablename` where catid='$this->catid' and status=1";
				// echo $sql;die();
    			return($this->pagingQuery($sql));
			}

		function selectStatusAll()
			{
				$sql ="select * from `$this->tablename` where status=1";
				 //echo $sql;die();
    			$result=$this->db->select($sql);
				return($result);
			}
			
		function selectRootProduct()
			{
				$sql ="select * from `$this->tablename` where catid='0' and status=1";
				 //echo $sql;die();
    			$result=$this->db->select($sql);
				return($result);
			}
			
		function selectCountStatus()
			{
				 $sql ="select count(*) as total from `$this->tablename` where category_id='$this->category_id' and status=1";
				 //echo $sql;die();
    			 $result=$this->db->select($sql);
				 return($result);
			}	
		function selectNewArrivalStatus($all="")
			{
				if($all==1)
					{
				 			$sql ="select * from `$this->tablename` where status=1 and new_arrival=1";
							 return($this->pagingQuery($sql));
				    }
				else
					{
						$sql ="select * from `$this->tablename` where status=1 and new_arrival=1 order by rand() limit 0,4";
						 $result=$this->db->select($sql);
						  return($result);
					}
			}
		function selectNewArrivalCountStatus()
			{
				$sql ="select count(*) as total from `$this->tablename` where status=1 and new_arrival=1";
				$result=$this->db->select($sql);
				return($result);
			}	
		function selectNewArrivalBrandStatus()
			{
				$sql ="select * from `$this->tablename` where status=1 and new_arrival=1 and brand_id='$this->brand_id'";//echo $sql;die();
				return($this->pagingQuery($sql));
			}	
		function selectNewArrivalBrandCountStatus()
			{
				$sql ="select count(*) as total from `$this->tablename` where status=1 and new_arrival=1 and brand_id='$this->brand_id'";//echo $sql;die();
				$result=$this->db->select($sql);
				return($result);
			}		
		function selectBestDealStatus($all="")
			{
				if($all==1)
					{
				 			$sql ="select * from `$this->tablename` where status=1 and best_deal=1";
							return($this->pagingQuery($sql));
				    }
				else
					{
						    $sql ="select * from `$this->tablename` where status=1 and best_deal=1 order by rand() limit 0,4";
							$result=$this->db->select($sql);
	 		                return($result);
					}	
			}			
		function selectBestDealCountStatus()
			{	
				$sql ="select count(*) as total from `$this->tablename` where status=1 and best_deal=1";
				$result=$this->db->select($sql);
				return($result);
			}	
		function selectBestDealBrandStatus()
			{
				$sql ="select * from `$this->tablename` where status=1 and best_deal=1 and brand_id='$this->brand_id'";
				//echo $sql;die();
				return($this->pagingQuery($sql));
			}		
		function selectBestDealBrandCountStatus()
			{
				$sql ="select count(*) as total from `$this->tablename` where status=1 and best_deal=1 and brand_id='$this->brand_id'";//echo $sql;die();
				$result=$this->db->select($sql);
				return($result);
			}						
		function searchStatus($query)
			{
				if($query==1)
				 {	
				 $sql ="select * from `$this->tablename` where category_id='$this->category_id' and status=1 and brand_id='$this->brand_id'";
				 }				
				else
					{
						$sql ="select * from `$this->tablename` where category_id='$this->category_id' and status=1";
					}	
				 //echo $sql;die();
    			   return($this->pagingQuery($sql));
			}
		function searchCountStatus($query)		
			{
				if($query==1)
				 {	
				 $sql ="select count(*) as total from `$this->tablename` where category_id='$this->category_id' and status=1 and brand_id='$this->brand_id'";
				 }				
				else
					{
						$sql ="select count(*) as total from `$this->tablename` where category_id='$this->category_id' and status=1";
					}	
				$result=$this->db->select($sql);
	 		       return($result);	
			}
		function mainSearchStatus($query)
			{
				if($query==1)
				 {	
				 $sql ="select * from `$this->tablename` where name like '%$this->name%' and status=1 and brand_id='$this->brand_id'";
				 }				
				else
					{
						$sql ="select * from `$this->tablename` where name like '%$this->name%' and status=1";
					}	
				 //echo $sql;die();
    			   return($this->pagingQuery($sql));
			}			
		function selectRecById()
			{
				$sql ="select * from `$this->tablename` 
					   where id='$this->id'";//echo $sql;die();
				   $result=$this->db->select($sql);
	 		       return($result);
			}	
		function selectRecByCategoryId()
			{
				$sql ="select * from `$this->tablename` 
					   where catid='$this->catid' and status=1";
				   //echo $sql;die();
				   $result=$this->db->select($sql);
	 		       return($result);
			}	
		function selectRecByIdStatus()
			{
				$sql ="select * from `$this->tablename` 
					   where id='$this->id' and status=1";//echo $sql;die();
				   $result=$this->db->select($sql);
	 		       return($result);
			}						
		function status()
			{
				$sql = "update `$this->tablename` set
							   `status`='$this->status'
								where `id`=$this->id";//echo $sql;die();	
						$this->db->edit($sql);		
						return true;
			}	
		function delete()
			{							 
					$sql="delete from `$this->tablename` 
						  where `id`=$this->id";//echo $sql;die();
					mysql_query($sql);	  
			}	
		function sequenceUpdate()
			{
				$sql = "update `$this->tablename` set
	  						   `seqno`='$this->seqno'
							    where `id`=$this->id";//echo $sql;die();	
						$this->db->edit($sql);		
						return true;
			}			
		/*update selected status publish*/	
		function statusUpdatePublish($chk)
			{
				for($i=0;$i<count($chk);$i++)
						{
							$id = $chk[$i];
							$sql = "update `$this->tablename` set
									`status`=1
									 where `id`='$id'";//echo $sql;die();	
									$this->db->edit($sql);		
	  				    }
			    return true;
			}	
		/*update selected status unpublish*/	
		function statusUpdateUnPublish($chk)
			{
				for($i=0;$i<count($chk);$i++)
						{
							$id = $chk[$i];
							$sql = "update `$this->tablename` set
										   `status`=0
											where `id`='$id'";//echo $sql;die();	
									$this->db->edit($sql);		
	  				    }
			    return true;
			}							
		/*delete the selected record*/	
		function deleteSelect($chk) 
			{
				for($i=0;$i<count($chk);$i++)
						{
							$id = $chk[$i];
							$sql="delete from `$this->tablename` where `id` = '$id'";
	     					$res = mysql_query($sql);
						}
				return true;
			}	
		/*...paging...*/
	function paging()
	{
		$pages = new Paging();
		$pages->sql ="select * from `$this->tablename`";
		
		$pages->page = isset($_REQUEST['page']) ? $_REQUEST['page'] : 1;
		$pages->limit = $this->limit;
		$pages->GeneratePaging();
		$this->pagination=$pages->pagination; 
		$result=$this->db->select($pages->sql);
		return($result);
	}
	function pagingQuery($sql)
	{
		$pages = new Paging();
		$pages->sql =$sql;
		$pages->page = isset($_REQUEST['page']) ? $_REQUEST['page'] : 1;
		$pages->limit = 16;
		$pages->parameters = $this->parameters;
		$pages->GeneratePaging();		
		$this->pagination=$pages->pagination; 
		$result=$this->db->select($pages->sql);
		return($result);
	}
		
   function addToCart($pid,$qty)
	{	
		unset($cart);
		$cart = array("id"=>array(), 
					  "name"=>array(), 	
					  "qty"=>array(),
					  "unit"=>array(),
					  "price"=>array());		
		$cart=$_SESSION['cart'];	
		  		
	    $sql="SELECT * FROM `$this->tablename` WHERE id=".$pid." and status=1";
		$rs=$this->db->select($sql);			
		$found=false;	
		for($col=0;$col<count($cart['id']);$col++){
			if($cart['id'][$col]==$pid)
			{ 	
				$cart['qty'][$col] = $cart['qty'][$col]+$qty;
				$qty = $cart['qty'][$col];			
				$cart['price'][$col] = ($rs[0]['price'] * $cart['qty'][$col]);
				$found=true;
				break;
			}						
		}					
		if(!$found)
		{
			$i=count($cart['id']);	
			$cart['id'][$i] = $pid; 								
			$cart['name'][$i] = $rs[0]['name'];
			$cart['qty'][$i] = $qty;
			$cart['unit'][$i] = $rs[0]['price'];
		    $cart['price'][$i] = ($rs[0]['price'] * ($qty)); 			
		}
		
		$_SESSION['cart']=$cart;		
		return $_SESSION['cart'];
	}		
 function updateCart($qty, $index)
	{
		$cart=$_SESSION['cart'];
		$cart['qty'][$index] = $qty;
		$sql="SELECT * FROM `$this->tablename` WHERE id=".$cart['id'][$index]." and status=1";
		$rs=$this->db->select($sql);
		$cart['price'][$index] = floatval($cart['qty'][$index] * $rs[0]['price']);	
		$_SESSION['cart']=$cart;		
		return $cart;
	}
 
 function remove($index)
 	{
		$cart=$_SESSION['cart'];	
		$tempcart = array("id"=>array(),"name"=>array(),"qty"=>array(),"unit"=>array(),"price"=>array());		  
		for($col=0,$tempcol=0;$col<count($cart['id']);$col++,$tempcol++)
			{
				if($col != $index)
				{
					$tempcart['id'][$tempcol]=$cart['id'][$col];
					$tempcart['name'][$tempcol]=$cart['name'][$col];
					$tempcart['qty'][$tempcol]=$cart['qty'][$col];	
					$tempcart['unit'][$tempcol]=$cart['unit'][$col];			
					$tempcart['price'][$tempcol]=$cart['price'][$col];								
				}
			} 
		$_SESSION['cart']=$tempcart;		
		unset($cart,$tempcart);
		return $_SESSION['cart'];			
	}
	
	
	function prod_cat($ctid)
	{
	
		$sql ="select * from `$this->tablename` where catid='$ctid' and status=1";
//			echo $sql; //exit;					
		 $result=$this->db->select($sql);
		 return($result);

	}
	
	function menuCategoryList()//order by id
			{
				 $sql ="select * from `$this->tablename` 
				   		 		 where subcatid=0  and  status=1 order by seq_no";//echo $sql;die();
    			   $result=$this->db->select($sql);
	 		       return($result);
			}				   			
}		
?>   