<? 
include("html/frmTemplate.php");
function details($pageName,$object,$heading,$listEdit="")
{
include("inc/clsObj.php");
?>
<!-- Added New Code For Multiple Image -->
<!-- Added New Code For Multiple Image -->
<script type="text/javascript">
	function add_file_field(){
		var container=document.getElementById('file_container');
		var file_field=document.createElement('input');
		file_field.name='images[]';
		file_field.type='file';
		// Added
		var file_field1=document.createElement('input');
		file_field1.name='img_title[]';
		file_field1.type='text';
		file_field1.value='Enter Title';
		
		var file_field2=document.createElement('input');
		file_field2.name='img_sequence[]';
		file_field2.type='text';
		file_field2.value='Enter Sequence';
		
		var file_field21=document.createElement('input');
		file_field21.name='price[]';
		file_field21.type='text';
		file_field21.value='Enter Price';
		
		var file_field3=document.createElement('br');
		// End
		container.appendChild(file_field);
		// Added
		container.appendChild(file_field1);
		container.appendChild(file_field2);
		container.appendChild(file_field21);
		container.appendChild(file_field3);
		// End
		var br_field=document.createElement('br');
		container.appendChild(br_field);
	}
	
	function getXMLHttp(){
	  var xmlHttp
	  try{
		//Firefox, Opera 8.0+, Safari
		xmlHttp = new XMLHttpRequest();
	  }
	  catch(e){
		//Internet Explorer
		try{
		  xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
		}
		catch(e){
		  try{
			xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
		  }
		  catch(e){
			alert("Your browser does not support AJAX!")
			return false;
		  }
		}
	  }
	  return xmlHttp;
	}
	
	function MakeRequest(getId, getImg){
	  var xmlHttp = getXMLHttp();
	  xmlHttp.onreadystatechange = function(){
		if(xmlHttp.readyState == 4){
		  HandleResponse(xmlHttp.responseText);
		}
	  }
	  xmlHttp.open("GET", "multiple_ajax.php?property_id="+getId+"&img="+getImg, true); 
	  xmlHttp.send(null);
	}
	
	function HandleResponse(response){
	  	alert(response);
		window.location.reload();
	}
	
	function MakeUpdateRequest(getId, getTitle, getSeq){
	  var xmlHttp = getXMLHttp();
	  xmlHttp.onreadystatechange = function(){
		if(xmlHttp.readyState == 4){
		  HandleUpdateResponse(xmlHttp.responseText);
		}
	  }
	  xmlHttp.open("GET", "multiple_ajax.php?img_id="+getId+"&title="+getTitle+"&seq="+getSeq, true); 
	  xmlHttp.send(null);
	}
	
	function HandleUpdateResponse(response){
	  	alert(response);
		//window.location.reload();
	}

</script>
<!-- End  name="frmManage"-->

<!-- ALIAS JS AND CSS ADDED -->
<script src="jquery.js" type="text/javascript" language="javascript"></script>
<form action="<?=$pageName;?>" method="post"  enctype="multipart/form-data" onSubmit="return ValidateForm(this)" name="mutiple_file_upload_form" id="mutiple_file_upload_form">

   <fieldset>
    	<legend>Testimonials Details</legend>          	
        <ul>
        	<li>
            	<label >Name <span class="requiredt"> * </span> :</label>
            </li>
            <li>
           	  	<input type="text" name="product_name" id="product_name" value="<?=$listEdit[0]['name'];?>" size="30">
            </li>
        </ul>   
        <ul>
        	<li>
            	<label >Sequence No. :</label>
            </li>
            <li>
           	  	<input type="text" name="Sequence_No" id="Sequence_No" value="<?=$listEdit[0]['seqNo'];?>">
            </li>
        </ul> 
		 <ul>
        	<li>
            	<label >Designation :</label>
            </li>
            <li>
           	  	<input type="text" name="post" id="post" value="<?=$listEdit[0]['post'];?>">
            </li>
        </ul> 
		
		 <ul>
        	<li>
            	<label >Image :</label>
            </li>
            <li>
           	  <input type="file" name="imageOriginal" id="imageOriginal"/>
            </li>
        </ul>
        <?php if(isset($_REQUEST['id'])){?>
        <ul>
        	<li>
        	  <label>&nbsp;</label>
        	</li>
            <li>
                <img src="<?php echo TESTIMONIAL_BIG_IMAGE.$listEdit[0]['image'];?>" alt="" width="100" height="100" />
                <input type="hidden" name="hiddenImage" id="hiddenImage" value="<?php echo $listEdit[0]['image']; ?>"/>
            </li>
        </ul>
        <?php }?>
		
		
		
		<?php /*?><ul>
			<li>
            	<label >Company name</label>
            </li>
            <li>
           	  	<?
                $path = pathinfo($_SERVER['SCRIPT_NAME']);
                $sBasePath = $path['dirname']."/editor/";
                $oFCKeditor = new FCKeditor('FCKeditor2') ;
                $oFCKeditor->ToolbarSet = 'MyToolbar' ;
                $oFCKeditor->Height ='200';
                $oFCKeditor->BasePath	= $sBasePath ;
                $oFCKeditor->Config['SkinPath'] = $sBasePath . 'editor/skins/silver/' ;
                $oFCKeditor->Value	= $listEdit[0]['company_name'];
                $oFCKeditor->Create() ;
            ?>                
      
            </li>
        </ul><?php */?>
     	<ul>
        	<li>
        	   <label >Description :</label>
        	</li>
            <li>
            <textarea  name="description" id="description" ><?=$listEdit[0]['description']; ?></textarea>
           </li>
    	</ul>
    	
        
        
            
    	</fieldset>
        
        
        <ul>
        	<li>
        	   <label>&nbsp;</label>
        	</li>
            <li>
			<? frmButtons($heading); if(isset($_GET['id']) && $_GET['id']!='')
            {
            	frmApplyButtons($heading);
			}
			?>               
            </li>
        </ul>
        <input type="hidden" name="Validation" value="Field=product_name|Alias=Product Name|Validate=Blank"/>    
</form>
<? }

function rowDisplay($pageName,$object,$heading,$listRec=""){
include("inc/clsObj.php");
?>

<!-- Sorting Start -->

<? 
extract($_POST);
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tabular">
  <tr>
    <th width="5%" onClick="sortColumn('id');" >Id. <div <? if($sortClName=='id' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='id' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?> ></div></th>    
    <th width="5%" onClick="sortColumn('seqNo');"  >Seq. No.<div <? if($sortClName=='seqNo' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='seqNo' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?>></div></th>   
    <th width="24%" onClick="sortColumn('product_name');" >Name <div <? if($sortClName=='product_name' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='product_name' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?>></div>
    </th>
   <?php /*?> <th width="46%" onClick="sortColumn('category_name');"   >Company Name <div <? if($sortClName=='category_name' && $ascdsc=='1'){echo "class='ascolumn'" ;}elseif($sortClName=='category_name' && $ascdsc=='0'){
		echo "class='descolumn'";
	} ?>></div></th><?php */?>
    
    <th width="19%">Actions&nbsp;
    <input type="checkbox" id="selectAll" name="selectAll" onClick="check_all(this.form,this);"/></th>
  </tr>  
   <?  
    if(count($listRec)>0)
	 {
	 	$colorflg=0;
         for($e=0;$e<count($listRec);$e++){
	     if ($colorflg==1)
		 {
			 $colorflg=0;?>
  		 <tr class="odd" onMouseOver="Javascript:this.className='rowhover'" onMouseOut="Javascript:this.className='odd'">
  		 <?
         }
		 else
		 {
			 $colorflg=1;?>
		 <tr class="even" onMouseOver="Javascript:this.className='rowhover'" onMouseOut="Javascript:this.className='even'">
  		 <?
         } ?>		        
                <td><?=$listRec[$e]['id'];?></td> 
                <td>
                <input type="text" size="3" name="txtSeqNo[]" id="txtSeqNo" value="<?=$listRec[$e]['seqNo'];?>"/>
                <input type="hidden"  name="categoryId[]" id="categoryId" value="<?=$listRec[$e]['id'];?>" size="3"/>
                </td> 
				<td><?=$listRec[$e]['name'];?></td>
              <?php /*?>  <td>
				<?=$listRec[$e]['company_name'];?></td>
				</td><?php */?>
                <td>
				<? frmActionButton($listRec[$e]['id'],$listRec[$e]['status'],$pageName,$listRec[$e]['name'],$heading); ?>
                </td>
	     </tr>
           <?php }}else {?>
  		<tr>
        	<td colspan="7" align="center">
            	No Records Found...
			</td>
        </tr>
    <?php }?>    
  </table>
<? } ?>