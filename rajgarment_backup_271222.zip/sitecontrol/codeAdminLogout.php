<?php 	
	session_start();
	
	//session_unregister('membername');
	//session_unregister('memberid');
	//session_unregister('accessby');
	
	$_SESSION['accessby']="";
	$_SESSION['memberid']="";
	$_SESSION['membername']="";
	$_SESSION['uid']="";
	
	unset($_SESSION['accessby']);
	unset($_SESSION['memberid']);
	unset($_SESSION['membername']);
	unset($_SESSION['uid']);
	
	header("Location: index.php");
?>
<script type="text/javascript">
	document.location="index.php";
</script>
