<?php
global $db;
class banner
{
	   var $tablename='banner';
	   var $id;	   
	   var $name;
       var $seqNo;
	   var $webcaption;	  
	   var $image;
	   var $status;
	   var $limit;
	   var $start;
       		function banner()
			{
						$this->db = new dbclass();
			}
	   		function insert()
			{	
				$sql = "insert into `$this->tablename` values('',																											
								'$this->name',
								'$this->seqNo',
								'$this->caption',
								'$this->url_link',			
								'$this->image',
								 $this->status)";
								//echo $sql;die();										
					$this->db->insert($sql);
					$id=mysql_insert_id();
					return($id);
			}
	   		function update()
			{
				$sql = "update `$this->tablename` set
								`name`='$this->name',
								`seqNo`='$this->seqNo',
								`caption`='$this->caption',
								`url_link`='$this->url_link',
								`image`='$this->image'																		
						    	 where `id`=$this->id";
								 
								 //echo $sql;die();	
						$this->db->edit($sql);		
						return true;
			}					
			function select()
			{
				 $sql ="select * from `$this->tablename` order by seqNo asc";//echo $sql;die();
    			   $result=$this->db->select($sql);
	 		       return($result);
			}	
			function selectStatus()
			{
				 $sql ="select * from `$this->tablename` where status=1 order by seqNo asc";
				 //echo $sql;die();
    			   $result=$this->db->select($sql);
	 		       return($result);
			}	
			function selectRecById()
			{
				$sql ="select * from `$this->tablename` 
					   where id='$this->id'";//echo $sql;die();
				   $result=$this->db->select($sql);
	 		       return($result);
			}					
			function status()
			{
				$sql = "update `$this->tablename` set
							   `status`='$this->status'
								where `id`=$this->id";//echo $sql;die();	
						$this->db->edit($sql);		
						return true;
			}	
			function delete()
			{							 
					$sql="delete from `$this->tablename` 
						  where `id`=$this->id";//echo $sql;die();
					mysql_query($sql);	  
			}	
			function sequenceUpdate()
			{
				$sql = "update `$this->tablename` set
	  						   `seqno`='$this->seqno'
							    where `id`=$this->id";//echo $sql;die();	
						$this->db->edit($sql);		
						return true;
			}			
		/*update selected status publish*/	
			function statusUpdatePublish($chk)
			{
				for($i=0;$i<count($chk);$i++)
						{
							$id = $chk[$i];
							$sql = "update `$this->tablename` set
									`status`=1
									 where `id`='$id'";//echo $sql;die();	
									$this->db->edit($sql);		
	  				    }
			    return true;
			}	
		/*update selected status unpublish*/	
			function statusUpdateUnPublish($chk)
			{
				for($i=0;$i<count($chk);$i++)
						{
							$id = $chk[$i];
							$sql = "update `$this->tablename` set
										   `status`=0
											where `id`='$id'";//echo $sql;die();	
									$this->db->edit($sql);		
	  				    }
			    return true;
			}							
		/*delete the selected record*/	
			function deleteSelect($chk) 
			{
				for($i=0;$i<count($chk);$i++)
						{
							$id = $chk[$i];
							$sql="delete from `$this->tablename` where `id` = '$id'";
	     					$res = mysql_query($sql);
						}
				return true;
			}	
			
		/*...paging...*/
		function paging()
		{
			$pages = new Paging();
			
			if(isset($_POST['search']) && $_POST['search']=='Search' && $_POST['search_txt']!='')
			{
				$query = "select * from `$this->tablename` where (name LIKE '%".$_POST['search_txt']."%') order by id asc";			
			}
			else
			{				
			
			extract($_POST);
		
			if($sortClName!='')
			{			
				$query = 'select * from `banner` order by '.$sortClName;											
			}
			else
			{
				$query = 'select * from `banner` order by seqNo';				
			}
						
			switch ($ascdsc)
			{
			  case 0:
			  $query = $query." asc";
				break;
			  case 1:
			  $query = $query." desc";
				break;
			}			
				 // echo "<pre>"; print_r($_POST); exit;
				// echo $query; exit;		
			}
			
			$pages->sql = $query;
						
			$pages->page = isset($_REQUEST['page']) ? $_REQUEST['page'] : 1;
			$pages->limit = $this->limit;
			$pages->GeneratePaging();
			$this->pagination=$pages->pagination; 
			$result=$this->db->select($pages->sql);
			return($result);
		}   			
}		
?>   