<?php
	error_reporting(0);
 	include("sitecontrol/inc/fileInclude.php"); 
	include("sitecontrol/inc/clsObj.php"); 
	include("sitecontrol/config.php"); 
	
	if(stristr($_SERVER['PHP_SELF'],"index.php")!="")
	{
		$objFrontMenu->id=1;
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	elseif(stristr($_SERVER['PHP_SELF'],"aboutus.php")!="")
	{
		$objFrontMenu->id=2;
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	elseif(stristr($_SERVER['PHP_SELF'],"products.php")!="")
	{
		$objFrontMenu->id=3;
		$metaRec=$objFrontMenu->selectRecById(); 
	}	
	elseif(stristr($_SERVER['PHP_SELF'],"inquiry.php")!="")
	{		
		$objFrontMenu->id=6;
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	elseif(stristr($_SERVER['PHP_SELF'],"contactus.php")!="")
	{
		$objFrontMenu->id=7;
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	elseif(stristr($_SERVER['PHP_SELF'],"sitemap.php")!="")
	{
		$objFrontMenu->id=8;
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	
	elseif(stristr($_SERVER['PHP_SELF'],"photo_gallery.php")!="")
	{
		$objFrontMenu->id=9;
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	elseif(stristr($_SERVER['PHP_SELF'],"video_gallery.php")!="")
	{
		$objFrontMenu->id=11;
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	elseif(stristr($_SERVER['PHP_SELF'],"abc.php")!="")
	{
		$objFrontMenu->id=13;
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	elseif((isset($_GET['ctid']) && $_GET['ctid']!="") || (isset($_GET['cpname']) && $_GET['cpname']!="") || (isset($_GET['pid']) && $_GET['pid']!=""))
	{
		if(isset($_GET['ctid']))
		{
				$objProCat->id=$_GET['ctid'];
				$metaRec = $objProCat->selectRecById();
				
				if($metaRec[0]['metaTitle']=='')
				{
					$metaRec[0]['metaTitle'] = $metaRec[0]['category_name'].' | '.META_TITLE;
				}
				if($metaRec[0]['metaDescription']=='')
				{
					$metaRec[0]['metaDescription'] = WE_OFFER.' '.$metaRec[0]['category_name'].' , '.META_DESC;
				}
				if($metaRec[0]['metaKeywords']=='')
				{
					$metaRec[0]['metaKeywords'] = $metaRec[0]['category_name'].' , '.META_KEYWORD;
				}
				
			}
			elseif(isset($_GET['pid']))
			{
				$objProduct->id=$_GET['pid'];
				$metaRec = $objProduct->selectRecById();
				
				if($metaRec[0]['metaTitle']=='')
				{
					$metaRec[0]['metaTitle'] = $metaRec[0]['product_name'].' | '.META_TITLE;
				}
				if($metaRec[0]['metaDescription']=='')
				{
					$metaRec[0]['metaDescription'] = WE_OFFER.' '.$metaRec[0]['product_name'].' , '.META_DESC;
				}
				if($metaRec[0]['metaKeywords']=='')
				{
					$metaRec[0]['metaKeywords'] = $metaRec[0]['product_name'].' , '.META_KEYWORD;
				}
			}
			elseif(isset($_GET['cpname']))
			{
				$objProduct->alias_name=$_GET['cpname'];
				$metaRec = $objProduct->selectRecByAlias();	
				
				//echo "<pre>"; print_r($metaRec); exit;
				
				if(count($metaRec)>0)
				{
					if($metaRec[0]['metaTitle']=='')
					{
						$metaRec[0]['metaTitle'] = $metaRec[0]['product_name'].' | '.META_TITLE;
					}
					if($metaRec[0]['metaDescription']=='')
					{
						$metaRec[0]['metaDescription'] = WE_OFFER.' '.$metaRec[0]['product_name'].' , '.META_DESC;
					}
					if($metaRec[0]['metaKeywords']=='')
					{
						$metaRec[0]['metaKeywords'] = $metaRec[0]['product_name'].' , '.META_KEYWORD;
					}
				}
				else
				{
				
					$objProCat->alias_name=$_GET['cpname'];
					$metaRec = $objProCat->selectRecByAlias();	
									
					if($metaRec[0]['metaTitle']=='')
					{
						$metaRec[0]['metaTitle'] = $metaRec[0]['category_name'].' | '.META_TITLE;
					}
					if($metaRec[0]['metaDescription']=='')
					{
						$metaRec[0]['metaDescription'] = WE_OFFER.' '.$metaRec[0]['category_name'].' , '.META_DESC;
					}
					if($metaRec[0]['metaKeywords']=='')
					{
						$metaRec[0]['metaKeywords'] = $metaRec[0]['category_name'].' , '.META_KEYWORD;
					}
					
				}
								
			}						
	}
	else
	{
		$objFrontMenu->id=$_GET['id'];
		$metaRec=$objFrontMenu->selectRecById(); 
	}
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title><? echo $metaRec[0]['metaTitle'];?></title>
<meta name="description" content="<? echo $metaRec[0]['metaDescription'];?>" />
<meta name="keywords" content="<? echo $metaRec[0]['metaKeywords'];?>" />
<meta name="robots" content="index,follow" />

<link rel="stylesheet" type="text/css" href="css/style.css" media="screen">
<script type="text/javascript" src="js/cufon-yui.js"></script>
<style type="text/css">cufon{text-indent:0!important;}@media screen,projection{cufon{display:inline!important;display:inline-block!important;position:relative!important;vertical-align:middle!important;font-size:1px!important;line-height:1px!important;}cufon cufontext{display:-moz-inline-box!important;display:inline-block!important;width:0!important;height:0!important;overflow:hidden!important;text-indent:-10000in!important;}cufon canvas{position:relative!important;}}@media print{cufon{padding:0!important;}cufon canvas{display:none!important;}}
</style>

<script type="text/javascript" src="js/PT_Sans.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.5.3.min.js"></script>
<script type="text/javascript" src="js/hoverintent.js"></script>
<script type="text/javascript" src="js/superfish.js"></script>
<script type="text/javascript" src="js/custom.js"></script>

<!--tabs-categories -->
<script type="text/javascript" src="js/tabs-hoverintent.js"></script>
<script type="text/javascript" src="js/tabs-superfish.js"></script>
<script type="text/javascript" src="js/tabs.js"></script>

<link rel="stylesheet" href="css/tabs.css" type="text/css" media="screen">
<!--Start Of Script Generated By WP-PageNavi 2.40 -->
<link rel="stylesheet" href="css/pagenavi-css.css" type="text/css" media="screen">
<!--End Of Script Generated By WP-PageNavi 2.40 -->
<link rel="stylesheet" href="css/my.css" type="text/css">

</head>

<body>
<div id="page">
  <!--header-->
  <div id="header">

    <!--logo-->
    <div class="logo">
    
      <h1><a href="<? echo BASE_URL; ?>" id="toplogo">
      <img id="toplogo" src="images/logo.png"/>
     </a></h1>

      </div>
           
    <!--/logo-->

    <!--/searchform -->
    <div class="clr"></div>
    <!--topnav menu-->

    <div class="topnav">
    
      <? include("top_menu.php"); ?>

      <div class="clr"></div>
    </div>
    <!--/topnav -->
    <div class="clr"></div>
    	<?  if(basename($_SERVER['PHP_SELF'])=='index.php')
			{ ?>
                <div id="featured">
      				<ul class="ui-tabs-nav">
						<? $banner = $objBanner->selectStatus();
                        for($i=0; $i<count($banner); $i++)
                        {
                        ?>
                        <li class="ui-tabs-nav-item first ui-tabs-selected" id="nav-fragment-1">
                        <a href="#fragment-<? echo $i+1;?>">
                            <img src="<?=BANNER_SMALL_IMAGE.$banner[$i]['image'];?>" alt="" height="59" width="98" />
                            <span><?=$banner[$i]['name'];?></span>
                        </a>
                        </li>                
                        <?			
                        }
                        ?>             
      				</ul>
						<?
                        for($i=0; $i<count($banner); $i++)
                        {
                        ?>
                        <div id="fragment-<? echo $i+1;?>" class="ui-tabs-panel" style="">
                            <img src="<?=BANNER_BIG_IMAGE.$banner[$i]['image'];?>" alt="" />
                        </div>
						<?			
                        }
                        ?>
    			</div>
                <?			
			}
		 	?>
    		<div class="clr"></div>
 	 </div>

  <!--/header-->
  <div id="columns">
   <? main(); ?>  
       <div class="clr"></div>     
  </div>
  <!--/columns -->
  <div id="footer">
    <div class="text">copyright &copy; <?=date('Y');?>, <?=SITE_NAME;?>  , All rights reserved. <br />Powered by
<a target="_blank" href="<?=POWER_BY_WEBSITE;?>" style="color:#3a335d;"><?=POWER_BY;?></a></div>

    <div class="text2">
   
     <?  $social = $objSocialLinks->selectStatus();
	 	
		for($i=0; $i<count($social); $i++)
		{	
			?>
            <a href="<?=$social[$i]['s_link'];?>" target="_blank"> <img src="<?=SOCIAL_IMAGE.$social[$i]['image'];?>" title="<?=$social[$i]['title'];?>" alt="<?=$social[$i]['title'];?>" > </a>
            <?
		}
	 
	  ?>
         </div>
  </div>
  <div class="clr"></div>
</div>
<!--/page -->
</body>
</html>