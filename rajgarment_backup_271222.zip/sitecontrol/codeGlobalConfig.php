<?php
include("template.php");
function main()
{
	include("inc/clsObj.php");	
	$heading="Global Configuration";	
	$object=$objGlobalConfig;
	
	$pageName="codeGlobalConfig.php";
	$object->limit=100;
	
	extract($_POST);	
	
	$object->id=isset($_GET['uid']) ? $_GET['uid'] : ( isset($_GET['delete']) ? $_GET['delete'] : ( isset($_GET['id']) ? $_GET['id'] : $hid )) ;	
	
	//echo "<pre>";print_r($_POST);exit;
	$object->name = $name;
	$object->seqNo = $txtSeqNo;
	$object->constantName = $constantName;	
	$object->constantValue = $constantValue;
			
	$object->status=isset($_GET['status']) ? $_GET['status'] : 1;	
	
	if(isset($_POST['btnAdd']))
	{				
		$object->insert();
		redirect($pageName."?msg=add");
	}	
	
	if(isset($_POST['btnUpdate']))
	{							
		$object->update();
		redirect($pageName."?msg=edit");
	}			
	
	if(isset($_POST['btnAction']))
	{
		 extract($_POST);
		 switch($optAction)
		 {
		  	case 0:
					$object->deleteSelect($chkAction);
    				redirect($pageName."?msg=del");
					break;
			case 1:
			 		$object->statusUpdatePublish($chkAction);
         			redirect($pageName."?msg=Publish");
			        break;
			case 2:
			        $object->statusUpdateUnPublish($chkAction);
					redirect($pageName."?msg=UnPublish");
					break;
			case 3:
					extract($_POST);
					for($i=0;count($categoryId)>$i;$i++)
					{
						$object->id=$categoryId[$i];
						$object->seqNo=$txtSeqNo[$i];
						$object->sequenceUpdate();				
					}	
					redirect($pageName."?msg=seq");					
		   } 
	     }						
	
	if(isset($_GET['id']))
	{					
			$editRec=$object->selectRecById();									
	}	
	
	if(isset($_GET['delete']))
	{								 
		  $object->delete();
		  redirect($pageName."?msg=del");
	}	
	
	if(isset($_GET['status']))
	{			
		 $object->status();
		 redirect($pageName."?msg=status");		
	}
	
	$listRec=$object->paging();	
    include("html/frmGlobalConfig.php");	
 } 
?>