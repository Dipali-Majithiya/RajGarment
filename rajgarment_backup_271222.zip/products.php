<?php
include("template.php");
//	include("sitecontrol/inc/fileInclude.php"); 
//	$menuListRec1=$objFrontMenu->menuCategoryListFront("top");	
//	echo "<pre>"; print_r($menuListRec1);
function main()
{ 	
	include("sitecontrol/inc/clsObj.php"); 
	session_start();
 		$Category = $objProCat->menuCategoryList();
		?>      
        <style type="text/css">
			.products th{
				color: #000;
				padding: 5px;
				text-align: left;
			}
			<?
				if(PRODUCT_MODE>4){
					
					?>
					.products th{
						background:#3A335D;
						color: #fff;
						padding: 5px;
						text-align: left;
					}
					
					.products th a{						
						color: #fff!important;						
					}
			 <?
				}
			 ?>
			
			.products img{
				border:0px solid #ccc;				
			}
			.products td:first-child{
				padding-right:20px;
			}
		</style>

<link rel="stylesheet" href="engine/css/vlightbox1.css" type="text/css" />
<link rel="stylesheet" href="engine/css/visuallightbox.css" type="text/css" media="screen" />
<script src="engine/js/jquery.min.js" type="text/javascript"></script>
<script src="engine/js/visuallightbox.js" type="text/javascript"></script>

<h1 class="headingh1">Products</h1> 
		    
        <table class="products" width="100%">
        	<?		
		for($t=0; $t<count($Category); $t++)
		{
				if($Category[$t]['alias_name']!="")
					$link = $Category[$t]['alias_name'].".html";
				else
					$link = "content.php?ctid=".$Category[$t]['id'];
				
			?>            
            <tr><th><a href="<?=$link;?>"><?=$Category[$t]['category_name'];?></a></th></tr>
            <tr><td style="padding-left:50px;"><? subCat($Category[$t]['id']); ?></td></tr>
            
                <?
		}		
		// rootLevelProduct();		
		?>
        </table>       
		<script src="engine/js/vlbdata1.js" type="text/javascript"></script>
        <?
} 
?>