function sortColumn(clName)
{
	document.tmpFrm.sortClName.value = clName;
	document.tmpFrm.rowNo.value = 0;
	document.tmpFrm.editTbl.value = 0;
	document.tmpFrm.editTblBool.value = 0;
	document.tmpFrm.newTbl.value = 0;
	document.tmpFrm.submit();
} //end of sortColumn

