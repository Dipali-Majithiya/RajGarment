<?php
global $db;
class userFrontMenuMaster
{
   var $tablename='menumgr';
   var $id;
   var $menuName;
   var $alias_name;
   var $seqNo;
   var $menuPosition;
   var $menuSubId;
   var $menuType;
   var $menuUrl;
   var $menuTargetWindow;
   var $menuFileName;
   var $menuDesc; 
   var $metaTitle;  
   var $metaDescription;
   var $metaKeywords;
   var $menuRobots;
   var $menuAuthor;	
   var $status;
   var $image;	
   var $limit;
   var $start;
	
	function userFrontMenuMaster()
	{
		$this->db = new dbclass();
	}

	function insert()
	{	
		$sql = "insert into `$this->tablename` values('',
						$this->menuSubId,
						'$this->seqNo',
						'$this->menuName',
						'$this->alias_name',
						'$this->menuPosition',
						'$this->menuDesc',
						'$this->menuUrl',
						'$this->menuFileName',
						'$this->menuType',								
						'$this->menuTargetWindow',
						'$this->status',
						'$this->image',								
						'$this->metaTitle',
						'$this->metaDescription',
						'$this->metaKeywords',
						'$this->menuRobots',
						'$this->menuAuthor')";
						//echo $sql;die();		
			$this->db->insert($sql);
			$id=mysql_insert_id();
			return($id);
	}

	function update()
	{
		$sql = "update `$this->tablename` set	  							
						`menuName`='$this->menuName',
						`alias_name`='$this->alias_name',
						`seqNo`=$this->seqNo,
						`menuPosition`='$this->menuPosition',
						`menuSubId`='$this->menuSubId',
						`menuType`='$this->menuType',
						`menuUrl`='$this->menuUrl',
						`menuTargetWindow`='$this->menuTargetWindow',
						`menuFileName`='$this->menuFileName',
						`menuDesc`='$this->menuDesc',
						`metaKeywords`='$this->metaKeywords',
						`image`='$this->image',
						`metaTitle`='$this->metaTitle',																	
						`metaDescription`='$this->metaDescription',
						`menuRobots`='$this->menuRobots',	
						`menuAuthor`='$this->menuAuthor'										
						 where `id`=$this->id";
						 // echo $sql;die();	
				$this->db->edit($sql);		
				return true;
	}		

	function menuCategoryList()//order by adminid
	{		 
		if(isset($_POST['search']) && $_POST['search']=='Search' && $_POST['search_txt']!='')
		{
			$query = "select * from `$this->tablename` where (menuName LIKE '%".$_POST['search_txt']."%') order by id asc";			
		}
		else
	    {
			//$sql = "select * from `$this->tablename`  where menuSubId = 0 order by seqNo asc";		
			extract($_POST);			
		
			if($sortClName!='')
			{				
				$query = 'select * from `menumgr` where menuSubId = 0 order by '.$sortClName;			
			}
			else
			{			
				$query = 'select * from `menumgr`  where menuSubId = 0 order by seqNo ';		
			}
		
			switch ($ascdsc)
			{
		  		case 0:
		  			$query = $query." asc";
				break;
		 		case 1:
		  			$query = $query." desc";
				break;
			}		
			 // echo "<pre>"; print_r($_POST); exit;
			// echo $query; exit;
		}		 
			// echo $sql; die();			
			// echo $query; exit;			
			$sql = $query;			
		   
		   $result=$this->db->select($sql);
		   return($result);
	}

	function topMenuList()//order by adminid
	{
		 $sql ="select * from `$this->tablename` where menuPosition = 'top' and menuSubId=0 order by seqNo asc";
		// echo $sql;die();
		$result=$this->db->select($sql);
		return($result);
	}	

	function menuSubCategoryList()//order by adminid
	{
		   $sql ="select * from `$this->tablename` where menuSubId=$this->id order by seqNo asc";//echo $sql;die();
		   $result=$this->db->select($sql);
		   return($result);
	}
	
	function menuSubCategoryListFront()//order by adminid for submenu
	{
		   $sql ="select * from `$this->tablename` where menuSubId=$this->id and status=1 order by seqNo asc";//echo $sql;die();
		   $result=$this->db->select($sql);
		   return($result);
	}

	function selectRecById()
	{
		$sql ="select * from `$this->tablename` where id='$this->id'";
		//echo $sql;die();
		   $result=$this->db->select($sql);
		   return($result);
	}

	function menuCategoryListFront($type)
	{
		 $sql ="select * from `$this->tablename` where menuSubId=0 and menuPosition='$type' and status=1 order by seqNo asc";
		 //echo $sql;die();
		   $result=$this->db->select($sql);
		   return($result);
	}				

	function status()
	{
		$sql = "update `$this->tablename` set
					   `status`='$this->status'
						where `id`=$this->id";//echo $sql;die();	
				$this->db->edit($sql);		
				return true;
	}

	function delete()
	{
			$sql="delete from `$this->tablename` 
				  where `menuSubId`=$this->id";
			mysql_query($sql);		  
			$sql="delete from `$this->tablename` 
				  where `id`=$this->id";//echo $sql;die();
			mysql_query($sql);	  
	}

	function sequenceUpdate()
	{
		$sql = "update `$this->tablename` set
					   `seqNo`='$this->seqNo'
						where `id`=$this->id";//echo $sql;die();	
				$this->db->edit($sql);		
				return true;
	}	

	/*update selected status publish*/	
	function statusUpdatePublish($chk)
	{
		for($i=0;$i<count($chk);$i++)
		{
			$id = $chk[$i];
			$sql = "update `$this->tablename` set
						   `status`=1
							where `id`='$id'";//echo $sql;die();	
					$this->db->edit($sql);		
		}
		return true;
	}	

	/*update selected status unpublish*/	
	function statusUpdateUnPublish($chk)
	{
		for($i=0;$i<count($chk);$i++)
		{
			$id = $chk[$i];
			$sql = "update `$this->tablename` set
						   `status`=0
							where `id`='$id'";//echo $sql;die();	
					$this->db->edit($sql);		
		}
		return true;
	}	

	/*delete the selected record*/	
	function deleteSelect($chk) 
	{
		for($i=0;$i<count($chk);$i++)
		{
			$id = $chk[$i];
			$sql="delete from `$this->tablename` where `id` = '$id'";
			$res = mysql_query($sql);
		}
		return true;
	}	
	
	function selectRecByAlias()
	{
		// $sql ="select * from `$this->tablename` where alias_name='$this->alias_name'";
		
		$sql =  "select * from ".$this->tablename." where alias_name=\"".$this->alias_name."\";"; 
			   //echo $sql;die();
		   $result=$this->db->select($sql);
		   return($result);
	}
			
			function selectRecords($pvar)
			{
			//	$sql ="select distinct count(p.alias_name),count(pc.alias_name),count(mm.alias_name) from products as p, pro_categories as pc, menumgr as mm where (p.alias_name = '".$pvar."') or (pc.alias_name = '".$pvar."') or (mm.alias_name = '".$pvar."')  ";
						
			$sql = "SELECT alias_name,id, COUNT(*) AS tes FROM menumgr WHERE alias_name='".$pvar."' GROUP BY alias_name HAVING COUNT(*) >= 1 union SELECT alias_name,id, COUNT(*) AS pro FROM products WHERE alias_name='".$pvar."' GROUP BY alias_name HAVING COUNT(*) >= 1 union SELECT alias_name,id, COUNT(*) AS pro FROM pro_categories WHERE alias_name='".$pvar."' GROUP BY alias_name HAVING COUNT(*) >= 1";
			
				//echo $sql;die();
    			$result=$this->db->select($sql);
		   		return($result);
			}		
}		
?>   